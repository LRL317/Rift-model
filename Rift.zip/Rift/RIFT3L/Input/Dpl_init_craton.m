function Dpl = Dpl_init_craton(Dpl0,GCOORD,ELEM2NODE,base_lithos,y_min1,Phases,nel )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

km = 1000;
% Transition points
ZDPL_01 =     -60*km; % DEPTH AT WHICH DEPLETION IS 10% OR 0.1 OVER 1
base_lithos = base_lithos; % DEPTH AT WHICH DEPLETION IS 0.04 OR 4% == EQUAL BASE LITHOS
Top_wet =  -160*km; % TOP DEPTH AT WHICH DEPLETION IS 0
Base_wet = y_min1; % BASI OF BOX - HERE DEPLETION IS 0



%==========================================================================
% CALCULATE RHEOLOGIC VARIATION FACTORS
%==========================================================================
% Wet asthenosphere
ind = find( GCOORD(2, :)  >= Base_wet & GCOORD(2, :) <= Top_wet);
Dpl(ind) = 0.0;
ind2 = find( GCOORD(2, :) > Top_wet  &  GCOORD(2, :)  < base_lithos );
Dpl(ind2) = (0.04/(base_lithos-Top_wet))*GCOORD(2,ind2) - (0.04/(base_lithos-Top_wet))*Top_wet;
ind3 = find(GCOORD(2, :) == base_lithos);
Dpl(ind3) = 0.04;
ind4 =  find(GCOORD(2,:) > base_lithos & GCOORD(2,:) <= ZDPL_01) ;
Dpl(ind4 ) = (0.06/(ZDPL_01-base_lithos))*GCOORD(2,ind4) + 0.04 - (0.06/(ZDPL_01-base_lithos))*base_lithos;
ind5 =  find(GCOORD(2,:) > ZDPL_01);
Dpl(ind5 ) = 0.1;




% % Figure
% figure(3)
% EL2N      = zeros(nel,3); % new connectivity matrix
% GCOORD_N  = zeros(2,nel*3);
% Dpl_n      = zeros(3,nel);
% 
% EL2N(1,:) = 1:3;
% nip = 6;
% nnodel = 6;
% [IP_X, IP_w]    = ip_triangle(nip);
% [   Nbig]    = shp_triangle(IP_X, nnodel);
% for i=1:nel
%     is         = (i-1)*3+1; ie = (i-1)*3+3;
%     GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
%     EL2N(i,:) = is:ie;
%     
%     Dpl_n(is:ie) = Dpl(ELEM2NODE([1 2 3],i));
%     
% end
% 
% 
% patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata',Dpl_n(:),'FaceColor','flat')
% shading interp
% %axis ([-150 150 -60 5])
% %axis ([-150 250 -60 5])
% %  axis ([-50 150 -60 5])
% %axis ([-250 250 -200 5])
% colorbar
% axis tight
% hold on
% %plot(Boxx,Boxy,'k')
% hold on
% caxis([0 0.1])
end

