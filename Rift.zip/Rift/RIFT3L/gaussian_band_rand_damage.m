function SS = gaussian_band_rand_damage(SS,RDWS,GCOORD,ELEM2NODE,nip)

% Get the x coordinates of the central node
X_NODE7 = GCOORD(1,ELEM2NODE(7,:))';
% Calculate the factors for this coordinates using a gaussian function
RDWS_factor = (RDWS.factor-1)*exp(-X_NODE7.^2./((RDWS.sigma/2)^2))+1;
SS.RDWS_factor = repmat(RDWS_factor,1,nip);

% % Plot (uncomment)
% plot(X_NODE7/1000,SS.RDWS_factor,'.')
% hold on
% plot([-RDWS.sigma RDWS.sigma; -RDWS.sigma RDWS.sigma]/2/1000, ...
%     [1 1; RDWS.factor RDWS.factor])
% hold off