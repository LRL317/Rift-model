function [iter_wb] = call_waitbar(iter_wb,ma,time0,ntime,time_int,dt,wait_bar)
%CALL_WAITBAR calculates the elapsed time and plots a waitbar

    iter_wb = iter_wb + 1;
    
    tdiff_wb = (clock - time0);
    tdiff_wb(2) = tdiff_wb(2)*365*24*60;
    tdiff_wb(3) = tdiff_wb(3)*30*24*60;
    tdiff_wb(4) = tdiff_wb(4)*24*60;
    tdiff_wb(6) = tdiff_wb(6)/60;
    tdiff_wb = sum(tdiff_wb);
    
    time_left = (time_int-ntime)/dt*tdiff_wb/iter_wb;
    hours_wb = floor(time_left/60);
    minutes_wb = floor((time_left/60-hours_wb)*60);
    try
        waitbar(ntime/time_int,wait_bar,[num2str(floor(ntime/time_int*100)) ...
            '%        ' num2str(floor(ntime/ma*100)/100) ...
            ' Myr        Time Remaining: ' ...
            num2str(hours_wb) ' h ' num2str(minutes_wb) ' min']);
    end
    
end

