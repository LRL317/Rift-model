function [Bc_ind, Bc_val, Point_id, Bc_ind_fs, Bc_val_fs, ext_erate] = set_bcs_flow3l(GCOORD, Corner_id, Cornin_id, Point_id,ext_erate, ext_rate, boundary_condition)

switch boundary_condition
    case 'ext_rate'
        ext_erate = ext_rate/GCOORD(1,Corner_id(2));
end

% %CORNERS
%bot left
Bc_ind = [2*(Corner_id(1)-1)+1 2*(Corner_id(1)-1)+2];
Bc_val = [ext_erate*GCOORD(1,Corner_id(1)) -ext_erate*GCOORD(2,Corner_id(1)) ];

%bot right
Bc_ind = [Bc_ind 2*(Corner_id(2)-1)+1 2*(Corner_id(2)-1)+2];
Bc_val = [Bc_val ext_erate*GCOORD(1,Corner_id(2)) -ext_erate*GCOORD(2,Corner_id(2))];

%top right
Bc_ind = [Bc_ind 2*(Corner_id(3)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Corner_id(3))];
%top left
Bc_ind = [Bc_ind 2*(Corner_id(4)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Corner_id(4))];
%Remove corner nodes from segement ids
Point_id(Corner_id) = -1;

%INNER CORNERS
%layer3 right
Bc_ind = [Bc_ind 2*(Cornin_id(1)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Cornin_id(1)) ];
%layer3 left
Bc_ind = [Bc_ind 2*(Cornin_id(2)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Cornin_id(2))];
%layer6 right
Bc_ind = [Bc_ind 2*(Cornin_id(3)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Cornin_id(3))];
%layer6 left
Bc_ind = [Bc_ind 2*(Cornin_id(4)-1)+1];
Bc_val = [Bc_val ext_erate*GCOORD(1,Cornin_id(4))];

%Remove corner nodes from segement ids
Point_id(Cornin_id) = -1;



%SIDES
Bc_tmp  = find(Point_id==1);
Bc_ind  = [Bc_ind 2*(Bc_tmp-1)+2];
Bc_val  = [Bc_val -ext_erate*GCOORD(2,Bc_tmp)];

Bc_tmp  = find(Point_id==2 | Point_id==5 | Point_id==8);
Bc_ind  = [Bc_ind 2*(Bc_tmp-1)+1];
Bc_val  = [Bc_val ext_erate*GCOORD(1,Bc_tmp)];

Bc_tmp  = find(Point_id==4 | Point_id==7 | Point_id==10);
Bc_ind  = [Bc_ind 2*(Bc_tmp-1)+1];
Bc_val  = [Bc_val ext_erate*GCOORD(1,Bc_tmp)];

Bc_ind_fs = Bc_ind;
Bc_val_fs = Bc_val;

Bc_tmp  = find(Point_id==9);
Bc_ind  = [Bc_ind 2*(Bc_tmp-1)+2];
Bc_val  = [Bc_val zeros(size(Bc_tmp))];

% Bc_tmp  = find(Point_id==6); % upper edge
% Bc_ind  = [Bc_ind 2*(Bc_tmp-1)+1 2*(Bc_tmp-1)+2];
% Bc_val  = [Bc_val ext_erate*abs(GCOORD(2,Bc_tmp)) zeros(1,length(Bc_tmp))]; 


