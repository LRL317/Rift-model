function SS = random_damage(SS,nel,nip)
% SS = RANDOM_DAMAGE(SS,NEL,NIP) modifies softening functions defined in SS
% to start from a random value in the range of SS.Param(1)-SS.Param_var/2
% to SS.Param(1)+SS.Param_var/2 defined outside of the function (i.e.
% instead of starting at SS.Phi(1) the function will start in a range
% between SS.Phi(1)-SS.Phi_var/2 to SS.Phi(1)+SS.Phi_var/2). The new
% softening functions will preserve their slope so that the maximum strain
% before softening stops SS.I2_param also needs to be modified
% SS.I2_param_rand.

%--------------------------------------------------------------------------
% Function written by Elena Ross 25-06-2015.
%--------------------------------------------------------------------------
% TODO Calculate randomization also for cohesion and viscous softening

% Change random parameters so randomized distribution is not repeated
rng('shuffle');

% Calculate random field
SS.Random  =rand(nel,1);
SS.Random  = repmat(SS.Random,1,nip);

% Calculate friction angle ranges for softening functions
SS.Phi1_rand = SS.Random.*(SS.Phi_var)+(SS.Phi(1)-SS.Phi_var/2);
SS.Phi2_rand = repmat(SS.Phi(2),[size(SS.Random)]);

% Calculate accumulated strain ranges for softening functions
SS.I2_phi1_rand = repmat(SS.I2_phi(1),size(SS.Random));
SS.I2_phi2_rand = (SS.Phi2_rand-SS.Phi1_rand) ...
    .*(SS.I2_phi(2)-SS.I2_phi(1))./(SS.Phi(2)-(SS.Phi(1))) + SS.I2_phi(1);

% % Plot of the element strain softening functions (uncomment for plotting)
% plot([SS.I2_phi1_rand(:,1) SS.I2_phi2_rand(:,1)]', ...
%     ([SS.Phi1_rand(:,1) SS.Phi2_rand(:,1)].*180./pi)')
% title('Friction angle strain softening function')
% xlabel('Friction angle [Degrees]')
% ylabel('Accumulated strain')