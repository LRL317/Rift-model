% Elena Ros

function [Crust_thickness,x_ign_body,y_ign_body,in_ign_body,TRACKP_melt,tp_melt,Temp] = emplacement_dike_sill_newmesh...
    (TRACKP_melt,Temp,istep,dz_crust,GCOORD,area_melt,ext_rate,dt,Point_id,ELEM2NODE,Phases,E2all,Geo_id,K,Cp,...
    km,dF,dF_interp,T_melt,Rho_melt,igneous_body,heat_release,Crust_thickness,Dserp)

%This function calculates the place where the dike or the sill is located.
%DIKE: It will be located below the Moho and centered where the maximum
%strain rate takes place.
%SILL: It will be located below the Moho over a distance equal to the width
%of the melting area.

switch igneous_body
    %DIKE CASE ------------------------------------------------------------
    case 'dike'
       %===================== 1st part ====================================
       % Calculate the column of dike (dz_crust/2 for the Moho node 
       % where maximum strain rate takes place )
       %===================================================================
         if(dz_crust == 0) % For the cases in which the interpolation gives dz_crust=0 because is calculated from dF16 (without node7th)

            %TRACKP_melt{istep} = [NaN'; NaN'];
            TRACKP_melt = [TRACKP_melt,[NaN'; NaN'; NaN'; istep]];

            Crust_thickness(istep) = 0;
            tp_melt = 0;
            x_ign_body = NaN;
            y_ign_body = NaN;
            in_ign_body = NaN;  
            
         else   

            [Crust_thickness,xdike,ydike,indike,tp_melt,TP_xmelt,TP_ymelt,x_shallow,y_shallow,radius_tpmelt_all] = ...
                column_melt_dike_maxE2all_newmesh_belowserp(GCOORD,area_melt,ext_rate,dt,...
                Point_id,ELEM2NODE,Phases,E2all,istep,Crust_thickness,Dserp);
    
            %TRACKP_melt{istep} = [TP_xmelt(:)'; TP_ymelt(:)'];   
            TRACKP_melt = [TRACKP_melt,[TP_xmelt(:)'; TP_ymelt(:)';radius_tpmelt_all;repmat(istep,[1 length(TP_xmelt)])]]; 
            
            x_ign_body = xdike;
            y_ign_body = ydike;
            in_ign_body = indike;
 
           

      
       %===================== 2nd part ====================================
       % Calculate heat release for the column and place the mesh 
       % where new temperatures are calculated into the model mesh
       %===================================================================
             switch heat_release
                 case 'y'
%                       [Temp] = heat_release_dike(GCOORD,Temp,Geo_id,dz_crust,K,...
%                       Cp,ext_rate,dt,T_melt,Rho_melt,x_shallow,y_shallow);
                  
                       [Temp] = heat_release_dike_errorfunction_test(GCOORD,Temp,dz_crust,K,...
                      Cp,ext_rate,dt,T_melt,Rho_melt,x_shallow,y_shallow);
                 otherwise
                      disp('No heat release')
             end
         end
         
   %SILL CASE ------------------------------------------------------------       
   case 'sill'
       %===================== 1st part ====================================
       % Calculate discretized columns of the sill (dz_crust for each Moho node 
       % in the segment limited by the ends of the melt area, from xa to xb )
       %===================================================================
       if(dz_crust==0)

%           TRACKP_melt{istep} = [NaN'; NaN'];
%            TRACKP_melt = [TRACKP_melt,[NaN'; NaN';istep]];
            TRACKP_melt = [TRACKP_melt,[NaN'; NaN'; NaN'; istep]];

          Crust_thickness(istep) = 0;
          tp_melt = 0;
          x_ign_body = NaN;
          y_ign_body = NaN;
          in_ign_body = NaN;
       else   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           column_melt_sill_maxE2all_newmesh_belowserp   --- TO BE DONE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          [Crust_thickness,xsill,ysill,insill,tp_melt,TP_xmelt,TP_ymelt,dF_column3,xsort,ysort] =...
                columns_melt_sill(GCOORD,km,dF,Point_id,area_melt,dF_interp,ext_rate,dt,ELEM2NODE,Phases,E2all,istep,Crust_thickness);
          
          %TRACKP_melt{istep} = [TP_xmelt(:)'; TP_ymelt(:)'];  
          TRACKP_melt = [TRACKP_melt,[TP_xmelt(:)'; TP_ymelt(:)';NaN; repmat(istep,[1 length(TP_xmelt)])]];
          %TRACKP_melt = [TRACKP_melt,[TP_xmelt(:)'; TP_ymelt(:)';radius_tpmelt_all;repmat(istep,[1 length(TP_xmelt)])]];
           
          x_ign_body = xsill;
          y_ign_body = ysill;
          in_ign_body = insill;
                      
  

       %===================== 2nd part ====================================
       % Calculate heat release for every dF_column and place the mesh 
       % where new temperatures are calculated into the model mesh
       %===================================================================
             switch heat_release
                 case 'y'
                      [Temp] = heat_release_sill(GCOORD,dF_column3,Temp,...
                          Geo_id,K,Cp,T_melt,Rho_melt,dz_crust,ext_rate,dt,Point_id,Phases,ELEM2NODE,dF,E2all,xsort,ysort);
                      
                    % adapt the dike function to sill?: [Temp] = heat_release_SILL_errorfunction_test(GCOORD,Temp,dz_crust,K,...
                    %  Cp,ext_rate,dt,T_melt,Rho_melt,x_shallow,y_shallow);
                 otherwise
                      disp('No heat release')
             end 
       end
              
end

