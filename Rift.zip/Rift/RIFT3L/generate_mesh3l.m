function [GCOORD,ELEM2NODE, Point_id, Phase_id] = generate_mesh3l(GEOMETRY,Geo_id,Elsizes,Sgap,mode,triangle_path,modelname)

%   Part of MILAMIN: MATLAB-based FEM solver for large problems, Version 1.0
%   Copyright (C) 2007, M. Dabrowski, M. Krotkiewski, D.W. Schmid
%   University of Oslo, Physics of Geological Processes
%   http://milamin.org
%   See License file for terms of use.

%--------------------------------------------------------------------------
% Edited by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 01-07-2014. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%modelname = 'model';
pointlist   = []; 
segmentlist = [];
regionlist  = [];
holelist    = [];

pts_l = 1;
pts_u = 0;

%Loop for the boxes

BOX          = [GEOMETRY(:,Geo_id==1) GEOMETRY(:,Geo_id==2) GEOMETRY(:,Geo_id==3) GEOMETRY(:,Geo_id==4)];
no_pts       = size(BOX,2); 
pts_u        = pts_u + no_pts;
Id_seg       = [ones(1,size(find(Geo_id==1),2)-1) 2*ones(1,size(find(Geo_id==2),2)+1) 3*ones(1,size(find(Geo_id==3),2)-1) 4*ones(1,size(find(Geo_id==4),2)+1)]; 
BOX_s        = [pts_l:pts_u; pts_l+1:pts_u+1; Id_seg];
BOX_s(2,end) = pts_l;
pts_l        = pts_l+no_pts;
Layer1_id    = find(Geo_id==1);
BOX_p        = [GEOMETRY(1,Layer1_id(1))+1e-2; GEOMETRY(2,Layer1_id(1))+1e-2;1;Elsizes(1)];

pointlist    = [pointlist   BOX];
segmentlist  = [segmentlist BOX_s];
regionlist   = [regionlist  BOX_p];

%BOX 2
BOX          = [GEOMETRY(:,Geo_id==5) GEOMETRY(:,Geo_id==6) GEOMETRY(:,Geo_id==7)];
no_pts       = size(BOX,2);
pts_u        = pts_u + no_pts;
Id_seg       = [5*ones(1,size(find(Geo_id==5),2)+1) 6*ones(1,size(find(Geo_id==6),2)-1) 7*ones(1,size(find(Geo_id==7),2)+1)]; 
BOX_s        = [pts_l:pts_u; pts_l+1:pts_u+1; Id_seg(2:end)];
Layer3_id    = find(Geo_id==3);
BOX_s(2,end) = Layer3_id(end);
BOX_s        = [[Layer3_id(1); pts_l; 5]   BOX_s];
pts_l        = pts_l+no_pts;
BOX_p        = [GEOMETRY(1,Layer3_id(end))+1e-2; GEOMETRY(2,Layer3_id(end))+1e-2;2;Elsizes(2)];

pointlist    = [pointlist   BOX];
segmentlist  = [segmentlist BOX_s];
regionlist   = [regionlist  BOX_p];

%BOX 3
BOX          = [GEOMETRY(:,Geo_id==8) GEOMETRY(:,Geo_id==9) GEOMETRY(:,Geo_id==10)];
no_pts       = size(BOX,2);
pts_u        = pts_u + no_pts;
Id_seg       = [8*ones(1,size(find(Geo_id==8),2)+1) 9*ones(1,size(find(Geo_id==9),2)-1) 10*ones(1,size(find(Geo_id==10),2)+1)]; 
BOX_s        = [pts_l:pts_u; pts_l+1:pts_u+1; Id_seg(2:end)];
Layer6_id    = find(Geo_id==6);
BOX_s(2,end) = Layer6_id(end);
BOX_s        = [[Layer6_id(1); pts_l; 8]   BOX_s];
pts_l        = pts_l+no_pts;
BOX_p        = [GEOMETRY(1,Layer6_id(end))+1e-2; GEOMETRY(2,Layer6_id(end))+1e-2;3;Elsizes(3)];

pointlist    = [pointlist   BOX];
segmentlist  = [segmentlist BOX_s];
regionlist   = [regionlist  BOX_p];

% Discontinuous layers (using Sgap calculated with dis_layers)
% ------------------------------------------------------------
% Note: For this to work it is necessary that triangle is called with the
% flag -j so that repeated vertexes (intersection points) are deleted
if sum(Sgap)>=1
    [regionlist,segmentlist] = dis_layers4genmesh ...
        (pointlist,regionlist,segmentlist,Sgap,Geo_id,Elsizes);
end

% % Uncomment for plot of the segments
% for ip = 1:length(segmentlist)
%     plot(pointlist(1,segmentlist(1:2,ip)), ...
%         pointlist(2,segmentlist(1:2,ip)),'.-k');
%     hold on
% end

%TOTAL
no_pts       = size(pointlist,2);
no_seg       = size(segmentlist,2);
no_reg       = size(regionlist,2);
no_hol       = size(holelist,2);

pointlist    = [1:no_pts;pointlist];
segmentlist  = [1:no_seg;segmentlist];
regionlist   = [1:no_reg;regionlist];
holelist     = [1:no_hol;holelist];

%write triangle input file
fid     = fopen([modelname,'.poly'],'w');
fprintf(fid,'%d 2 0 0\n', no_pts);
fprintf(fid,'%d %15.12f %15.12f\n', pointlist);
fprintf(fid,'%d 1\n', no_seg);
fprintf(fid,'%d %d %d %d\n', segmentlist);
fprintf(fid,'%d\n',no_hol);
fprintf(fid,'%d %15.12f %15.12f\n', holelist);
fprintf(fid,'%d 0\n', no_reg);
fprintf(fid,'%d %15.12f %15.12f %d %15.12f\n', regionlist);
% fprintf(fid,'%d 0\n', no_reg);
% fprintf(fid,'%d %15.12f %15.12f %d\n', regionlist);
fclose(fid);

% area_glob = 1e7; %(2*pi*radius/no_pts_incl)^2;

if(strcmp(mode,'binary'))
    binary_flag = '-b';
else
    binary_flag = [];
end

% system(['triangle ',binary_flag,' -pQIo2q33Aa',num2str(area_glob,'%12.12f'),' ',modelname,'.poly']);
system([triangle_path,' ',binary_flag,' -pQIo2q33FAaj',' ',modelname,'.poly']);


if(strcmp(mode,'binary'))

    %NODES READING
    fid=fopen([modelname,'.node'], 'r');
    fseek(fid, 0, 1);
    file_size	= ftell(fid);
    fseek(fid, 0, -1);
    dummy	= fread(fid,file_size/8,'double');
    fclose(fid);

    GCOORD		= [dummy(6:4:end)';dummy(7:4:end)'];
    Point_id	= dummy(8:4:end)';

    %ELEMS READING
    fid=fopen([modelname,'.ele'], 'r');
    fseek(fid, 0, 1);
    file_size	= ftell(fid);
    fseek(fid, 0, -1);
    dummy	= fread(fid,file_size/8,'double');
    fclose(fid);

    ELEM2NODE	= [dummy(5:8:end)';dummy(6:8:end)';dummy(7:8:end)';dummy(8:8:end)';dummy(9:8:end)';dummy(10:8:end)'];
    ELEM2NODE	= int32(ELEM2NODE);
    Phase_id		= dummy(11:8:end)';

else

    %NODES READING
    fid =fopen(strcat(modelname,'.node'),'r');
    tmp = fscanf(fid,'%d',4);
    nnod = tmp(1);
    GCOORD = fscanf(fid, '%e', [4, nnod]);
    fclose(fid);

    GCOORD(1,:)   = [];
    Point_id = GCOORD(end,:);
    GCOORD(end,:) = [];

    %ELEMS READING
    fid =fopen(strcat(modelname,'.ele'),'r');
    tmp = fscanf(fid, '%d',3);
    nel = tmp(1);
    ELEM2NODE = fscanf(fid, '%d',[8, nel]);
    fclose(fid);
    Phase_id  = ELEM2NODE(end,:);
    ELEM2NODE(1,:) = [];
    ELEM2NODE(end,:) = [];
    ELEM2NODE	= int32(ELEM2NODE);

end
