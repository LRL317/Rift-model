function [Vel,Pressure,PRES_IP,TAU_xx,TAU_yy,TAU_xy,TAU_xx_old,TAU_yy_old,TAU_xy_old,STRAIN_xx,STRAIN_yy, ...
    STRAIN_xy,E2all,Mu_all,Mu_dis_all,Mu_dif_all,Mu_b_all,Dx_e,F_xx,F_xy,F_yx,F_yy,I2,GIP_x_all,GIP_y_all, ...
    THETA_all,W_xy,RHO,nw_it] = mechanical2d_cnvr(ELEM2NODE,Phases,GCOORD,Temp,E2all, ...
    Mu_all,RHEOL,Phi0,Cohesion0,R,Grain,Burger,Shearm,Rho,G,Bc_ind, ...
    Bc_val,nip,reorder,ext_erate,top_surface,Corner_id,Point_id,dt, ...
    alpha,beta,Bc_ind_fs,Bc_val_fs,SS,F_xx,F_xy,F_yx,F_yy,I2,THETA_all, ...
    TAU_xx_old,TAU_yy_old,TAU_xy_old,elasticity_s,Ce,Dpl,Dplf,nw_it, ...
    sea_level,rho_w,plasticity_t)

% MECHANICAL2D Two dimensional finite element mechanical problem solver of
% MILAMIN

%   Part of MILAMIN: MATLAB-based FEM solver for large problems, Version 1.0
%   Copyright (C) 2007, M. Dabrowski, M. Krotkiewski, D.W. Schmid
%   University of Oslo, Physics of Geological Processes
%   http://milamin.org
%   See License file for terms of use.

%   Edited by Miguel Andres-Martinez, Elena Ros-Bernabeu and Marta 
%   Perez-Gussinye. Earth Sciences Department. This version includes:
%       - Free surface agorithm
%       - Fixed diagonal terms of the Stiffnes matrix (the value was
%           previously duplicated by the code.
%       - Strain softening
%       - Elasticity
%       - Varying rheologies along a phase
%       - Plasticity based on Moresi, 2003
%       - Yield based on discontinues pressures
%       - Density dependent on temperature
%       - Dislocation and diffusion softening controlled by different
%           parameters
%       - Viscous strain softening dependent on Arrhenius equation
%           (temperature dependent)
%       - Random weak noise
%       - Sea level pressures

% TODO Linear shape functions for stress, strain and viscosities
% TODO Continuous pressure
% TODO Put viscosities in a structure and change plots
% TODO Integration point coordinate calculation into a function and remove
%   GIP from the output
% TODO scaling of the strain softening? (coded in 
%   mechanical2d_cohesion_co.m)
% TODO yielding criterium before strain softening in phi and cohesion? 
%   (coded in mechanical2d_cohesion.m)

% 05/01/2016 ER
    % Activation volume added to the flow law
% 01/05/2016 DD & MA
    % Fixed error in which the coefficients for transforming rheological
    % parameters from uniaxial/triaxial to second square invariants was
    % accumulated along the rheol-var loop
% 08/06/2016 MA
    % Strain softening in an independent function to speed up the code

%==========================================================================
% MODEL INFO
%==========================================================================
nnod        = size(GCOORD,2);
nel         = size(ELEM2NODE,2);

%==========================================================================
% CONSTANTS
%==========================================================================
ndim        = 2;
nnodel      = 7;
nedof       = nnodel*ndim;
sdof        = 2*nnod;
np          = 3;

DEV   = [ 4/3 -2/3 0;...
    -2/3  4/3 0;...
    0    0 1];


mu_max      = 1e24;
mu_min      = 1e18;
PF = 1e6*mu_max;


C1 = 4/3;
C2 = 2/3;

nelblo      = 400;
%==========================================================================
% BLOCKING PARAMETERS (nelblo must be < nel)
%==========================================================================
nelblo          = min(nel, nelblo);
nblo            = ceil(nel/nelblo);

%==========================================================================
% i) PREPARE INTEGRATION POINTS & DERIVATIVES wrt LOCAL COORDINATES
%==========================================================================
[IP_X, IP_w]    = ip_triangle(nip);
[   N, dNdu]    = shp_deriv_triangle(IP_X, nnodel);

%==========================================================================
% DECLARE VARIABLES (ALLOCATE MEMORY)
%==========================================================================
% A_all       = zeros(nedof*(nedof+1)/2,nel);
% Q_all       = zeros(nedof*np,nel);
% invM_all    = zeros(np*np,nel);
% Rhs_all     = zeros(nedof,nel);
% Tauxx       = zeros(nel,nip);
Vel         = zeros(sdof,1);
% ELEM_DOF = zeros(nedof, nel,'int32');
% ELEM_DOF(1:ndim:end,:) = ndim*(ELEM2NODE-1)+1;
% ELEM_DOF(2:ndim:end,:) = ndim*(ELEM2NODE-1)+2;

TAU_xx      = zeros(nel,nip);
TAU_yy      = zeros(nel,nip);
TAU_xy      = zeros(nel,nip);
STRAIN_xx   = zeros(nel,nip);
STRAIN_yy   = zeros(nel,nip);
STRAIN_xy   = zeros(nel,nip);
E2it        = ones(nel,nip)*ext_erate;
% Mu_all      = zeros(nel,nip);
Mu_b_all    = zeros(nel,nip);
Mu_dis_all  = zeros(nel,nip);
Mu_dif_all  = zeros(nel,nip);
MAX_TAU     = zeros(nel,nip);
PRES_IP     = zeros(nel,nip);
YIELD       = zeros(nel,nip);
F0_xx      = F_xx;
F0_xy      = F_xy;
F0_yx      = F_yx;
F0_yy      = F_yy;
I20        = I2;
W_xy        = zeros(nel,nip); % Rotation
YC          = zeros(nel,nip);
YC_old      = YC;

% Calculate parameters for strain softening
[Phi_all,Cohesion_all,Pef_dif_all,Pef_dis_all] = strain_softening_SST_rand ...
    (nip,nel,Phi0,Cohesion0,I20,PRES_IP,SS,Temp,ELEM2NODE,Phases);

%==========================================================================
% PREPARE WATER LOADS
%==========================================================================
if rho_w~=0
    % Find topography
    [Topography,Topo2nodes] = find_topo(GCOORD,ELEM2NODE,Point_id);
    % Water thickness
    Water_thick = Topography;
    Water_thick(2,:) = sea_level-Water_thick(2,:);
    Water_thick(2,Water_thick(2,:)<0) = 0;
    % Calculate water
    [F_w,Wet_el] = distr_load_hydrost(Topography,Topo2nodes,Water_thick, ...
        rho_w,GCOORD,ELEM2NODE,Point_id,Corner_id,sea_level,G);
else
    Wet_el = zeros(1,size(ELEM2NODE,2))==1;
end

%==========================================================================
% INDICES EXTRACTING LOWER PART
%==========================================================================
indx_l = tril(ones(nedof)); indx_l = indx_l(:); indx_l = indx_l==1;
ei = 0;
track_pli = 0;

while(1) %strain rate iteration
    ei       = ei +1;
    
    %======================================================================
    % FLOW SOLUTION OPTIMIZED VERSION
    %======================================================================
    %==================================================================
    % DECLARE VARIABLES (ALLOCATE MEMORY)
    %==================================================================
    nelblo      = 400;
    nelblo      = min(nel, nelblo);
    invJx       = zeros(nelblo, ndim);
    invJy       = zeros(nelblo, ndim);
    A_block     = zeros(nelblo, nedof*(nedof+1)/2);
    Q_block     = zeros(nelblo, np*nedof);
    M_block     = zeros(nelblo, np*(np+1)/2);
    invM_block  = zeros(nelblo, np*np);
    invMQ_block = zeros(nelblo, np*nedof);
    Pi_block    = zeros(nelblo, np);
    Rhs_block   = zeros(nelblo, nedof);

    A_all       = zeros(nedof*(nedof+1)/2,nel);
    Q_all       = zeros(nedof*np, nel);
    invM_all    = zeros(np*np, nel);
    Rhs_all     = zeros(nedof, nel);
        
    il          = 1;
    iu          = nelblo;
    %==================================================================
    % i) BLOCK LOOP - MATRIX COMPUTATION
    %==================================================================

    fprintf(1, 'MATRIX COMPUTATION: '); tic;
    for ib = 1:nblo
        %==============================================================
        % ii) FETCH DATA OF ELEMENTS IN BLOCK
        %==============================================================
        ECOORD_x    = reshape( GCOORD(1,ELEM2NODE(:,il:iu)), nnodel, nelblo);
        ECOORD_y    = reshape( GCOORD(2,ELEM2NODE(:,il:iu)), nnodel, nelblo);
        Temp_bl     = reshape( Temp(ELEM2NODE(:,il:iu)), nnodel, nelblo);
        
        Adis_block  = RHEOL.Adis(Phases(il:iu),:);
        Ndis_block  = RHEOL.Ndis(Phases(il:iu),:);
        Qdis_block  = RHEOL.Qdis(Phases(il:iu),:);
        Vdis_block  = RHEOL.Vdis(Phases(il:iu),:);
        
        Adif_block  = RHEOL.Adif(Phases(il:iu),:);
        Ndif_block  = RHEOL.Ndif(Phases(il:iu),:);
        Qdif_block  = RHEOL.Qdif(Phases(il:iu),:);
        Vdif_block  = RHEOL.Vdif(Phases(il:iu),:);
        
        Var_block   = RHEOL.var(il:iu,:);

        Shear_block = Shearm(Phases(il:iu));
        
        %ERho        = Rho(Phases(il:iu));
 
        %==============================================================
        % iii) INTEGRATION LOOP
        %==============================================================
        A_block(:)      = 0;
        Q_block(:)      = 0;
        M_block(:)      = 0;
        invM_block(:)   = 0;
        invMQ_block(:)  = 0;
        Rhs_block(:)    = 0;

        a23   = ECOORD_x(2,:).*ECOORD_y(3,:) - ECOORD_x(3,:).*ECOORD_y(2,:);
        a31   = ECOORD_x(3,:).*ECOORD_y(1,:) - ECOORD_x(1,:).*ECOORD_y(3,:);
        a12   = ECOORD_x(1,:).*ECOORD_y(2,:) - ECOORD_x(2,:).*ECOORD_y(1,:);
        area  = a23 + a31 + a12;

        for ip=1:nip
            
            Ni      =        N{ip};
            %Temp at integration point
            Temp_ip = (Ni'*Temp_bl)';% mean(Temp_bl,1)'; %;
            ED = zeros(nelblo,1);
            
            % Load cohesion, friction angle and viscous softening factors
            Cohesion = Cohesion_all(il:iu,ip);
            Phi = Phi_all(il:iu,ip);
            Pef_dis = Pef_dis_all(il:iu,ip);
            Pef_dif = Pef_dif_all(il:iu,ip);
            
            % TODO Take the density calculation out of the solvers
            ERho = dens_temp_Dpl(ELEM2NODE, Phases,Rho, Temp,np, Ce,il,iu, ...
                nip,ip,Dpl,Dplf);
            
            %==============================================================
            % VISCOSITY UPDATE (FIRST ITERATION)
            %==============================================================
            if(ei==1)
                if(all(Mu_all(il:iu,ip)==0))
                    E2               = mean(E2all(il:iu,:),2);
                    Sc_dis = zeros(length(il:iu),1);
                    for n = 1:size(Ndis_block,2)
                        Sc_dis = ...
                            1./(2.^((Ndis_block(:,n)-1)./Ndis_block(:,n)).* ...
                            3.^((Ndis_block(:,n)+1)./(2*Ndis_block(:,n))));
                        
                        ED = ED + Var_block(:,n).*...
                            (Sc_dis.*Adis_block(:,n).^(-1./Ndis_block(:,n)).* ...
                            E2.^(1./Ndis_block(:,n)-1).* ...
                            exp(Qdis_block(:,n)./ ...
                            (Ndis_block(:,n).*R.*(Temp_ip+273))));
                    end
                    ED = 1./((1./ED)+elasticity_s*(1./(Shear_block.*dt)));
                    ED(ED>=mu_max)   = mu_max;
                    ED(ED<=mu_min)   = mu_min;
                    Mu_all(il:iu,ip) = ED;
%                     Mu_ve = ED;
%                     Mu_ve_all(il:iu,ip) = Mu_ve;
                else
                    ED = Mu_all(il:iu,ip);
%                     Mu_ve = Mu_ve_all(il:iu,ip);
                end
            else
                                 
                %==========================================================
                % VISCOSITY
                %==========================================================
                % Load the strain rate of the previous iteration
                E2               =  E2all(il:iu,ip);
                
                % Initialize Mu_dis_block and Mu_dif_block
                Mu_dis_block = zeros(length(il:iu),1);
                Mu_dif_block = zeros(length(il:iu),1);
                Sc_dis = zeros(length(il:iu),1);
                Sc_dif = zeros(length(il:iu),1);
                
                % Loop for rheologic variation in the same phase
                for n = 1:size(Ndis_block,2)
                    % Factors for scaling triaxial and uniaxial experiment
                    % parameters (GERYA 2010)
                    Sc_dis = ...
                        1./(2.^((Ndis_block(:,n)-1)./Ndis_block(:,n)).* ...
                        3.^((Ndis_block(:,n)+1)./(2*Ndis_block(:,n))));
                    Sc_dif = 1/3;
                    
                    % Dislocation creep
                    Mu_dis_block = Mu_dis_block + Var_block(:,n).* ...
                        (Sc_dis.*(Pef_dis.*Adis_block(:,n)).^(-1./Ndis_block(:,n)) ...
                        .* E2.^(1./Ndis_block(:,n)-1) ...
                        .* exp((Qdis_block(:,n) + PRES_IP(il:iu,ip).*Vdis_block(:,n)) ...
                        ./(Ndis_block(:,n).*R.*(Temp_ip+273))));
                    % Diffusion creep
                    Mu_dif_block = Mu_dif_block + Var_block(:,n).* ...
                        (Sc_dif.*(Pef_dif.*Adif_block(:,n)).^(-1./Ndif_block(:,n)) ...
                        .* (Grain/Burger).^0 ...
                        .* exp((Qdif_block(:,n)+PRES_IP(il:iu,ip).*Vdif_block(:,n)) ...
                        ./(Ndif_block(:,n).*R.*(Temp_ip+273))));
                end
                                                
                % Effective viscosity
                ED(Ndif_block(:,1)~=0) = (1./Mu_dis_block(Ndif_block(:,1)~=0) ...
                    + 1./Mu_dif_block(Ndif_block(:,1)~=0) ...                
                    + elasticity_s*(1./(Shear_block(Ndif_block(:,1)~=0).*dt))...
                    ).^-1;
                 %+ 1./Mu_brittle(Ndif_block(:,1)~=0) ...
                ED(Ndif_block(:,1)==0) = (1./Mu_dis_block(Ndif_block(:,1)==0) ...
                    + elasticity_s*(1./(Shear_block(Ndif_block(:,1)==0).*dt))...
                    ).^-1;
                %+ 1./Mu_brittle(Ndif_block(:,1)==0) ...
                
                % Limit viscosities
                ED(ED<=mu_min)   = mu_min;               
                ED(ED>mu_max)   = mu_max;
                
%                 % Visco-elastic
%                 Mu_ve = ED;
                
                %==========================================================
                % PLASTICITY
                %==========================================================
                % Pressures at the ips
                Pres_ip_block = PRES_IP(il:iu,ip);
                
                % Yield stress
                T2_yield = Pres_ip_block.*sin(Phi)+Cohesion;
                T2_yield(T2_yield < Cohesion) = Cohesion(T2_yield < Cohesion);
                
                
                switch plasticity_t
                    case 'moresi'
                        %ED_old = ED;
                        T2old = sqrt(0.5*(TAU_xx_old(il:iu,ip).^2 + TAU_yy_old(il:iu,ip).^2) + TAU_xy_old(il:iu,ip).^2);
                        
                        % Forecasting new stresses with previous iteration strain
                        % rates and current viscosity
                        Txx_block_f = 4/3.*ED.*STRAIN_xx(il:iu,ip) ...
                            -2/3.*ED.*STRAIN_yy(il:iu,ip) + ...
                            2.*ED.*THETA_all(il:iu,ip).*TAU_xx_old(il:iu,ip);
                        Tyy_block_f = -2/3.*ED.*STRAIN_xx(il:iu,ip) ...
                            + 4/3.*ED.*STRAIN_yy(il:iu,ip) ...
                            + 2.*ED.*THETA_all(il:iu,ip).*TAU_yy_old(il:iu,ip);
                        Txy_block_f = 2.*ED.*STRAIN_xy(il:iu,ip) + ...
                            2.*ED.*THETA_all(il:iu,ip).*TAU_xy_old(il:iu,ip);
                        T2forecast = sqrt(0.5*(Txx_block_f.^2 + Tyy_block_f.^2) ...
                            + Txy_block_f.^2);
                        
                        % Yield criterium
                        % No memory for plasticity:
                        YC(il:iu,ip) = T2forecast>T2_yield;
                        % Memory of plasticity (uncomment):
                        %YC(il:iu,ip) = T2forecast>T2_yield | YC(il:iu,ip);
                        YC_block = YC(il:iu,ip);
                        
                        % Ductile viscosity
                        Yield_b           = T2_yield;
                        
                        % Calculate E2eff as in Eq. 35, Moresi, 2003
                        E_eff_xx = 2.*STRAIN_xx(il:iu,ip) ...
                            + 1./(Shear_block.*dt).*TAU_xx_old(il:iu,ip);
                        E_eff_yy = 2.*STRAIN_yy(il:iu,ip) ...
                            + 1./(Shear_block.*dt).*TAU_yy_old(il:iu,ip);
                        E_eff_xy = 2.*STRAIN_xy(il:iu,ip) ...
                            + 1./(Shear_block.*dt).*TAU_xy_old(il:iu,ip);
                        E2eff = sqrt(0.5*(E_eff_xx.^2+E_eff_yy.^2)+E_eff_xy.^2);
                        
                        Mu_brittle = Yield_b./E2eff;
                        
                        %ED(YC_block~=0 & T2old~=0) = Mu_brittle(YC_block~=0 & T2old~=0);
                        ED(YC_block~=0) = Mu_brittle(YC_block~=0);
                        
                    case 'maxwell'
                        Mu_brittle = T2_yield./(2.*E2);
                        ED1 = (1./ED + 1./Mu_brittle).^-1;
                        ED = ED.*Mu_brittle./(ED+Mu_brittle);
                    case 'no'
                        Mu_brittle = 0;
                end
                    % Limit viscosities
                    ED(ED<=mu_min)   = mu_min;
                    ED(ED>mu_max)   = mu_max;
                    
%                     % Update old stresses
%                     TAU_xx_old_b = TAU_xx_old(il:iu,ip);
%                     TAU_xx_old_b(YC_block~=0 & TAU_block~=0) = TAU_xx_old_b(YC_block~=0 & TAU_block~=0).*Yield_b(YC_block~=0 & TAU_block~=0)./TAU_block(YC_block~=0 & TAU_block~=0);
%                     TAU_xx_old(il:iu,ip) = TAU_xx_old_b;
%                     
%                     TAU_yy_old_b = TAU_yy_old(il:iu,ip);
%                     TAU_yy_old_b(YC_block~=0 & TAU_block~=0) = TAU_yy_old_b(YC_block~=0 & TAU_block~=0).*Yield_b(YC_block~=0 & TAU_block~=0)./TAU_block(YC_block~=0 & TAU_block~=0);
%                     TAU_yy_old(il:iu,ip) = TAU_yy_old_b;
%                     
%                     TAU_xy_old_b = TAU_xy_old(il:iu,ip);
%                     TAU_xy_old_b(YC_block~=0 & TAU_block~=0) = TAU_xy_old_b(YC_block~=0 & TAU_block~=0).*Yield_b(YC_block~=0 & TAU_block~=0)./TAU_block(YC_block~=0 & TAU_block~=0);
%                     TAU_xy_old(il:iu,ip) = TAU_xy_old_b;
                    
%                     track_pli = max([track_pli,pli]);
%                     pli = pli+1;
                %end
                
                % Save viscosities
                Mu_all(il:iu,ip) = ED;
%                 Mu_ve_all(il:iu,ip) = Mu_ve;
                Mu_b_all(il:iu,ip) = Mu_brittle;
                Mu_dis_all(il:iu,ip) = Mu_dis_block;
                Mu_dif_all(il:iu,ip) = Mu_dif_block;
            end
            
            % Calculates the factors for the elasticity
            Etheta     = elasticity_s*1./(2.*Shear_block.*dt);
            THETA_all(il:iu,ip) = Etheta;
            RHO(il:iu,ip) = ERho(:);
            
            %==========================================================
            % iv) LOAD SHAPE FUNCTIONS DERIVATIVES FOR INTEGRATION POINT
            %==========================================================
            dNdui   =     dNdu{ip};
            GIP_x   = Ni'*ECOORD_x;
            GIP_y   = Ni'*ECOORD_y;

            tmp   = ECOORD_x(3,:).*GIP_y - GIP_x.*ECOORD_y(3,:);
            eta1  = a23 + tmp + ECOORD_y(2,:).*GIP_x - GIP_y.*ECOORD_x(2,:);
            eta2  = a31 - tmp + ECOORD_x(1,:).*GIP_y - GIP_x.*ECOORD_y(1,:);

            Pi_block(:,1) = eta1./area;
            Pi_block(:,2) = eta2./area;
            Pi_block(:,3) = 1 - Pi_block(:,1) - Pi_block(:,2);

            %==========================================================
            % v) CALCULATE JACOBIAN, ITS DETERMINANT AND INVERSE
            %==========================================================
            Jx          = ECOORD_x'*dNdui;
            Jy          = ECOORD_y'*dNdui;
            detJ        = Jx(:,1).*Jy(:,2) - Jx(:,2).*Jy(:,1);

            invdetJ     = 1.0./detJ;
            invJx(:,1)  = +Jy(:,2).*invdetJ;
            invJx(:,2)  = -Jy(:,1).*invdetJ;
            invJy(:,1)  = -Jx(:,2).*invdetJ;
            invJy(:,2)  = +Jx(:,1).*invdetJ;

            %==========================================================
            % vi) DERIVATIVES wrt GLOBAL COORDINATES
            %==========================================================
            dNdx        = invJx*dNdui';
            dNdy        = invJy*dNdui';

            %==========================================================
            % vii) NUMERICAL INTEGRATION OF ELEMENT MATRICES
            %==========================================================
            weight      = IP_w(ip)*detJ;
            weightD     =    weight.*ED;
            % ------------------------A matrix-------------------------
            indx  = 1;
            for i = 1:nnodel
                % x-velocity equation
                for j = i:nnodel
                    A_block(:,indx) = A_block(:,indx) + ( C1.*dNdx(:,i).*dNdx(:,j) + dNdy(:,i).*dNdy(:,j)).*weightD;
                    indx = indx+1;
                    A_block(:,indx) = A_block(:,indx) + (-C2.*dNdx(:,i).*dNdy(:,j) + dNdy(:,i).*dNdx(:,j)).*weightD;
                    indx = indx+1;
                end
                % y-velocity equation
                for j = i:nnodel
                    if(j>i)
                        A_block(:,indx) = A_block(:,indx) + (-C2.*dNdy(:,i).*dNdx(:,j) + dNdx(:,i).*dNdy(:,j)).*weightD;
                        indx = indx+1;
                    end
                    A_block(:,indx) = A_block(:,indx) + ( C1.*dNdy(:,i).*dNdy(:,j) + dNdx(:,i).*dNdx(:,j)).*weightD;
                    indx = indx+1;
                end
            end

            % ------------------------Q matrix-------------------------
            for i=1:np
                TMP1 = weight.*Pi_block(:,i);
                TMP2 = TMP1(:,ones(1,nnodel));
                Q_block(:,(i-1)*nedof + (1:2:nedof)) =  Q_block(:,(i-1)*nedof + (1:2:nedof)) - TMP2.*dNdx;
                Q_block(:,(i-1)*nedof + (2:2:nedof)) =  Q_block(:,(i-1)*nedof + (2:2:nedof)) - TMP2.*dNdy;
            end

            % ------------------------M matrix-------------------------
            indx = 1;
            for i = 1:np
                for j = i:np
                    M_block(:,indx) = M_block(:,indx) + weight.*Pi_block(:,i).*Pi_block(:,j);
                    indx = indx + 1;
                end
            end

            % -----------------------Rhs vector------------------------
            Rhs_block(:,1:2:nedof) = Rhs_block(:,1:2:nedof) + G(1)*(ERho.*weight)*Ni' ...
                - dNdx.*repmat(2.*ED.*Etheta.*TAU_xx_old(il:iu,ip).*weight,[1,nnodel])...
                - dNdy.*repmat(2.*ED.*Etheta.*TAU_xy_old(il:iu,ip).*weight,[1,nnodel]);
            Rhs_block(:,2:2:nedof) = Rhs_block(:,2:2:nedof) + G(2)*(ERho.*weight)*Ni' ...
                - dNdy.*repmat(2.*ED.*Etheta.*TAU_yy_old(il:iu,ip).*weight,[1,nnodel])...
                - dNdx.*repmat(2.*ED.*Etheta.*TAU_xy_old(il:iu,ip).*weight,[1,nnodel]);

        end

        %==============================================================
        % viii) STATIC CONDENSATION
        %==============================================================

        % --------------------------invM-------------------------------
        TMP     = 1./area';
        M_block = M_block.*TMP(:,ones(1,np*(np+1)/2));

        detM_block = M_block(:,1).*(M_block(:,4).*M_block(:,6) - M_block(:,5).*M_block(:,5)) + ...
            M_block(:,2).*(M_block(:,5).*M_block(:,3) - M_block(:,2).*M_block(:,6)) + ...
            M_block(:,3).*(M_block(:,2).*M_block(:,5) - M_block(:,4).*M_block(:,3));

        detM_block = detM_block./TMP;
        invM_block(:,1) = (M_block(:,4).*M_block(:,6) - M_block(:,5).*M_block(:,5))./detM_block;
        invM_block(:,2) = (M_block(:,5).*M_block(:,3) - M_block(:,2).*M_block(:,6))./detM_block;
        invM_block(:,3) = (M_block(:,2).*M_block(:,5) - M_block(:,4).*M_block(:,3))./detM_block;
        invM_block(:,4) = invM_block(:,2);
        invM_block(:,5) = (M_block(:,1).*M_block(:,6) - M_block(:,3).*M_block(:,3))./detM_block;
        invM_block(:,6) = (M_block(:,2).*M_block(:,3) - M_block(:,1).*M_block(:,5))./detM_block;
        invM_block(:,7) = invM_block(:,3);
        invM_block(:,8) = invM_block(:,6);
        invM_block(:,9) = (M_block(:,1).*M_block(:,4) - M_block(:,5).*M_block(:,5))./detM_block;

        % --------------------------invM*Q'----------------------------
        for i=1:np
            for j=1:nedof
                for k=1:np
                    invMQ_block(:,(i-1)*nedof+j) = invMQ_block(:,(i-1)*nedof+j) + invM_block(:,(i-1)*np+k).*Q_block(:,(k-1)*nedof+j);
                end
            end
        end

        % -------------------A = A + PF*Q'*invM*Q'---------------------
        indx = 1;
        for i=1:nedof
            for j=i:nedof
                for k=1:np
                    A_block(:,indx) = A_block(:,indx) + PF*Q_block(:,(k-1)*nedof+i).*invMQ_block(:,(k-1)*nedof+j);
                end
                indx = indx + 1;
            end
        end

        %==============================================================
        % ix) WRITE DATA INTO GLOBAL STORAGE
        %==============================================================
        A_all(:,il:iu)  = A_block';
        Q_all(:,il:iu)  = Q_block';
        invM_all(:,il:iu)  = invM_block';
        Rhs_all(:,il:iu)  = Rhs_block';

        %==============================================================
        % READJUST START, END AND SIZE OF BLOCK. REALLOCATE MEMORY
        %==============================================================
        il  = il+nelblo;
        if(ib==nblo-1)
            nelblo 	   = nel-iu;
            A_block = zeros(nelblo, nedof*(nedof+1)/2);
            Q_block = zeros(nelblo, np*nedof);
            M_block = zeros(nelblo, np*(np+1)/2);
            invM_block = zeros(nelblo, np*np);
            invMQ_block = zeros(nelblo, np*nedof);
            Pi_block  = zeros(nelblo, np);
            Rhs_block = zeros(nelblo, nedof);
            invJx      = zeros(nelblo, ndim);
            invJy      = zeros(nelblo, ndim);
        end
        iu  = iu+nelblo;
    end
    fprintf(1, [num2str(toc),'\n']);


    %======================================================================
    % ix) CREATE TRIPLET FORMAT INDICES
    %======================================================================
    tic; fprintf(1, 'TRIPLET INDICES:    ');
    %A matrix
    ELEM_DOF = zeros(nedof, nel,'int32');
    ELEM_DOF(1:ndim:end,:) = ndim*(ELEM2NODE-1)+1;
    ELEM_DOF(2:ndim:end,:) = ndim*(ELEM2NODE-1)+2;
    indx_j = repmat(1:nedof,nedof,1); indx_i = indx_j';
    indx_i = tril(indx_i); indx_i = indx_i(:); indx_i = indx_i(indx_i>0);
    indx_j = tril(indx_j); indx_j = indx_j(:); indx_j = indx_j(indx_j>0);

    A_i = ELEM_DOF(indx_i(:),:);
    A_j = ELEM_DOF(indx_j(:),:);

    indx       = A_i < A_j;
    tmp        = A_j(indx);
    A_j(indx)  = A_i(indx);
    A_i(indx)  = tmp;

    %Q matrix
    Q_i = repmat(int32(1:nel*np),nedof,1);
    Q_j = repmat(ELEM_DOF,np,1);

    %invM matrix
    indx_j = repmat(1:np,np,1); indx_i = indx_j';
    invM_i = reshape(int32(1:nel*np),np, nel);
    invM_j = invM_i(indx_i,:);
    invM_i = invM_i(indx_j,:);

    fprintf(1, [num2str(toc),'\n']);

    %======================================================================
    % x) CONVERT TRIPLET DATA TO SPARSE MATRIX
    %======================================================================
    
    %clear blocl variables
    clear 'Q_block' 'A_block' 'invMQ_block' 'Rhs_block'
    fprintf(1, 'SPARSIFICATION:     '); tic
    A    = sparse2(A_i(:)   ,    A_j(:),    A_all(:));
    Q    = sparse2(Q_i(:)   ,    Q_j(:),    Q_all(:));
    invM = sparse2(invM_i(:), invM_j(:), invM_all(:));
    Rhs  = accumarray(ELEM_DOF(:), Rhs_all(:));
    clear A_i A_j A_all Q_i Q_j Q_all invM_i invM_j invM_all Rhs_all;
    fprintf(1, [num2str(toc),'\n']);
    
%     ind_Asparse_example = find(A~=0); % Uncomment this for plotting the
%         % elements of the matrix A. Set a break point in 'Break point
%         % here'.
%     
%     [iAsparse,jAsparse] = ind2sub(size(A),ind_Asparse_example);
%     figure(3)
%     plot(jAsparse,iAsparse,'.');
%     xlabel('J')
%     ylabel('I')
%     axis ij 
%     % Break point here
    
    %======================================================================
    % ADD WATER LOAD
    %======================================================================
    if rho_w~=0
        Rhs = Rhs + F_w;
    end
    
%     %======================================================================
%     % CONVERGENCE CRITERIUM PREVIUS STEP (SPIEGELMAN)
%     %======================================================================
%     if ei>1
%         if ei==2
%             Residue = [];
%         end
%         PRESS = Pressure(:);
%         
%         AA = A + cs_transpose(A) - diag(diag(A));
%         % New_stiffness*old_vel-old_rhs
%         Residue(end+1) = max(max(abs([AA cs_transpose(Q)]*[Vel; PRESS]-Rhs)));
%         disp(['Residue = ',num2str(Residue(end))])
%     end
%     Rhs_old = Rhs;

    %======================================================================
    % SWITCH FOR THE BOUNDARY CONDITIONS
    %======================================================================

    switch top_surface
        case 'fix'    
            %==============================================================
            % BOUNDARY CONDITIONS FOR A FIXED TOP SURFACE
            %==============================================================
            fprintf(1, 'BDRY CONDITIONS:    '); tic;
            Free        = 1:sdof;
            Free(Bc_ind)= [];
            A_BC_UPPER = transpose(A);
            A_BC_UPPER = A_BC_UPPER - diag(diag(A_BC_UPPER));
            TMP         = A(:,Bc_ind) + A_BC_UPPER(:,Bc_ind);
            %TMP         = A(:,Bc_ind) + cs_transpose(A(Bc_ind,:));
            Rhs         = Rhs - TMP*Bc_val';
            A           = A(Free,Free);
            fprintf(1, [num2str(toc),'\n']);
            Dx_e = 0;

            %==============================================================
            % REORDERING
            %==============================================================
            fprintf(1, 'REORDERING:         '); tic;
            switch reorder
                case 'metis'
                    perm = metis(A);
                case 'amd'
                    perm = amd(A);
                otherwise
                    error('Unknown reordering')
            end
            fprintf(1, [num2str(toc),'\n']);

            %==============================================================
            % FACTORIZATION - ideally L = lchol(K, perm)
            %==============================================================
            fprintf(1, 'FACTORIZATION:      '); tic;
            A = cs_transpose(A);
            A = cs_symperm(A,perm);
            A = cs_transpose(A);
            L = lchol(A);
            fprintf(1, [num2str(toc,'%8.6f'),'\n']);

            %==============================================================
            % POWELL-HESTENES ITERATIONS - UZAWA-like - PRESSURE
            %==============================================================
            tic
            div_max_uz  = 1e-16; div_max     = realmax;
            uz_iter     =     0; uz_iter_max =       5;

            Pressure    = zeros(nel*np, 1);
            Vel         = zeros(sdof  , 1);
            Vel(Bc_ind) = Bc_val;

            while (uz_iter<uz_iter_max) %div_max>div_max_uz  && 
                uz_iter         = uz_iter + 1;
                Vel(Free(perm)) = cs_ltsolve(L,cs_lsolve(L,Rhs(Free(perm))));          %BACK & FORWARD SUBS
                Div             = invM*(Q*Vel);                                        %COMPUTE QUASI-DIVERGENCE
                Rhs             = Rhs - PF*(Q'*Div);                                   %UPDATE RHS
                Pressure        = Pressure + PF*Div;                                   %UPDATE TOTAL PRESSURE (negative sign convention)
                div_max         = max(abs(Div(:)));                                    %CHECK INCOMPRESSIBILITY
                disp([' PH_ITER: ', num2str(uz_iter), ' ', num2str(div_max)]);
            end
            Pressure = reshape(Pressure,np, nel);
            fprintf(1, 'P-H ITERATIONS:     ');
            fprintf(1, [num2str(toc,'%8.6f'),'\n']);   
            
        case 'fs'
    
            %==============================================================
            % BOUNDARY CONDITIONS FOR A FREE SURFACE
            %==============================================================
            fprintf(1, 'BDRY CONDITIONS:    '); tic;
                        
            %______________________________________________________________
            %                 Top_nodes x
            %     x-----x-----x-----x-----x-----x-----x-----x-----x Surface
            %                  \Top_elem3/ \Top_elem3/
            %                   \       /   \       /
            %                    o     o     o     o
            %                     \   /       \   /
            %                      \ /         \ /
            %                       o           o
            %
            %______________________________________________________________
            
            Point_id(Corner_id(3:4)) = max(Point_id)-1;
                % Change the id of the superior corners of the model from 
                % -1 to , the id of the top surface.
            nnod_el_fs = 3; % Number of superficial nodes in the element.
            Top_nodes = find(Point_id==max(Point_id)-1); 
                % Indexes of the top nodes.
            Top_elem3 = find(sum(ismember(ELEM2NODE,Top_nodes),1)==...
                nnod_el_fs);
                % Top element indexes with 3 nodes on the surface.
            nip_fs = 3; % Number of integration points.
            % Water density vector with value 0 where no water loads the
            % element, and rho_w where the element is loaded
            Rho_w = Wet_el(Top_elem3)'*rho_w;
            inc_rho = Rho(Phases(Top_elem3))-Rho_w; 
            % Increment of the density.
            Ip_fs = [-sqrt(3/5), 0, sqrt(3/5)]; % Integration points
            Ipw_fs = [5/9; 8/9; 5/9]; % Integration weight
            [N_fs] = shp_line_int(Ip_fs, nnod_el_fs); % Shape functions
            
            AX_I_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of indexes i for the free surface elements in the
                % x component.
            AX_J_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of indexes j for the free surface elements in the
                % x component. i.e. (3*3, elements on top) 
            AX_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of values for the correction of the matrix A for
                % the free surface in the x component.
            AY_I_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of indexes i for the free surface elements in the
                % y component.
            AY_J_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of indexes j for the free surface elements in the
                % y component.
            AY_FS = zeros(nnod_el_fs*nnod_el_fs,size(Top_elem3,2));
                % Matrix of values for the correction of the matrix A for
                % the free surface in the y component.
           
            Dx_e = zeros(size(Top_elem3,2),1); % Vector for store
                % superficial dx of the superfitial elements for the
                % Courant time step criterium.
            
            F_fs = zeros(sdof, 1);
                % Vector of the values for the correction of the Rhs for
                % the free surface.
                        
            for i = 1:size(Top_elem3,2) % Loop for each superficial element
                Lo_nodes_fs = Point_id(ELEM2NODE(1:6,Top_elem3(i)))==max(Point_id)-1;
                    % Local indexes of the superficial nodes.
                Gl_nodes_fs = ELEM2NODE(Lo_nodes_fs,Top_elem3(i));
                    % Global indexes of the supercitial nodes.
 
                [Xorder, Xindex] = sort(GCOORD(1,Gl_nodes_fs)); % Orders
                    % the surface elements in increasing value.
                Gl_nodes_fs = Gl_nodes_fs(Xindex); % Reorder the global
                    % node indexes.
                Dx_e(i) = (max(Xorder)-min(Xorder)); % Calculate dx.
                h_fs = GCOORD(2,Gl_nodes_fs); % Heights of the nodes.
                dhdx = (h_fs(end)-h_fs(1))/Dx_e(i); % Slope at each node.
                    
                Ax_ie = (2*double(Gl_nodes_fs))*ones(1,nnod_el_fs); 
                    % Indexes i for the matrix Ax_fse of the evaluated
                    % element for the x component.
                Ay_ie = (2*double(Gl_nodes_fs))*ones(1,nnod_el_fs); % Indexes
                    % i for the matrix Ay_fse of the evaluated element for
                    % the y component.
                Ax_ie = Ax_ie(:);
                Ay_ie = Ay_ie(:);
                Ax_je = ones(nnod_el_fs,1)*(2*double(Gl_nodes_fs)-1)';
                    % Indexes j for the matrix Ax_fse of the evaluated
                    % element for the x component.
                Ay_je = ones(nnod_el_fs,1)*2*double(Gl_nodes_fs)'; 
                    % Indexes j for the matrix Ay_fse of the evaluated
                    % element for the y component.
                Ax_je = Ax_je(:);
                Ay_je = Ay_je(:);
                F_index = 2*double(Gl_nodes_fs); % Indexes for the vector F
                
                % Initialize the matrices for the correction of A and F for
                % each element.
                Ax_fse = zeros(nnod_el_fs,nnod_el_fs);
                Ay_fse = zeros(nnod_el_fs,nnod_el_fs);
                F_fse =  zeros(nnod_el_fs,1);
                
                for ip_fs = 1:nip_fs % Integration loop
                    Ax_fse = Ax_fse + N_fs{ip_fs}*N_fs{ip_fs}'*...
                        Ipw_fs(ip_fs)*Dx_e(i)/2; % Ni*Nj*w*dx                   
                    Ay_fse = Ay_fse + N_fs{ip_fs}*N_fs{ip_fs}'*...
                        Ipw_fs(ip_fs)*Dx_e(i)/2; % Ni*Nj*w*dx
                    F_fse = F_fse + N_fs{ip_fs}*Ipw_fs(ip_fs)*Dx_e(i)/2; 
                        % Ni*w*dx
                end

                Ax_fse_col = Ax_fse(:)*inc_rho(i)*G(2)*alpha*beta*-(dhdx)*dt;
                    % Afs for x = inc_density*g*beta*dhdx*dt*integral(Ni*Nj*dx)
                Ay_fse_col = Ay_fse(:)*inc_rho(i)*G(2)*alpha*dt; 
                    % Afs for y = inc_density*g*alpha*dt*integral(Ni*Nj*dx)
                    
                % Fills the global matrices for the free surface correction
                AY_I_FS(:,i) = Ay_ie;
                AY_J_FS(:,i) = Ay_je;
                AY_FS(:,i) = Ay_fse_col;
                
                AX_I_FS(:,i) = Ax_ie;
                AX_J_FS(:,i) = Ax_je;
                AX_FS(:,i) = Ax_fse_col;
                
                F_fs(F_index) = 0; %F_fse(:).*h_fs'*inc_rho*G(2);
                    % Ffs = inc_density*g*h*integral(Ni*dx)
                
            end
            
            
            % Delete the non-diagonal terms of the local matrices
                    % matrices for the 3 surficial nodes of each surficial element
                    %
                    %  / k1  k4  k7 \   Remove           / k1         \
                    % |  k2  k5  k8  |  non-diagonal => |  k2  k5      |
                    %  \ k3  k6  k9 /   terms            \ k3  k6  k9 /
                    
                    V_rm = AY_J_FS(:)>AY_I_FS(:); % Vector for removing the elements
                    % of the matrix A_FS which j>i.
                    AY_FS(V_rm) = [];
                    AY_I_FS(V_rm) = [];
                    AY_J_FS(V_rm) = [];
                        
            AX_FS_SPARSE = sparse2(AX_I_FS, AX_J_FS, AX_FS, sdof, sdof); 
                % Sparsification of AX_FS.
            AY_FS_SPARSE = sparse2(AY_I_FS, AY_J_FS, AY_FS, sdof, sdof); 
                % Sparsification of AY_FS
            
            A = A - AY_FS_SPARSE; % Subtracts to A the symmetric part of 
                % the free surface correction.
            
            Free        = 1:sdof;
            Free(Bc_ind_fs)= []; % Boundary conditions without taking into
                % account the free surface.
            A_BC_UPPER = cs_transpose(A);
            A_BC_UPPER = A_BC_UPPER - diag(diag(A_BC_UPPER));
            TMP         = A(:,Bc_ind_fs) + A_BC_UPPER(:,Bc_ind_fs);
            Rhs         = Rhs - TMP*Bc_val_fs';
            A           = A(Free,Free);
                
            fprintf(1, [num2str(toc),'\n']);
            
%     ind_Asparse_example = find(A~=0); % Uncomment this for plotting the
%         % elements of the matrix A. Set a break point in 'Break point
%         % here'.
%     
%     [iAsparse,jAsparse] = ind2sub(size(A),ind_Asparse_example);
%     figure(4)
%     plot(jAsparse,iAsparse,'.');
%     xlabel('J')
%     ylabel('I')
%     axis ij 
%     % Break point here
            
            %==============================================================
            % REORDERING
            %==============================================================
            fprintf(1, 'REORDERING:         '); tic;
            switch reorder
                case 'metis'
                    perm = metis(A);
                case 'amd'
                    perm = amd(A);
                otherwise
                    error('Unknown reordering')
            end
            fprintf(1, [num2str(toc),'\n']);

            %==============================================================
            % FACTORIZATION - ideally L = lchol(K, perm)
            %==============================================================
            fprintf(1, 'FACTORIZATION:      '); tic;
            A = cs_transpose(A);
            A = cs_symperm(A,perm);
            A = cs_transpose(A);
            L = lchol(A);
            fprintf(1, [num2str(toc,'%8.6f'),'\n']);

            %==============================================================
            % POWELL-HESTENES ITERATIONS - UZAWA-like - PRESSURE
            %==============================================================
            if beta > 0
                tic
                div_max_uz  = 1e-16; div_max     = realmax;
                uz_iter     =     0; uz_iter_max =       5;
                fs_iter     =     0; fs_iter_max =       10;
                
                Pressure    = zeros(nel*np, 1);
                Vel         = zeros(sdof  , 1);
                Vel(Bc_ind_fs) = Bc_val_fs;
                Vel_sav = zeros(sdof,fs_iter_max);
                vel_dif = 0;
                
                Rhs0 = Rhs;
                
                while fs_iter<fs_iter_max
                    fs_iter = fs_iter+1;
                    Rhs = Rhs0 + AX_FS_SPARSE*Vel;
                    uz_iter = 0;
                    
                    while (uz_iter<uz_iter_max) %div_max>div_max_uz  &&
                        uz_iter         = uz_iter + 1;
                        Vel(Free(perm)) = cs_ltsolve(L,cs_lsolve(L,Rhs(Free(perm))));
                        %BACK & FORWARD SUBS
                        Div             = invM*(Q*Vel);
                        %COMPUTE QUASI-DIVERGENCE
                        Rhs             = Rhs - PF*(Q'*Div);
                        %UPDATE RHS
                        Pressure        = Pressure + PF*Div;
                        %UPDATE TOTAL PRESSURE (negative sign convention)
                        div_max         = max(abs(Div(:)));
                        %CHECK INCOMPRESSIBILITY
                        %disp([' PH_ITER: ', num2str(uz_iter), ' ', num2str(div_max)]);
                        % In order to check convergence uncomment the
                        % following:
                        if uz_iter==uz_iter_max;
                            Vel_sav(:,fs_iter) = Vel;
                        end
                    end
                    if fs_iter>1
                        vel_dif = max(abs(Vel_sav(:,fs_iter)-Vel_sav(:,fs_iter-1)));
                    end
                    disp([' FS_ITER: ', num2str(fs_iter), ' ', num2str(div_max),' Vel diff: ',num2str(vel_dif)]);
                end
                Pressure = reshape(Pressure,np, nel);
                fprintf(1, 'P-H ITERATIONS:     ');
                fprintf(1, [num2str(toc,'%8.6f'),'\n']);
                
            else % If beta = 0
                tic
                div_max_uz  = 1e-16; div_max     = realmax;
                uz_iter     =     0; uz_iter_max =       5;
                
                Pressure    = zeros(nel*np, 1);
                Vel         = zeros(sdof  , 1);
                Vel(Bc_ind_fs) = Bc_val_fs;
                
                while (uz_iter<uz_iter_max) %div_max>div_max_uz  &&
                    uz_iter         = uz_iter + 1;
                    Vel(Free(perm)) = cs_ltsolve(L,cs_lsolve(L,Rhs(Free(perm))));
                    %BACK & FORWARD SUBS
                    Div             = invM*(Q*Vel);
                    %COMPUTE QUASI-DIVERGENCE
                    Rhs             = Rhs - PF*(Q'*Div);
                    %UPDATE RHS
                    Pressure        = Pressure + PF*Div;
                    %UPDATE TOTAL PRESSURE (negative sign convention)
                    div_max         = max(abs(Div(:)));
                    %CHECK INCOMPRESSIBILITY
                    disp([' PH_ITER: ', num2str(uz_iter), ' ', num2str(div_max)]);
                    % In order to check convergence uncomment the
                    % following:
                    %                         if uz_iter==uz_iter_max;
                    %                             Vel_sav(:,fs_iter) = Vel;
                    %                         end
                end
                Pressure = reshape(Pressure,np, nel);
                fprintf(1, 'P-H ITERATIONS:     ');
                fprintf(1, [num2str(toc,'%8.6f'),'\n']);
            end
    end
    
    %======================================================================
    % UPDATE STRESS AND STRAINS
    %======================================================================

    tic
    
    %======================================================================
    % SMOOTH PRESSURES
    %======================================================================
    % Pc = el2nod_pressure(GCOORD,ELEM2NODE,nel,Pressure);
    
    %======================================================================
    % DECLARE VARIABLES (ALLOCATE MEMORY)
    %======================================================================
    nelblo      = 400;
    nelblo      = min(nel, nelblo);
    invJx      = zeros(nelblo, ndim);
    invJy      = zeros(nelblo, ndim);

    il          = 1;
    iu          = nelblo;
    %==================================================================
    % i) BLOCK LOOP -
    %==================================================================

    for ib = 1:nblo
        %==============================================================
        % ii) FETCH DATA OF ELEMENTS IN BLOCK
        %==============================================================
        ECOORD_x        = reshape( GCOORD(1,ELEM2NODE(:,il:iu)), nnodel, nelblo);
        ECOORD_y        = reshape( GCOORD(2,ELEM2NODE(:,il:iu)), nnodel, nelblo);
        Vel_block       = reshape(Vel(ELEM_DOF(:,il:iu))',  nelblo, 2*nnodel);
        %PRESSURE
        Pressure_block  = Pressure(:,il:iu);
        Pi_block        = zeros(nelblo, np);  %pressure shape functions

        a23   = ECOORD_x(2,:).*ECOORD_y(3,:) - ECOORD_x(3,:).*ECOORD_y(2,:);
        a31   = ECOORD_x(3,:).*ECOORD_y(1,:) - ECOORD_x(1,:).*ECOORD_y(3,:);
        a12   = ECOORD_x(1,:).*ECOORD_y(2,:) - ECOORD_x(2,:).*ECOORD_y(1,:);
        area  = a23 + a31 + a12;


        for ip=1:nip
            %==========================================================
            % iv) LOAD SHAPE FUNCTIONS DERIVATIVES FOR INTEGRATION POINT
            %==========================================================
            ED       = Mu_all(il:iu,ip);
%             Mu_ve    = Mu_ve_all(il:iu,ip);
            Etheta   = THETA_all(il:iu,ip);
            
            F0_xx_block = F0_xx(il:iu,ip);
            F0_xy_block = F0_xy(il:iu,ip);
            F0_yx_block = F0_yx(il:iu,ip);
            F0_yy_block = F0_yy(il:iu,ip);
            
            Ni      =        N{ip};
            dNdui   =     dNdu{ip};
            GIP_x   = Ni'*ECOORD_x; %x and y coordinate of the integrations point
            GIP_y   = Ni'*ECOORD_y;

            tmp   = ECOORD_x(3,:).*GIP_y - GIP_x.*ECOORD_y(3,:);
            eta1  = a23 + tmp + ECOORD_y(2,:).*GIP_x - GIP_y.*ECOORD_x(2,:);
            eta2  = a31 - tmp + ECOORD_x(1,:).*GIP_y - GIP_x.*ECOORD_y(1,:);

            %pressure shape functions
            Pi_block(:,1) = eta1./area;
            Pi_block(:,2) = eta2./area;
            Pi_block(:,3) = 1 - Pi_block(:,1) - Pi_block(:,2);

            %pressure at the integration point
            Pres_ip       = sum(Pi_block.*Pressure_block',2);

            %==========================================================
            % v) CALCULATE JACOBIAN, ITS DETERMINANT AND INVERSE
            %==========================================================
            Jx          = ECOORD_x'*dNdui;
            Jy          = ECOORD_y'*dNdui;
            detJ        = Jx(:,1).*Jy(:,2) - Jx(:,2).*Jy(:,1);

            invdetJ     = 1.0./detJ;
            invJx(:,1)  = +Jy(:,2).*invdetJ;
            invJx(:,2)  = -Jy(:,1).*invdetJ;
            invJy(:,1)  = -Jx(:,2).*invdetJ;
            invJy(:,2)  = +Jx(:,1).*invdetJ;

            %==========================================================
            % vi) DERIVATIVES wrt GLOBAL COORDINATES
            %==========================================================

            dNdx            = invJx*dNdui';
            dNdy            = invJy*dNdui';
            B               = zeros(nelblo, 2*nnodel);
            B(:,1:2:end-1)  = dNdx;
            Erx_block       = sum(B.*Vel_block,2);
            B(:)            = 0;
            B(:,2:2:end)    = dNdy;
            Ery_block       = sum(B.*Vel_block,2);
            B(:)            = 0;
            B(:,1:2:end-1)  = dNdy;
            B(:,2:2:end)    = dNdx;
            Erxy_block      = sum(B.*Vel_block,2);
            
            Wxy_block       = 0.5.*(sum(dNdy.*Vel_block(:,1:2:end-1),2) - sum(dNdx.*Vel_block(:,2:2:end),2));

            Txx_block       = 4/3.*ED.*Erx_block -2/3.*ED.*Ery_block + 2.*ED.*Etheta.*TAU_xx_old(il:iu,ip);
            Tyy_block       = -2/3.*ED.*Erx_block +4/3.*ED.*Ery_block + 2.*ED.*Etheta.*TAU_yy_old(il:iu,ip);
            Txy_block       = ED.*Erxy_block + 2.*ED.*Etheta.*TAU_xy_old(il:iu,ip);

            Erxy_block      = Erxy_block./2;
            %2. strain rate invariant / effective strain rate
            E2it_block      = sqrt(0.5*(Erx_block.^2+Ery_block.^2) + Erxy_block.^2);
            
            %2nd invatiant of the deviatoric stress
            T2it_block    = sqrt(0.5*(Txx_block.^2+Tyy_block.^2)+Txy_block.^2);
            
            %TAU(il:iu,ip) = sqrt(1/2*(TAU_xx_old(il:iu,ip).^2 + TAU_yy_old(il:iu,ip).^2) + TAU_xy_old(il:iu,ip).^2);

            %Difference in principal stresses (2 ways of calculating)

%             Diff_ps_block1  = 2*sqrt((Txx_block - Tyy_block).^2 / 4 + Txy_block.^2);
            Max_Tau_block   = 2*ED.*E2it_block; % maximum shear stress
                                                %equal to difference in principal stresses divided by two /Turcotte Schubert page 83
                                                % principal stresses and
                                                % strain rate invariants
                                                % page 36 and 76 in
                                                % Ranalli's book
                                                            
                                                            
            Yield_block                         = -GIP_y'*9.81*2700*sin(Phi0) + Cohesion0;%sin(Phi).*Pres_ip + Cohesion;% 200*1e6;%sin(Phi).*Pres_ip + Cohesion;
            Yield_block(Yield_block<Cohesion0)  = Cohesion0;
            
            %--------------------------------------------------------------
            % STRAIN SOFTENING: Calculating and accumulating I2 MODIFY
            %--------------------------------------------------------------
            % Calculates the spatial gradients of the velocity (Malvern p.
            % 146)
            
            % Calculates the L matrix
            dVxdx = sum(Vel_block(:,1:2:end-1).*dNdx,2);
            dVxdy = sum(Vel_block(:,1:2:end-1).*dNdy,2);
            dVydx = sum(Vel_block(:,2:2:end).*dNdx,2);
            dVydy = sum(Vel_block(:,2:2:end).*dNdy,2);
            
            % Calculates the rate of change of the deformation gradient
            Fr_xx_block = dVxdx.*F0_xx_block + dVxdy.*F0_yx_block;
            Fr_xy_block = dVxdx.*F0_xy_block + dVxdy.*F0_yy_block;
            Fr_yx_block = dVydx.*F0_xx_block + dVydy.*F0_yx_block;
            Fr_yy_block = dVydx.*F0_xy_block + dVydy.*F0_yy_block;
            
            % Calculates the accumulated change of deformation for the
            % current strain iteration
            F_xx_block = F0_xx_block + dt*Fr_xx_block;
            F_xy_block = F0_xy_block + dt*Fr_xy_block;
            F_yx_block = F0_yx_block + dt*Fr_yx_block;
            F_yy_block = F0_yy_block + dt*Fr_yy_block;
            
            % Calculates the accumulated strain
            E_xx = (1/2)*(F_xx_block.^2 + F_yx_block.^2 - 1);
            E_xy = (1/2)*(F_xx_block.*F_xy_block + F_yx_block.*F_yy_block - 0);
            E_yy = (1/2)*(F_xy_block.^2 + F_yy_block.^2 - 1);
            
%             % Calculates the deviatoric strain (not needed because incompressibility)
%             Ed_xx = E_xx - (1/2).*(E_xx+E_yy);
%             Ed_yy = E_yy - (1/2).*(E_xx+E_yy);
            
            % Calculates the second invariant of the accumulated deviatoric
            % strain I2
            I2_block = sqrt((1/2)*(E_xx.^2 + E_yy.^2) ...
                + E_xy.^2);
            
            %==============================================================
            % ix) WRITE DATA INTO GLOBAL STORAGE
            %==============================================================
            STRAIN_xx(il:iu,ip)  = Erx_block;
            STRAIN_yy(il:iu,ip)  = Ery_block;
            STRAIN_xy(il:iu,ip)  = Erxy_block;
            TAU_xx(il:iu,ip)     = Txx_block;
            TAU_yy(il:iu,ip)     = Tyy_block;
            TAU_xy(il:iu,ip)     = Txy_block;
            E2it(il:iu,ip)       = E2it_block;
            T2all(il:iu,ip)      = T2it_block;
            MAX_TAU(il:iu,ip)    = Max_Tau_block;
            PRES_IP(il:iu,ip)    = Pres_ip;
            GIP_x_all(il:iu,ip)  = GIP_x';
            GIP_y_all(il:iu,ip)  = GIP_y';
            YIELD(il:iu,ip)      = Yield_block;
            F_xx(il:iu,ip)      = F_xx_block;
            F_xy(il:iu,ip)      = F_xy_block;
            F_yx(il:iu,ip)      = F_yx_block;
            F_yy(il:iu,ip)      = F_yy_block;
            I2 (il:iu,ip)        = I2_block;
            W_xy(il:iu,ip)       = Wxy_block;
            
        end


        %==============================================================
        % READJUST START, END AND SIZE OF BLOCK. REALLOCATE MEMORY
        %==============================================================
        il  = il+nelblo;
        if(ib==nblo-1)
            nelblo 	   = nel-iu;
            invJx      = zeros(nelblo, ndim);
            invJy      = zeros(nelblo, ndim);
        end
        iu  = iu+nelblo;
    end

    %======================================================================
    % Closes the loop
    %======================================================================
    strain(ei) = max(abs(E2all(:) - E2it(:)))./max(E2it(:))
    %strain(ei) = max((abs(E2all(:) - E2it(:)))./(E2it(:)))
    E2all      = E2it;
    if(strain(end)<1e-3 & ei>1  | ei>30 | all(RHEOL.Ndis==1) )
        ei
        break
    end

% ISBRITTLE = (MAX_TAU - YIELD);%zeros(size(YIELD));
% %ISBRITTLE(MAX_TAU>=YIELD) = 1;
%     %PLOTTING FOR TESTING
%     EL2N      = zeros(nel,3);
%     GCOORD_N  = zeros(2,nel*3);
%     TAU_xxn   = zeros(3,nel);
%     Mu_n      = zeros(3,nel);
%     Pres_n    = zeros(3,nel);
%     Brittle   = zeros(3,nel);
%     EL2N(1,:) = 1:3;
%     nip1 = 6;
%     nnodel1 = 6;
%     [IP_X, IP_w]    = ip_triangle(nip1);
%     [   Nbig]    = shp_triangle(IP_X, nnodel1);
%     for i=1:nel
%         is         = (i-1)*3+1; ie = (i-1)*3+3;
%         GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
%         EL2N(i,:) = is:ie;
%         Dummy      = Nbig'\YIELD(i,:)';
%         TAU_xxn(:,i)= Dummy(1:3);
%         Dummy      = Nbig'\Mu_all(i,:)';
%         Mu_n(:,i)= Dummy(1:3);
%         Dummy      = Nbig'\PRES_IP(i,:)';
%         Pres_n(:,i)= Dummy(1:3);
%         Dummy      = Nbig'\ISBRITTLE(i,:)';
%         Brittle(:,i)= Dummy(1:3);
% 
% 
%     end
%     figure(1), clf,
%     patch('faces',EL2N,'vertices',GCOORD_N','facevertexcdata',Pres_n(:),'FaceColor','flat')
%     shading interp
%     colorbar
% %     hold on
% %     quiver(GCOORD(1,:), GCOORD(2,:), Vel(1:2:end-1)', Vel(2:2:end)','w');
%     axis tight
%     drawnow
%  
% %     axis([-6 6 -6 6])
%     title('Pressure')
%     drawnow
%     figure(2),clf
%     patch('faces',EL2N,'vertices',GCOORD_N','facevertexcdata',TAU_xxn(:),'FaceColor','flat')
%     shading interp
%     colorbar
%     title('yield stress')
%     drawnow
%     figure(3),clf
%     patch('faces',EL2N,'vertices',GCOORD_N','facevertexcdata',log(Mu_n(:)),'FaceColor','flat')
% %     shading interp
%     colorbar
%     title('Mu')
%     drawnow
% 
%     figure(4),clf
%     patch('faces',EL2N,'vertices',GCOORD_N','facevertexcdata',Brittle(:),'FaceColor','flat')
%     shading interp
%     colorbar
%     title('diff yield stress')
%     drawnow
% 
    
%     plot(GIP_x_all(YC==1&YC_old==0)/1000,GIP_y_all(YC==1&YC_old==0)/1000,'.','Color',rand(1,3))
%     axis([-250 500 -400 5])
%     hold on
    disp(['Number of yielding ips: ',num2str(sum(sum(YC)))])
    disp(' ')
%     YC_old = YC;

    fprintf(1, 'STRESS STRAINS UPDATE:     ');
    fprintf(1, [num2str(toc,'%8.6f'),'\n']);
    
    %CLEAR UNUSED VARIABLES
    clear 'perm' 'invM' 'Q' 'L' 'A' 'EL2N' 'GCOORD_N';


end

% STRESS ROTATION

TAU_xx_old = TAU_xx + 2*W_xy.*TAU_xy*dt;
TAU_yy_old = TAU_yy - 2*W_xy.*TAU_xy*dt;
TAU_xy_old = TAU_xy - (TAU_xx - TAU_yy).*W_xy*dt;

nw_it = [nw_it ei];
