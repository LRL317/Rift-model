function tpelagic = tpelagic(pelagic_rate,pelagic_type,TopoXY,dt_sed)
switch pelagic_type
    case 'cnst'
        tpelagic = zeros(1,length(TopoXY));
        tpelagic(TopoXY(2,:)<=0) = pelagic_rate*dt_sed;
%         hold on
%         plot(TopoXY(1,:),TopoXY(2,:)+tpelagic,'xr')
    case 'var'
end