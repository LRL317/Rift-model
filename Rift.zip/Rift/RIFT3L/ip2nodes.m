function Vn = ip2nodes(Vip,GCO,E2N,nip,nnodel)
% VN = IP2NODES(VIP,GCO,E2N,NIP,NNODEL) calculates the values of variables
% VN defined at NNODEL number of nodes per element from a given VIP defined
% at NIP number of integration points per element. GCO and E2N define the
% mesh. VIP can be a matrix composed by a large number of variables with
% the same number of integration points per element (NIP).
%
%       Size
% VIP   (NVAR*NIP,NEL)                          NVAR = number of variables
% VN    (NVAR*NNODEL,NEL)                       NEL  = number of elements
%
% You choose weather the interpolation is linear or cuadratic by
% selecting NNODEL (NNODEL = 3 then linear, NNODEL = 6 then cuadratic).
% Note that when NIP is different from NNODEL that means that the shape
% function matrix N is not going to be square and therefore:
%
%       VN = N \ VIP    is not equivalent to    VN = N^(-1) * VIP
%
% since there is no inverse for a non-square matrix. This means that the
% solution is over-conditioned. For this case \ solves by least-squares.

%--------------------------------------------------------------------------
% Function based in Lars Ruepke plotting function. Edited by Miguel 
% Andres-Martinez, 15-09-2016. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%==========================================================================
% VARIABLES
%==========================================================================
% Number of elements
nel = size(E2N,2);

% Number of variables
nvar = size(Vip,2)/nip;

% Initialize variables in the nodes
Vn = zeros(nnodel*nvar,nel);

% Calculate shape functions
[IP_X,~] = ip_triangle(nip);
Nbig = shp_triangle(IP_X,nnodel);

%==========================================================================
% ELEMENT BY ELEMENT INTERPOLATION LOOP
%==========================================================================
for i=1:nel
    for j = 1:nvar
        Dummy      = Nbig'\Vip(i,(1:nip)+nip*(j-1))';
        Vn((1:nnodel)+nnodel*(j-1),i)= Dummy(1:nnodel)';
    end  
end

%==========================================================================
% PLOT (uncomment)
%==========================================================================
% for n = 1:size(Vn,2)
%     patch('Faces',[1 2 3],'Vertices',[GCO(:,E2N(1:3,n))'/1000 ...
%         Vn((4-1)*3+(1:3),n)],'EdgeColor','white')
%     %       ^
%     %       |
%     % Change this number to plot different variables
%     hold on
% end