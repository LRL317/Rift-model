function [remesh,GCOORD,ELEM2NODE,Phases,GEOMETRY,Geo_id,Corner_id,Cornin_id, ...
            Point_id,cont_points,Elsizes,nip,x_min,x_max,ext_rate,ext_erate, ...
            boundary_condition,temp_bc,temp_bc_depth,mode,prec, ...
            Temp,F_xx,F_xy,F_yx,F_yy,TAU_xx_old,TAU_xy_old, ...
            TAU_yy_old,I2,E2all,Mu_all,ndof,nnod,nel,layer_corr,Bc_ind,Bc_val ...
            Bc_ind_fs,Bc_val_fs,Bct_ind,Bct_val,Geo_mark,Intersect_ID,Sgap, ...
            Rheol_var,SS] = ...
    remesh_all3l(remesh,GCOORD,ELEM2NODE,GEOMETRY,Phases,Geo_id, ...
    Corner_id,Cornin_id,cont_points,Elsizes,nip,x_min,x_max,Ylim,ext_rate, ...
    ext_erate,boundary_condition,temp_bc,temp_bc_depth,mode,prec, ...
    shift,Temp,F_xx,F_xy,F_yx,F_yy, ...
    TAU_xx_old,TAU_xy_old, TAU_yy_old, plot_s,Intersect_ID,Sgap, ...
    intersect_s,triangle_path,meshname,Rheol_var,E2all,Mu_all,SS)
% REMESH_ALL generates a new mesh and remeshes the temperature, the
% accumulated gradient of the deformation and the stress

E2N = ELEM2NODE;
GCO = GCOORD;
Pha = Phases;

layer_corr = [0 0];

%remeshing interfaces (TODO)
[GEOMETRY, Geo_id, Intersect_ID,Sgap] =  resample_interf(GCOORD, ...
    GEOMETRY,Geo_id,Corner_id, Cornin_id,cont_points,x_max,x_min,Ylim, ...
    Intersect_ID);

% Resample can make interfaces to intersect so lineintersect or dis_layers 
% needs to be called again
inter_t = tic;
switch intersect_s
    case 'lineintersect'
        [GEOMETRY(1,Geo_id==3), GEOMETRY(2,Geo_id==3), GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), remesh, layer_corr] = lineintersect (GEOMETRY(1,Geo_id==3), GEOMETRY(2,Geo_id==3), GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), remesh, shift);
        [GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), GEOMETRY(1,Geo_id==9), GEOMETRY(2,Geo_id==9), remesh, layer_corr] = lineintersect (GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), GEOMETRY(1,Geo_id==9), GEOMETRY(2,Geo_id==9), remesh, shift);
        Intersect_ID = zeros(1,size(GEOMETRY,2))==1;
    case 'dis_layers'
        [GEOMETRY,Geo_id,Sgap,Intersect_ID,remesh] = ...
            dis_layers(GEOMETRY,Geo_id,Intersect_ID,shift,remesh);
end
toc(inter_t)

%make mesh
[GCOORD,ELEM2NODE, Point_id, Phases] = generate_mesh3l ...
    (GEOMETRY,Geo_id,Elsizes,Sgap,mode,triangle_path,meshname);
nnod    = size(GCOORD,2);
ndof    = size(GCOORD,1);
nel     = size(ELEM2NODE,2);

% Increase the shift and remesh in case the intersections at the interfaces
% are generating very bad triangles
% switch intersect_s
%     case 'dis_layers'
%         shiftc = shift + shift;
%         mesh_c = 1;
%         cc = 1;
%         while mesh_c
%         [qn,amin,amax] = checkmesh(GCOORD,ELEM2NODE);
%             if(qn<0.2 || amin<7 || amax>170) && cc<=2
%                 [GEOMETRY,Geo_id,Sgap,Intersect_ID,remesh] = ...
%                     dis_layers(GEOMETRY,Geo_id,Intersect_ID,shiftc,remesh);
%                 [GCOORD,ELEM2NODE, Point_id, Phases] = generate_mesh ...
%                     (GEOMETRY,Geo_id,Elsizes,Sgap,mode,triangle_path);
%                 shiftc = shiftc + shift;
%                 cc = cc + 1;
%                 nnod = size(GCOORD,2);
%                 ndof = size(GCOORD,1);
%                 nel = size(ELEM2NODE,2);
%             else
%                 mesh_c = 0;
%             end
%         end
% end

%add 7th node
ELEM2NODE(7,:)  = nnod+1:nnod+nel;
GCOORD          = [GCOORD, [...
    mean(reshape(GCOORD(1, ELEM2NODE(1:3,:)), 3, nel));...
    mean(reshape(GCOORD(2, ELEM2NODE(1:3,:)), 3, nel))]];

nnod    = size(GCOORD,2);

%RESET STRAIN RATE
E2all = remesh_val_ip(GCO,E2N,E2all,nip,nip,GCOORD,ELEM2NODE);
Mu_all = remesh_val_ip(GCO,E2N,Mu_all,nip,nip,GCOORD,ELEM2NODE);
Mu_all(Mu_all<0) = -Mu_all(Mu_all<0);
%FIND GEOMETRY MARKERS
[~,Geo_mark] = ismember(fix(GEOMETRY'*1e3),fix(GCOORD'*1e3),'rows');

% CORNER NODES
Layer1_id   = find(Geo_id==1);
Layer9_id   = find(Geo_id==9);
CORNERS     = [GEOMETRY(:,Layer1_id(1)) GEOMETRY(:,Layer1_id(end)) GEOMETRY(:,Layer9_id(1))  GEOMETRY(:,Layer9_id(end))];
Corner_id   = find(ismember((round(prec*GCOORD))', (round(prec*CORNERS))','rows')==1)';
%INNER CORNERS
Layer3_id   = find(Geo_id==3);
Layer6_id   = find(Geo_id==6);
CORNERS_IN  = [GEOMETRY(:,Layer3_id(1)) GEOMETRY(:,Layer6_id(1)) GEOMETRY(:,Layer6_id(end))  GEOMETRY(:,Layer3_id(end))];
Cornin_id   = find(ismember((round(prec*GCOORD))', (round(prec*CORNERS_IN))','rows')==1)';

if(~isequal(size(Corner_id,2),4) & ~isequal(size(Cornin_id,2),6))
    error('Corners');
end
% Layer6_id   = [find(Point_id==6) Cornin_id(4)];

%reset boundary conditions
[Bc_ind, Bc_val, Point_id, Bc_ind_fs, Bc_val_fs, ext_erate]    = set_bcs_flow3l(GCOORD, Corner_id, Cornin_id, Point_id, ext_erate, ext_rate, boundary_condition);

% Remesh the accumulated gradient of the deformation F
nnodel_r = nip;
[F_xx, F_xy, F_yx, F_yy,GIP_xF,GIP_yF, I2, TAU_xx_old, ...
    TAU_xy_old, TAU_yy_old] = remesh_F_TAU(GCOORD, ELEM2NODE, ...
    GCO, E2N, F_xx, F_xy, F_yx, F_yy, nnodel_r, ...
    TAU_xx_old, TAU_xy_old, TAU_yy_old, nip, nel);

% % Remesh random
% if SS.rand_s
%     [SS] = remesh_random_element(GCOORD,ELEM2NODE,Phases,GCO,E2N,Pha,SS);
% end

%remesh temperatures
%INTERPOLATE TEMPERATURES
Tris       = tsearch2(GCO,uint32(E2N(1:3,:)),GCOORD);
Ind        = find(Tris==0);

%check of all elements were found
if(~isempty(Ind))
    %     disp('remeshing has problems');
    %             GCO_C(:,:)               = 1/3*(GCO(:,E2N(1,:))+GCO(:,E2N(2,:))+GCO(:,E2N(3,:)));
    
    for i=1:length(Ind)
        [val, Tris(Ind(i))] = min(sqrt((GCO(1,E2N(7,:)) - GCOORD(1,Ind(i))).^2 + (GCO(2,E2N(7,:)) - GCOORD(2,Ind(i))).^2));
    end
end

if(any(Tris==0))
    error('remeshing failed in move_contours');
end


[Temp] = remesh_val(Tris,GCO,GCOORD,Temp,E2N);

[Bct_ind, Bct_val] = set_bcs_temp(GCOORD, Corner_id, Cornin_id, Point_id, temp_bc, temp_bc_depth);

if(~isempty(Ind))
    EL2N      = zeros(nel,3);
    GCOORD_N  = zeros(2,nel*3);
    T_n      = zeros(3,nel);
    EL2N(1,:) = 1:3;
    nip = 6;
    nnodel = 6;
    [IP_X, IP_w]    = ip_triangle(nip);
    [   Nbig]    = shp_triangle(IP_X, nnodel);
    for i=1:nel
        is         = (i-1)*3+1; ie = (i-1)*3+3;
        GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
        EL2N(i,:) = is:ie;
        T_n(is:ie) = Temp(ELEM2NODE([1 2 3],i));
        
    end
    switch plot_s
        case 'y'
            figure(11), clf
            subplot(221),patch('faces',EL2N,'vertices',GCOORD_N','facevertexcdata',T_n(:),'FaceColor','flat')
            shading interp
            axis tight
            drawnow
    end
end

%==========================================================================
% REMESH FACTORS FOR RHEOLOGIC CHANGES INSIDE PHASES
%==========================================================================
if size(Rheol_var,2) > 1
    Rheol_var = ...
        remesh_rheol_var(GCOORD,ELEM2NODE,Phases,GCO,E2N,Pha,Rheol_var);
else
    Rheol_var = ones(nel,1);
end

remesh = 0;