Pt_dif = SS.F_dif(I2(:),TEMP_IP(:));
diff_dif = abs(Pt_dif-Pef_dif(:));
Pt_dis = SS.F_dis(I2(:),TEMP_IP(:));
diff_dis = abs(Pt_dis-Pef_dis(:));
if sum(diff_dif>0.001)>0 || sum(diff_dis>0.001)>0
    error(['Differences between the theoretical and the calculated ' ...
        'pef softening factor are too big. Recommendation: check plots'])
end