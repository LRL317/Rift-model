function TRACKP = track_points(GCOORD,ELEM2NODE,Point_id,TRACKP,DISPL,dt)

% TRACK_POINTS(GCOORD,ELEM2NODE,TRACKP,DISPL,DT) Calculatates the new
% positions for the tracked points TRACKP after deformation of the current
% time step DT, using the velocities DISPL, defined in the nodes of a mesh
% GCOORD, ELEM2NODE.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 23-06-2013. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------
% MA 23-06-2014 Indexation of the outer track point problems solved
% MA 06-09-2015 Bug when tracking points where at x-coordinates equivalent
%     to the corners of the model solved
tic;
% Finds the elements where the track points are located
Tris = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),TRACKP);
toc
% Finds points outside of the mesh
Ind = find(Tris==0);

Rout = TRACKP(1,:)>max(GCOORD(1,:));
Lout = TRACKP(1,:)<min(GCOORD(1,:));
TRACKP(1,Rout) = max(GCOORD(1,:));
TRACKP(1,Lout) = min(GCOORD(1,:));
%==========================================================================
% OUTSIDE POINTS
%==========================================================================
% TODO matricial form of OUTSIDE POINTS
% TODO Velocity interpolation as in the edge on the element when outside
% points
tic;
% Checks all points were found and if not correct the problem
if(~isempty(Ind))
    % Add corners to the surface
    Corners = find(Point_id==-1);
    Point_id(Corners(end-1:end)) = max(Point_id)-1;
    % Finds the surface indexes
    Surf_i = find(Point_id==max(Point_id)-1);
    % Finds the surface coordinates
    Surface = GCOORD(:,Surf_i);
    % Loop through the track points found outside of the meshTris = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),TRACKP)
    for i=1:length(Ind)
        % Interpolates the y-coordinate of the track point at the surface
        % and saves it as the y-coordinate of the track point
        TRACKP(2,Ind(i)) = interp1(Surface(1,:),Surface(2,:), ...
            TRACKP(1,Ind(i)));
        
        % Find if the x-coordinate corresponds to a corner
        if ismember(TRACKP(1,Ind(i)),GCOORD(1,Corners))
            % Finds the element that contains that corner
            Tpcorner = ismember(GCOORD(1,Corners),TRACKP(1,Ind(i))) & ...
                ismember(GCOORD(2,Corners),TRACKP(2,Ind(i)));
            [~,Tris(Ind(i))] = find(sum(ismember(ELEM2NODE, ...
                Corners(Tpcorner))==1),1,'first');
        else
            % Finds the nodes indexes at the right and left of the track 
            % point
            right = find(min(Surface(1,(Surface(1,:) ...
                - TRACKP(1,Ind(i)))>=0))==Surface(1,:));
            left = find(max(Surface(1,(TRACKP(1,Ind(i)) ...
                - Surface(1,:))>0))==Surface(1,:));
            
            % Finds the element index which contains the left and right
            % node
            [~,Tris(Ind(i))] = ...
                find(sum(ismember(ELEM2NODE,Surf_i([left right])))==2);
        end
    end
end
toc
%==========================================================================
% VELOCITIES AND DISPLACEMENTS
%==========================================================================

% Interpolate velocities at the trackpoints
Vx_tp = remesh_val(Tris,GCOORD,TRACKP,DISPL(1,:),ELEM2NODE);
Vy_tp = remesh_val(Tris,GCOORD,TRACKP,DISPL(2,:),ELEM2NODE);

% Calculates displacements and updates the position of the track points
TRACKP = TRACKP + [Vx_tp; Vy_tp].*dt;