function [BREAKUP,time_int] = break_up(BREAKUP,GCOORD,Point_id,ntime, ...
    time_int)
% [BREAKUP,TIME_INT] = BREAK_UP(BREAKUP,GCOORD,POINT_ID,NTIME,TIME_INT) checks for
% break-up conditions given by the structure BREAKUP and, if met, changes
% the end time TIME_INT to the current time NTIME plus an additional time
% interval BREAKUP.break_time, so that the model stops BREAKUP.break_time
% after the break-up conditions are met. GCOORD and POINT_ID define the
% geometry of the mesh. BREAKUP.mid corresponds to the id of the moho in
% POINT_IT, BREAKUP.min_thick to the crustal thickness for the break-up to
% be considered as achieved, and BREAKUP.bool is 0 if the break-up
% condition is not met or 1 if its met.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 15-05-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

% Check if break up condition is already met
if BREAKUP.bool==0
    % Surface node coordinates   
    Surface = GCOORD(:,Point_id==max(Point_id)-1);
    % Moho node coordinates 
    Moho = GCOORD(:,Point_id==BREAKUP.mid);
    
    % Interpolation the surface y-coordinates at the moho node 
    % x-coordinates
    M2S = interp1(Surface(1,:),Surface(2,:),Moho(1,:),'linear');
    % Interpolation the moho y-coordinates at the surface node 
    % x-coordinates
    S2M = interp1(Moho(1,:),Moho(2,:),Surface(1,:),'linear');
    
    % Find which moho nodes meet the break-up criterium
    M_Sbool = abs(M2S-Moho(2,:))<=BREAKUP.min_thick;
    % Find which surface nodes meet the break-up criterium
    S_Mbool = abs(S2M-Surface(2,:))<=BREAKUP.min_thick;
    
    % Check if any node meets the break-up criterium
    if sum(M_Sbool)+sum(S_Mbool)>0
        disp(['BREAK UP CRITERIUM MET: ', ...
            num2str(sum(M_Sbool)+sum(S_Mbool)),' nodes'])
        % Set break-up bool 1
        BREAKUP.bool = 1;
        % Calculate the new finishing time
        time_int = floor((ntime+2*BREAKUP.break_time)/ ...
            BREAKUP.break_time)*BREAKUP.break_time;
    end

%     % Plot (uncomment)
%     plot(Moho(1,:)/1000,M2S/1000,'.r')
%     hold on
%     plot(Surface(1,S_Mbool)/1000,Surface(2,S_Mbool)/1000,'or')
%     plot(Surface(1,:)/1000,S2M/1000,'.b')
%     plot(Moho(1,M_Sbool)/1000,Moho(2,M_Sbool)/1000,'ob')
end