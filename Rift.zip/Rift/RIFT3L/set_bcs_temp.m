function [Bc_ind, Bc_val, Point_id] = set_bcs_temp(GCOORD, Corner_id, Cornin_id, Point_id,temp_bc,temp_bc_depth)

% %CORNERS
% %bot left
% Bc_ind = Corner_id(1);
% Bc_val = temp_bc;
% 
% %bot right
% Bc_ind = [Bc_ind Corner_id(2)];
% Bc_val = [Bc_val temp_bc];

%top right
Bc_ind = [ Corner_id(3)];
Bc_val = [ 0];
%top left
Bc_ind = [Bc_ind Corner_id(4)];
Bc_val = [Bc_val 0];
%Remove corner nodes from segement ids
Point_id(Corner_id) = -1;

%Remove corner nodes from segement ids
Point_id(Cornin_id) = -1;

% Upper boundary
Bc_tmp = find(Point_id==max(Point_id)-1);
Bc_ind = [Bc_ind Bc_tmp];
Bc_val = [Bc_val zeros(size(Bc_tmp))];

% Bottom boundary
Bc_tmp = find(GCOORD(2,:) <= temp_bc_depth); % Nodes below
    % boundary condition
Bc_ind = [Bc_ind Bc_tmp];
Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];

%CORNERS
%bot left
Bc_ind = [Bc_ind Corner_id(1)];
Bc_val = [Bc_val temp_bc];

%bot right
Bc_ind = [Bc_ind Corner_id(2)];
Bc_val = [Bc_val temp_bc];

% Bottom boundary
Bc_tmp = find(Point_id==1);
Bc_ind = [Bc_ind Bc_tmp];
Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];
