      
function ERho = dens_temp(ELEM2NODE, Phases,Rho, Temp,np, Ce,il,iu, nip,ip)  
        Rho_block   = Rho(Phases(il:iu))';
        Tref = 0;
        [IP_X, ~]    = ip_triangle(nip);
        [   N, ~]    = shp_deriv_triangle(IP_X, np);
         Ni          =        N{ip};
        if il==iu
            dT           = (Temp(ELEM2NODE(1:3,il:iu))* Ni ) - Tref;
        else
            dT           = (Temp(ELEM2NODE(1:3,il:iu))'* Ni ) - Tref;
        end
        
        Rho_block   = Rho_block.*(1 - Ce(Phases(il:iu)).*dT)';  %why it has just Ce vector not CE? (PHYSICS.alpha)
        ERho = Rho_block';
end