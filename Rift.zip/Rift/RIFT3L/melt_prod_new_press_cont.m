function  [Dpl,dF,Temp,dF_up,dF_diffusive,dP_melting] = melt_prod_new_press_cont(Dpl,GCOORD,GCOORD_old,z2p,Ts0,dTs_dP,dTs_dF,QL,Temp,nnod,istep,Point_id,Corner_id,Rho,Phases,G,PRESS_CONT,PRESS_CONT_old)

%Estimates depletion, dF, magmatic crustal thickness and Temperature
%resulting form melting

%     %FIND MELT PRODUCTIVITY AND UPDATE SOLIDUS
%     % First check if the new temperature due to diffusion of heat at the
%     % same depth as the old nodes, puts as above or below the solidus. If
%     % above solidus ten estimate DF due to new temperature, new solidus and
%     % new temperature

     
     P = PRESS_CONT_old;
    %P = -z2p *GCOORD_old(2,:) ; % lithostatic pressure at old node %WE NEED TO DEFINE THIS BETTER DUE TO FREE SURFACE.Pressure is positive
    
    Dpl0 = Dpl;
    
    Ts_dry = Ts0 + dTs_dP.*P + dTs_dF.*Dpl0;
    %Ts_wet(:) = Ts_dry(:,jc) +  PETRO.aX.*(0.01.*PETRO.X0(jc)).^PETRO.bX;
% Plot (uncomment)

% 
% title('Pressures [MPa]')
% xlabel('Distance [Km]')
% ylabel('Depth [Km]')

%%%%%%%%%% added by elena -> check how it works
% figure(16)
% plot(Ts_dry,GCOORD_old(2,:)/1000,'*r')
% hold on;
% plot(Temp,GCOORD_old(2,:)/1000,'og')
% hold on;
% plot(Temp,GCOORD(2,:)/1000,'xb')
% hold on;
% plot(P,GCOORD(2,:)/1000,'xg')
% 
% figure(14)
% plot(Ts_dry,GCOORD(2,:)/1000,'*r')
% hold on;
% plot(Temp,GCOORD(2,:)/1000,'og')
%     
%     figure(15)
%     plot(Ts_dry(7607),GCOORD_old(2,7607)/1000,'*r')%%%%  punto de melting de 1064
%     hold on;
%     plot(Temp(7607),GCOORD_old(2,7607)/1000,'og')
%     axis([0 2500 -300 50])
% 
%     figure(16)
%     plot(Ts_dry(9000),GCOORD_old(2,9000)/1000,'*r')%%%% NO punto de melting de 1064 (para comparar el plot)
%     hold on;
%     plot(Temp(9000),GCOORD_old(2,9000)/1000,'og')
%     axis([0 2500 -300 50])
%     
%     figure(17)
%     plot(Ts_dry(23203),GCOORD_old(2,23203)/1000,'*r') %%%% punto de melting de 1064
%     hold on;
%     plot(Temp(23203),GCOORD_old(2,23203)/1000,'og')
%     axis([0 2500 -300 50])

%     xlabel('Temperature [C]')
%     ylabel('Depth [km]')
%     %title(['Solidus',num2str((istep*dt/ma)),' ma'])
%     hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    is_melting = find(Temp >=Ts_dry);
    T_m_Ts = Temp - Ts_dry;
    
    dF_diffusive = zeros(1,nnod);
    dF_diffusive(is_melting) = T_m_Ts(is_melting) ./ (QL + dTs_dF);
    
%     disp(dF_diffusive(is_melting)) %added
%     display(T_m_Ts(is_melting))%added
%     display(Temp(is_melting))%added
%     display(Ts_dry(is_melting))%added
    
% Correction to T due to dF
    T_correction = zeros(1,nnod); % or zeros(nnod,1) ???
    T_correction(is_melting) = dTs_dF .* dF_diffusive(is_melting);
    
%disp(T_correction(is_melting)) 
%added
    
    % New temperature
    Temp(is_melting) = Ts_dry(is_melting) + T_correction(is_melting);
%     disp(istep)
    
%     if(Temp(is_melting ~= 0))%added
%     disp(Temp(is_melting)) %added
%     end  %added
    
    
    Dpl = Dpl0 + dF_diffusive;
    
    ind2 =find(Dpl <0);
    
    if(ind2 ~= 0)
        error('Dpl diffusive i less than zero')
    end
    
    % New solidus after dF_diffusive
    Ts_dry0 = Ts0 + dTs_dP*P + dTs_dF.*Dpl; 
%%%%%%%%%% added by elena -> check how it works
%     figure(15)
%     plot(Ts_dry0(is_melting),GCOORD_old(2,is_melting)/1000,'*c','MarkerSize', 5)
%     hold on;
%         plot(Ts_dry0,GCOORD_old(2,:)/1000,'*k')
%     hold on;
% 
%         plot(Temp,GCOORD_old(2,:)/1000,'og')
%     hold on;
%            plot(Temp,GCOORD(2,:)/1000,'xr')
% 
%     xlabel('Temperature [C]')
%     ylabel('Depth [km]')
%     %title(['Solidus',num2str((istep*dt/ma)),' ma'])
%     hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Find new depletion due to decompression only
    %dz_max = PETRO.dzmax;
    %dT0   = abs(Temp - Ts_dry);
    dT0   =  Ts_dry0 - Temp ;
    ind0 =find(dT0 <0);
    if(ind0 ~= 0)
        Temp(ind0) = Ts_dry0(ind0);
        dT0(ind0) = Ts_dry0(ind0)- Temp(ind0);
    end   
     
    Pnew = PRESS_CONT;
    %%%%%
    %dz    = (GCOORD(2,:)-GCOORD_old(2,:)); %Do we need to transpose here? % this dz is positive because GCOORD and GCOORD_old are negative and abs(GCOORD_old) > abs(GCOORD)
    %niter = ceil(max(dz)/dz_max);
    %dP    = -z2p * dz;          % decompression during this time step, dP is negative
    %P     = PLITHOST;
    %P     = z2p*(GCOORD_surf_old - GCOORD_old(2,:)); % lithostatic pressure at old node %we need to define this better due to free-surface. Pressure is positive
    %P     = P + dP;  %This is new pressure after going up a dP with a Temp equal to the one after diffusion and melting in the previous step
    % New pressure is less than previous one due to
    % upwelling
    
    % New solidus after dP due to upwelling
    Ts_dry1 = Ts0 + dTs_dP*Pnew + dTs_dF.*Dpl;
    dP    = (Pnew - P) ;
%%%%%%%%%% added by elena -> check how it works
%     figure(15)
%     plot(Ts_dry1,GCOORD(2,:)/1000,'*g')
%     xlabel('Temperature [C]')
%     ylabel('Depth [km]')
%     %title(['Solidus',num2str((istep*dt/ma)),' ma'])
%     hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    
    dT1 =  Temp - Ts_dry1;
    
    % Am i now above solidus?
    is_melting_up = find(Temp >=Ts_dry1);
    dP0 = zeros(1,nnod);
    
    dP0(is_melting_up) = (dT0(is_melting_up).*dP(is_melting_up))./(Ts_dry0(is_melting_up) - Ts_dry1(is_melting_up) );
    dP1 = zeros(1,nnod);
    dP1(is_melting_up) =  dP(is_melting_up) -dP0(is_melting_up);
    %
    indkk =find(dT0 <0);
    
    if(indkk ~= 0)
       error('dT0 i less than zero')
    end
    
    dP_melting = zeros(1,nnod);
    dP_melting(is_melting_up) = dP1(is_melting_up) ;
    
    
    % Calculate productivity (change in degree of melting over dP)
    dF_dP = dTs_dP ./ (dTs_dF +  QL);
    
    % Calculate change derivative in temperature with respect to pressure
    dT_dP = dTs_dP - dTs_dF .* dF_dP;
    % New temperature at nodes with melting
    Temp(is_melting_up)  = Temp(is_melting_up) + dT_dP .* dP_melting(is_melting_up);
    
    
    % Final change in degree of melting for all nodes
    dF_up= zeros(1,nnod);
    if dP_melting(is_melting_up) <= 0
        dF_up(is_melting_up) = - dF_dP .* dP_melting(is_melting_up); % dF in this iteration
    else
        dF_up(is_melting_up) = dF_dP .* dP_melting(is_melting_up); % dF in this iteration
    end
    % Final depletion for the time step
    Dpl = Dpl + dF_up;
    
    indk =find(Dpl <0);
    
    if(indk ~= 0)
        error('Dpl i less than zero')
    end
    
    
    Ts_dry2 = Ts0 + dTs_dP.*Pnew + dTs_dF.*Dpl;
%%%%%%%%%% added by elena -> check how it works
%     figure(15)
%     plot(Ts_dry2,GCOORD(2,:)/1000,'*k')
%     hold on;
%     plot(Ts_dry2(is_melting_up),GCOORD(2,is_melting_up)/1000,'*b','MarkerSize', 10)
%     hold on;
%            plot(Temp,GCOORD(2,:)/1000,'xr')
% 
%     xlabel('Temperature [C]')
%     ylabel('Depth [km]')
    %title(['Solidus',num2str((istep*dt/ma)),' ma'])
%     hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    
    % Final dF in time step
    dF = zeros(1,nnod);
    dF = dF_up + dF_diffusive;
    
end

