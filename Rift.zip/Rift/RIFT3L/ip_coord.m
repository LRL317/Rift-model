function [GIP_X,GIP_Y] = ip_coord(GCOORD,ELEM2NODE,nel,nip)
% [GIP_X,GIP_Y] = IP_COORD(GCOORD,ELEM2NODE,NEL,NIP) calculates the
% coordinates of the integration points for a mesh defined by GCOORD and
% ELEM2NODE, with NEL number of elements and NIP number of integration
% points per element.

%--------------------------------------------------------------------------
% Function based in Lars Ruepke script. Edited by Miguel Andres-Martinez,
% 15-09-2016. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

% Initialize coordinates
GIP_X = zeros(nel,nip);
GIP_Y = zeros(nel,nip);

% Load shape functions
[IP_X, ~]    = ip_triangle(nip);
[   N, ~]    = shp_deriv_triangle(IP_X,size(ELEM2NODE,1));

% Reorder coordinates in the element matrix shape
ECOORD_x = reshape(GCOORD(1,ELEM2NODE), size(ELEM2NODE,1), nel);
ECOORD_y = reshape(GCOORD(2,ELEM2NODE), size(ELEM2NODE,1), nel);

% Ip loop to calculate coordinates of the integration points
for ip=1:nip
    
    Ni      =        N{ip};

    GIP_x   = Ni'*ECOORD_x;
    GIP_y   = Ni'*ECOORD_y;
    
    GIP_X(:,ip)   = GIP_x;
    GIP_Y(:,ip)   = GIP_y;

end