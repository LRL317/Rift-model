% Displays the age of the current step
disp([num2str(dt*istep/ma),' ma'])