function [Z] = function_nl_erosion_fixedelevation(Z,no_nodes,F_loc,MM_loc,De,nexp,dt,Dx)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

no_el       = no_nodes-1; % Number of elements
no_nodes_el = 2; % Two nodes per element

nodes = zeros(no_el); % Connectivity matrix ?
D     = zeros(no_el); % Stiffness ?

for i=1:no_el % Loop through the elements
    iel = i; nodes(iel,1) = i; nodes(iel,2) = i+1;
end

% calculate the slope direction and water flux

q_w = -Dx.*cumtrapz(sign(diff(Z)));

% find the TOP of the hills
indx = find(diff(diff(Z)>0)<0);

if indx > 0
    q_w(1:indx(1)) = q_w(1:indx(1)) - min(q_w(1:indx(1)));
    
    q_w(indx(length(indx))+1:no_el) = ...
        q_w(indx(length(indx))+1:no_el) - ...
        min(q_w(indx(length(indx))+1:no_el));
    if length(indx) > 1
        for i=1:length(indx)-1
            q_w(indx(i)+1:indx(i+1)) = ...
                q_w(indx(i)+1:indx(i+1)) - ...
                min(q_w(indx(i)+1:indx(i+1)));
        end
    end
end

%q_w = q_w - min(q_w);
D = 1 + De*(abs(q_w).^nexp);

% Setup system matrix
KM          = zeros(no_nodes,no_nodes);
MM          = zeros(no_nodes,no_nodes);
F           = zeros(no_nodes,1);

for iel=1:no_el
    
    KM_loc       = D(iel)*[1/Dx(iel) -1/Dx(iel); -1/Dx(iel) 1/Dx(iel)];
    
    for i=1:no_nodes_el
        ii                              = nodes(iel,i);
        for j=1:no_nodes_el
            jj                          = nodes(iel,j);
            KM(ii,jj)                   = KM(ii,jj) + KM_loc(i,j);
            MM(ii,jj)                   = MM(ii,jj) + Dx(iel)*MM_loc(i,j); %%%NEW%%%
        end
        F(ii)                           = F(ii)     + F_loc(i);
    end
end

F_tot                                   =       F   + 1/dt*MM*Z; %%%NEW%%%
KK_TOT                                  = 1/dt*MM   +      KM; %%%NEW%%%

% zero gradient

U                     = chol(KK_TOT);
L                     = U';

Z                     = U\(L\F_tot);

% Dirichlet

% Free                 = 1:no_nodes;
% Free([1 no_nodes])   = [];
% Z                    = zeros(no_nodes,1);
% Z([1 no_nodes])      = [0 0];
% F_tot                = F_tot - KK_TOT*Z;
% 
% U                    = chol(KK_TOT(Free,Free));
% L                    = U';
% 
% Z(Free)              = U\(L\F_tot(Free));


end

