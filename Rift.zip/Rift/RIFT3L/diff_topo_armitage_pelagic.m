function [TopoXY,SP] = diff_topo_armitage_pelagic(TopoXY,GCOORD,SP,dt,ma,pelagic_rate,pelagic_type)
% [TOPOXY,SP] = DIFF_TOPO_ARMITAGE(TOPOXY,GCOORD,SP,DT,MA) takes current
% topography TOPOXY and calculates new topographies by diffusion taking
% into account the parameters defined by GCOORD, SP, DT and MA. This
% algorithm uses the finite element diffusion function
% function_nl_erosion_fixedelevation developed by John Armitage.



% Longitude of the model [m]
model_long  = max(GCOORD(1,:))-min(GCOORD(1,:));

% Make variables adimensional
De = SP.c*SP.alpha_sed*model_long^SP.nexp/SP.kappa;
Topography = TopoXY(2,:)';
Old_topo = TopoXY(2,:);
no_nodes_sed = size(Topography,1);
Rhs_sed = zeros(size(Topography));
Dx_sed = diff(TopoXY(1,:));
Dx_sed = Dx_sed'/model_long;
KK_SED = [1/3 1/6; 1/6 1/3];
dt_sed = 1e6*SP.dt*SP.kappa/(ma*model_long*model_long);
Topography = Topography/model_long;

% Number of sediment time steps to reach a mechanical time step
ntsteps_sed = dt/SP.dt;
% Calculates the size of the last time step
last_dts = SP.dt*(dt/SP.dt-floor(dt/SP.dt));
% Loop through the erosion/sedimentation time steps
for j = 1:ntsteps_sed+1
    % If it is the last sediment time step and the last_dts is
    % different from 0
    if j==ntsteps_sed+1 && last_dts~=0
        dt_sed = 1e6*last_dts*SP.kappa/(ma*model_long*model_long);
        % Pelagic
        tpelagic = pelagic(pelagic_rate,pelagic_type,TopoXY,dt_sed_dim);
        Topography = Topography + tpelagic'/model_long;
        
        % Calculating new topography
        Topography = function_nl_erosion_fixedelevation ...
            (Topography,no_nodes_sed,Rhs_sed,KK_SED,De,SP.nexp,dt_sed, ...
            Dx_sed);
        % If it is not the last time step
    elseif j<ntsteps_sed+1
        dt_sed_dim = dt_sed*(ma*model_long*model_long)/(1e6*SP.kappa);

        tpelagic = pelagic(pelagic_rate,pelagic_type,TopoXY,dt_sed_dim);
        Topography = Topography + tpelagic'/model_long;
        % Calculating new topography
        Topography = function_nl_erosion_fixedelevation ...
            (Topography,no_nodes_sed,Rhs_sed,KK_SED,De,SP.nexp,dt_sed, ...
            Dx_sed);
    end
end

% Redimensioning topography
Topography = Topography'*model_long;

TopoXY = [TopoXY(1,:); Topography];

% % Plot old and new topographies (uncomment)
% figure(2)
% plot(TopoXY(1,:)/1000,Old_topo/1000,'k')
% hold on
% plot(TopoXY(1,:)/1000,Topography/1000,'r')
function tpelagic = pelagic(pelagic_rate,pelagic_type,TopoXY,dt_sed)
switch pelagic_type
    case 'cnst'
        tpelagic = zeros(1,length(TopoXY));
        tpelagic(TopoXY(2,:)<=0) = pelagic_rate*dt_sed;
%         hold on
%         plot(TopoXY(1,:),TopoXY(2,:)+tpelagic,'xr')
    case 'var'
end

