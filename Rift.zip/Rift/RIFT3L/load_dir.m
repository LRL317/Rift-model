function [data_dir,triangle_dir,ssparse_dir] = load_dir(n)
% FIND WHICH COMPUTER THE TEST IS RUNNING AND SET UP THE DIRECTORIES

% For run triangle on Windows use a directory of the type:
% triangle_path = 'C:\Users\Trabajo\Dropbox\Codes\triangle\triangle.exe'

directory_model = pwd;
bar_pos = strfind(directory_model,'/');

switch directory_model((bar_pos(1)+1):(bar_pos(3)-1))
    case 'home/jason'
        data_dir = '/data/miguel/';
        triangle_dir = '/home/jason/miguel/';
        ssparse_dir = '/home/jason/miguel/';
    case 'home/miguel'
        [~,ncores] = system('nproc');
        if strcmp(ncores(1:2),'20')
            % If corresponds to the 20 core computers
            data_dir = '/data/miguel/';
            triangle_dir = '/home/miguel/';
            ssparse_dir = '/home/miguel/';
        else
            data_dir = '/data/disk1/archiveMIGUEL/';
            triangle_dir = '/home/miguel/Files/Dropbox/Codes/';
            ssparse_dir = '/home/miguel/Files/Dropbox/Codes';
        end
    case 'Users/miguel'
        switch n
            case 0
                data_dir = '/Users/miguel/data/';
            case 1
                data_dir = '/Volumes/disk1/data/';
            case 2
                data_dir = '/Volumes/disk2/data/';
        end
        triangle_dir = '/Users/miguel/Dropbox/Codes/';
        ssparse_dir = '/Users/miguel/Dropbox/Codes/';
    case 'home/mat1'
        data_dir = '/mlbraid/miguel/';
        triangle_dir = '/home/mat1/';
        ssparse_dir = '/home/mat1/';
    case 'home/mat2'
        data_dir = '/mldata/miguel/';
        triangle_dir = '/home/mat2/miguel/';
        ssparse_dir = '/home/mat2/miguel/';
end
