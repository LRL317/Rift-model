function T = thermal2d_m(ELEM2NODE, GCOORD, Phases, K, Rho, Cp, Hp, Hs, ...
    Temp, Bc_ind, Bc_val, dt, nip, reorder,Ce,Dplf,Dpl)
% THERMAL2D Two dimensional finite element thermal problem solver of MILAMIN

%   Part of MILAMIN: MATLAB-based FEM solver for large problems, Version 1.0
%   Copyright (C) 2007, M. Dabrowski, M. Krotkiewski, D.W. Schmid
%   University of Oslo, Physics of Geological Processes
%   http://milamin.org
%   See License file for terms of use.

%==========================================================================
% MODEL INFO
%==========================================================================
nnod         = max(ELEM2NODE(:));
nnodel       = size(ELEM2NODE,1);
nel          = size(ELEM2NODE,2);

%==========================================================================
% CONSTANTS
%==========================================================================
ndim         =   2;
nelblo       = 800;

%==========================================================================
% BLOCKING PARAMETERS (nelblo must be < nel)
%==========================================================================
nelblo       = min(nel, nelblo);
nblo         = ceil(nel/nelblo);

%==========================================================================
% PREPARE INTEGRATION POINTS & DERIVATIVES wrt LOCAL COORDINATES
%==========================================================================
[IP_X, IP_w] = ip_triangle(nip);
[N, dNdu]     = shp_deriv_triangle(IP_X, nnodel);

%==========================================================================
% DECLARE VARIABLES (ALLOCATE MEMORY)
%==========================================================================
K_all        = zeros(nnodel*(nnodel+1)/2,nel);
Rhs          = zeros(nnod,1);
Rhs_all      = zeros(nnodel,nel);
%==========================================================================
% INDICES EXTRACTING LOWER PART
%==========================================================================
indx_l       = tril(ones(nnodel)); indx_l = indx_l(:); indx_l = indx_l==1;


%==================================================================
% DECLARE VARIABLES (ALLOCATE MEMORY)
%==================================================================
K_block     = zeros(nelblo,nnodel*(nnodel+1)/2);
Rhs_block   = zeros(nelblo, nnodel);
invJx       = zeros(nelblo, ndim);
invJy       = zeros(nelblo, ndim);
il          = 1;
iu          = nelblo;

%==================================================================
% i) BLOCK LOOP - MATRIX COMPUTATION
%==================================================================
%         fprintf(1, 'MATRIX ASSEMBLY:    '); tic;
for ib = 1:nblo
    %==============================================================
    % ii) FETCH DATA OF ELEMENTS IN BLOCK
    %==============================================================
    ECOORD_x = reshape( GCOORD(1,ELEM2NODE(:,il:iu)), nnodel, nelblo);
    ECOORD_y = reshape( GCOORD(2,ELEM2NODE(:,il:iu)), nnodel, nelblo);
   % ED       = reshape( Rho(Phases(il:iu)).*Cp(Phases(il:iu)),nelblo,1);
    EK       = reshape( K(Phases(il:iu)),nelblo,1);
    EQ       = reshape( Hp(Phases(il:iu)),nelblo,1);
    HS       = Hs(il:iu,:);
    Temp_bl  = reshape( Temp(ELEM2NODE(:,il:iu)), nnodel, nelblo);
    %==============================================================
    % iii) INTEGRATION LOOP
    %==============================================================
    K_block(:)      = 0;
    Rhs_block(:)    = 0;
    for ip=1:nip    
        np=3;
        % TODO Take the density calculation out of the solvers
        %ERho = dens_temp(ELEM2NODE, Phases,Rho, Temp, np, Ce,il,iu,nip,ip);
        ERho = dens_temp_Dpl(ELEM2NODE, Phases,Rho, Temp,np, Ce,il,iu, nip,ip,Dpl,Dplf);
        ED       =  ERho.*Cp(Phases(il:iu));
        %==========================================================
        % iv) LOAD SHAPE FUNCTIONS DERIVATIVES FOR INTEGRATION POINT
        %==========================================================
        Ni          = N{ip};
        dNdui       = dNdu{ip};

        %==========================================================
        % v) CALCULATE JACOBIAN, ITS DETERMINANT AND INVERSE
        %==========================================================
        Jx          = ECOORD_x'*dNdui;
        Jy          = ECOORD_y'*dNdui;
        detJ        = Jx(:,1).*Jy(:,2) - Jx(:,2).*Jy(:,1);

        invdetJ     = 1.0./detJ;
        invJx(:,1)  = +Jy(:,2).*invdetJ;
        invJx(:,2)  = -Jy(:,1).*invdetJ;
        invJy(:,1)  = -Jx(:,2).*invdetJ;
        invJy(:,2)  = +Jx(:,1).*invdetJ;

        %==========================================================
        % vi) DERIVATIVES wrt GLOBAL COORDINATES
        %==========================================================
        dNdx        = invJx*dNdui';
        dNdy        = invJy*dNdui';

        %==========================================================
        % vii) NUMERICAL INTEGRATION OF ELEMENT MATRICES
        %==========================================================
        weight      = IP_w(ip)*detJ;
        % N_lumped    = diag(sum(Ni*Ni',2)); For temperature it can work
        % faster but needs only 3 node elements.

        indx = 1;
        for i = 1:nnodel
            for j = i:nnodel
                K_block(:,indx)  =   K_block(:,indx) + ...
                    dt*(dNdx(:,i).*dNdx(:,j)+ dNdy(:,i).*dNdy(:,j)).*(weight.*EK)...
                    + Ni(i).*weight.*ED*Ni(j);
                indx = indx + 1;
            end
        end

        %RIGHT HAND SIDE
        Rhs_block  = Rhs_block + (Ni*(Ni'*Temp_bl.*weight'.*ED'))' + ...
            (Ni*(dt*(EQ + HS(:,ip)).*weight)')';

    end
    %==============================================================
    % ix) WRITE DATA INTO GLOBAL STORAGE
    %==============================================================
    K_all(:,il:iu)	  = K_block';
    Rhs_all(:,il:iu)  = Rhs_block';
    %==============================================================
    % READJUST START, END AND SIZE OF BLOCK. REALLOCATE MEMORY
    %==============================================================
    il  = il + nelblo;
    if(ib==nblo-1)
        nelblo 	  = nel-iu;
        K_block	  = zeros(nelblo, nnodel*(nnodel+1)/2);
        Rhs_block = zeros(nelblo, nnodel);
        invJx     = zeros(nelblo, ndim);
        invJy     = zeros(nelblo, ndim);
    end
    iu  = iu + nelblo;
end

%==========================================================================
% ix) CREATE TRIPLET FORMAT INDICES
%==========================================================================
% fprintf(1, 'TRIPLET INDICES:    '); tic
indx_j = repmat(1:nnodel,nnodel,1); indx_i = indx_j';
indx_i = tril(indx_i); indx_i = indx_i(:); indx_i = indx_i(indx_i>0);
indx_j = tril(indx_j); indx_j = indx_j(:); indx_j = indx_j(indx_j>0);

K_i = ELEM2NODE(indx_i,:); K_i = K_i(:);
K_j = ELEM2NODE(indx_j,:); K_j = K_j(:);

indx       = K_i < K_j;
tmp        = K_j(indx);
K_j(indx)  = K_i(indx);
K_i(indx)  = tmp;
% fprintf(1, [num2str(toc),'\n']);

%==========================================================================
% x) CONVERT TRIPLET DATA TO SPARSE MATRIX
%==========================================================================
% fprintf(1, 'SPARSIFICATION:     '); tic
K_all  = K_all(:);
K      = sparse2(K_i, K_j, K_all);
Rhs    = accumarray(ELEM2NODE(:), Rhs_all(:));
clear K_i K_j K_all Rhs_all;
% fprintf(1, [num2str(toc),'\n']);

%==========================================================================
% BOUNDARY CONDITIONS
%==========================================================================
% fprintf(1, 'BDRY CONDITIONS:    '); tic;
Free        = 1:nnod;
Free(Bc_ind)= [];
TMP         = K(:,Bc_ind) + cs_transpose(K(Bc_ind,:));
Rhs         = Rhs - TMP*Bc_val';
K           = K(Free,Free);
% fprintf(1, [num2str(toc),'\n']);

%==========================================================================
% REORDERING
%==========================================================================
% fprintf(1, 'REORDERING:         '); tic;
switch reorder
    case 'metis'
        perm = metis(K);
    case 'amd'
        perm = amd(K);
    otherwise
        error('Unknown reordering')
end
% fprintf(1, [num2str(toc),'\n']);

%==========================================================================
% FACTORIZATION - ideally L = lchol(K, perm)
%==========================================================================
% fprintf(1, 'FACTORIZATION:      '); tic;
K = cs_transpose(K);
K = cs_symperm(K,perm);
K = cs_transpose(K);
L = lchol(K);
% fprintf(1, [num2str(toc,'%8.6f'),'\n']);

%==========================================================================
% SOLVE
%==========================================================================
% fprintf(1, 'SOLVE:              '); tic;
T             = zeros(1,nnod);
T(Bc_ind)     = Bc_val;
T(Free(perm)) = cs_ltsolve(L,cs_lsolve(L,Rhs(Free(perm))));
% fprintf(1, [num2str(toc,'%8.6f'),'\n']);
