                                                                                                                                                                                                                %%TEST FLUID2D_SOLVER
%   Part of MILAMIN: MATLAB-based FEM solver for large problems, Version 1.0
%   Copyright (C) 2007, M. Dabrowski, M. Krotkiewski, D.W. Schmid
%   University of Oslo, Physics of Geological Processes
%   http://milamin.org
%   See License file for terms of use.

%   Edited by Miguel Andres-Martinez, PhD student at Royal Holloway
%   University of London. Earth Sciences Department. This version includes:
%       - Free surface algorithm
%       - Friction angle, cohestion and viscous strain weakening
%       - Elasticity
%       - Discontinuous layers
%       - Varying rheologies along a phase
%       - Melting (Marta Perez-Gussinye)
%       - Dike/sill emplacement and postsolidification heat release 
%           (Elena Ros)
%       - Density dependent on temperature and depletion (Elena Ros and
%           Marta Perez-Gussinye)
%       - Random Pef (Miguel Andres-Martinez)
%       - Viscous strain weakening dependent on temperature (Albert de 
%           Monserrat, Leon Liu and Elena Ros)
%       - Water load (Miguel Andres-Martinez)

%==========================================================================
% CLEARING AND INITIALIZATION
%==========================================================================

%CLEAR ENVIRONMENT, BUT NOT BREAKPOINTS
%try close (wait_bar); end;
clc; clear variables;

%SET THE DEFAULT ROOT RENDERER TO ZBUFFER,
set(0, 'DefaultFigureRenderer', 'zbuffer');

wb = 0; % Set to 0 or 1 to run the model with or without waitbar 
    % respectively

loadsave = 'y'; % 'n' to initialize all the variables and input and run the
    % the code and 'y' to load a previews save and run the code.

%[data_dir,triangle_dir,ssparse_dir] = load_dir(0);
loadsave_file = '/_';

switch loadsave
    case 'y'

%==========================================================================
%% USER INPUT:
%==========================================================================

%% SETTINGS
%%      - Saving options                                            
%--------------------------------------------------------------------------
% save_choice = 'cont' for saving each time step and 'dis' for saving only 
% n_saves ammount of time steps
save_choice = 'dis'; 
% Number of saves along the time
n_saves = 1000;
% Directory of the saved file
directory = '';
% Name of the saved file
name = '_';
% Switch for saves in all time steps when save_choice = 'dis':
%   'overwrite' -   saves every time step overwritting the previous one.
%                   The name of the overwritten file is always the one of
%                   the variable name. When the step corresponds to a
%                   saving 'dis' defined by n_saves, does not overwrite the
%                   file and instead writes a file with the [name,istep].
%                   This option is good for only preserving discontinuous
%                   saves but to be able to always resume a model from
%                   where it stoped loading name file.
%
%   'partial' -     saves standard discontinuous time steps as [name,istep]
%                   and saves in the remaining steps the variables
%                   specified by sav_var_part under the name of
%                   [name,'p',istep]. This is usefull for example for
%                   saving velocities and the mesh to do a later post-
%                   processing to follow faults.
%
%   'never' -       never saves in steps that are not defined by n_saves.
sav_every_step = 'overwrite';
% List of variables to save in case sav_every_step = 'partial'
sav_var_part = {'GCOORD','ELEM2NODE','Point_id','dt','DISPL','nel', ...
    'istep','ma','Corner_id','Cornin_id','ISOCHRONS','Basement', ...
    'tp_isoc','E2all','km'};
%--------------------------------------------------------------------------
%%      - General settings                                          
%--------------------------------------------------------------------------
% tstep_type = 'cnst' for a constant time step defined by dt and 'courant'
% for a courant time step criteria:
%             dt = C*(min(inc_surface_element)/max(velocity)).
tstep_type  = 'cnst';
% Courant time step criteria
C           = 0.025;

% plot_s = 'y' to plot and 'n' to not plot
plot_s = 'n';

% Defines the display position of the wait bar
waitbar_pos = [2536.9 338 304.9 63.5];

% Triangle path
triangle_path = '/dynamic/triangle/triangle';
% Triangle mode (choose between 'text' and 'binary')
mode = 'text';

% Mutils path
mutils_path = '/dynamic/mutils-0.4-2/';
%--------------------------------------------------------------------------
%%      - Units                                                     
%--------------------------------------------------------------------------
km      = 1000;
ma      = 1e6*365.25*24*60*60;
year    = 365*24*60*60;
prec    = 1e2;
mpa     = 1e6;
%--------------------------------------------------------------------------

%% PHYSICS
%%      - Constants                                                 
%--------------------------------------------------------------------------
R       = 8.3143; % Gas constant
G       = [0; -9.8]; %Gravity
%--------------------------------------------------------------------------
%%      - Time                                                      
%--------------------------------------------------------------------------
% Time step
dt          = 0.01*ma;
% Time interval
time_int    = 100*ma; % Time interval for the model.
% Number of steps
steps       = time_int/dt;

% Break up conditions
% -------------------
% Moho id
BREAKUP.mid = 3;
% Crustal thickness for which the model is considered to be on break-up
BREAKUP.min_thick = 100;
% Time interval that passes after meeting the break-up condition, before
% stopping the model
BREAKUP.break_time = 7*ma;
%--------------------------------------------------------------------------
%%      - Thermal parameters                                        
%--------------------------------------------------------------------------
K           = [3.3;            2.5;            2.1];
Cp          = [1200; 1200; 1200];
Hp          = [0; 0.2e-6; 1.3e-6]; %./[1000; 1000; 1000]./Rho;
Ce          = [3.0;            2.4;            2.4]*1e-5;
Dplf         = 0.04; %Parameter to parameterize change of rho due to melting (value for garnet, below ~60 km at mid-ocean ridges)
%--------------------------------------------------------------------------
%%      - Rheologies                                                
%%          * Olivine preexponential factors                        
%--------------------------------------------------------------------------
% WET DIFFUSION AND DISLOCATION PARAMETERS FOR OLIVINE
Ndis_w        = 3.5;                % Power law exponent
Adis_w        = 90*(1e6)^(-Ndis_w); % Pa^-n*s^-1   
Qdis_w        = 480e3;       % Activation energy
Vdis_w        = 10e-6;

Ndif_w        = 1;           % Power law e=xponent
Adif_w        = 1e6*(1e6)^(-Ndif_w);  % Pa^-1*s^-1
Qdif_w        = 335e3;       % Activation energy
Vdif_w        = 4e-6;

% DRY DIFFUSION AND DISLOCATION PARAMETERS
Ndis_d        = 3.5;         % Power law exponent
Adis_d        = 1.1e5*(1e6)^(-Ndis_d);       % Pa^-n*s^-1
Qdis_d        = 530e3;       % Activation energy
Vdis_d        = 13e-6;

Ndif_d        = 1;          % Power law exponent
Adif_d        = 1.5e9*(1e6)^(-Ndif_d);      % Pa^-1*s^-1
Qdif_d        = 375e3;      % Activation energy
Vdif_d        = 6e-6;

m = 3; 
f = 125; %fugacity ppm ; H/Si
d= 6000;%6mm in microns
Bdis_w = Adis_w*f^(1.2);
Bdif_w = Adif_w.*d.^(-m)*f^1;
Bdis_d = Adis_d;
Bdif_d = Adif_d.*d.^(-m);
%--------------------------------------------------------------------------
%%          * General rheological parameters                        
%--------------------------------------------------------------------------
%DISLOCATION

%MAFIC GRANULITE LOWER CRUST (WET OLIVINE TO DRY OLIVINE MANTLE)
%'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
%MANTLE VALUES FROM HIRTH AND KOHLSTEDT 2003 (WET TO DRY OLIVINE)
%LOWER CRUST VALUES FROM WILKS AND KARTER 1990 (MAFIC GRANULITE)
%UPPER CRUST VALUES FROM GLEASON AND TULLIS 1995 (WET QUARTZITE)
% RHEOL.Adis  = [ Bdis_w          Bdis_d; ...
%                10^(-21.05)     10^(-21.05); ...
%                10^(-28.00)     10^(-28.00)]; % Pa^-n*s^-1
% RHEOL.Ndis  = [ 3.5             3.5; ...
%                4.2             4.2; ...
%                4.0             4.0]; % Power law exponent
% RHEOL.Qdis  = [ 480e3           530e3; ...
%                445e3           445e3; ...
%                223e3           223e3]; % Activation energy
% RHEOL.Vdis  = [ 10e-6           13e-6; ...
%                0                 0; ...
%                0                 0]; % Activation volume

% %WET ANORTHITE LOWER CRUST (WET OLIVINE TO DRY OLIVINE MANTLE)
% %'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
% %MANTLE VALUES FROM HIRTH AND KOHLSTEDT 2003 (WET TO DRY OLIVINE)
% %LOWER CRUST VALUES FROM RYBACKI AND DRESEN 2000 (WET ANORTHITE)
% %UPPER CRUST VALUES FROM GLEASON AND TULLIS 1995 (WET QUARTZITE)
% RHEOL.Adis  = [ Bdis_w          Bdis_d; ...
%                 10^(-15.40)     10^(-15.40); ...
%                 10^(-28.00)     10^(-28.00)]; % Pa^-n*s^-1
% RHEOL.Ndis  = [ 3.5             3.5; ...
%                 3.0             3.0; ...
%                 4.0             4.0]; % Power law exponent
% RHEOL.Qdis  = [ 480e3           530e3; ...
%                 356e3           356e3; ...
%                 223e3           223e3]; % Activation energy
% RHEOL.Vdis  = [ 10e-6           13e-6; ...
%                 0                 0; ...
%                 0                 0]; % Activation volume

% %WET QUARTZITE LOWER CRUST (WET OLIVINE TO DRY OLIVINE MANTLE)
% %'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
% %MANTLE VALUES FROM HIRTH AND KOHLSTEDT 2003 (WET TO DRY OLIVINE)
% %LOWER CRUST VALUES FROM GLEASON AND TULLIS 1995 (WET QUARTZITE)
% %UPPER CRUST VALUES FROM GLEASON AND TULLIS 1995 (WET QUARTZITE)
RHEOL.Adis  = [ Bdis_w          Bdis_d; ...
                10^(-28.00)     10^(-28.00); ...
                10^(-28.00)     10^(-28.00)]; % Pa^-n*s^-1
RHEOL.Ndis  = [ 3.5             3.5; ...
                4.0             4.0; ...
                4.0             4.0]; % Power law exponent
RHEOL.Qdis  = [ 480e3           530e3; ...
                223e3           223e3; ...
                223e3           223e3]; % Activation energy
RHEOL.Vdis  = [ 10e-6           13e-6; ...
                0                 0; ...
                0                 0]; % Activation volume

%DIFFUSION FLOW LAWS ARE ALL FOR OLIVINE
RHEOL.Adif  = [ Bdif_w      	Bdif_d; ...
                0               0; ...
                0               0]; % Pa^-1*s^-1
RHEOL.Ndif  = [ 1               1; ...
                0               0; ...
                0               0]; % Power law exponent
RHEOL.Qdif  = [ 335e3           375e3; ...
                0               0; ...
                0               0]; % Activation energy
RHEOL.Vdif  = [ 4e-6            6e-6; ...
                0               0; ...
                0               0]; % Activation volume

Grain       = 1;
Burger      = 1;
Shearm      = [74e9;           40e9;           36e9]; 
    % 1 for Hirth because is included inside A
    
% Input function for rheology changes inside the same phase (need to be
% specified in case of more than one column in A, N and Q
rheol_var_f = 'rheol_var_Dpl_new';

% Switch to apply elasticity 1 or to not apply it 0
elasticity_s = 1;

% Switch to apply shear heating 1 or to not apply it 0
sh_s = 1;
%--------------------------------------------------------------------------
%%      - Mohr-Coulomb criteria and strain weakening parameters     
%--------------------------------------------------------------------------
% Type of plasticity to choose among 'maxwell', 'moresi' and 'no'
% plasticity
plasticity_t = 'maxwell';

% Friction angle
Phi = [30].*(2*pi)/360;
% Cohesion
Cohesion = 10*mpa; % Make sure this value is equal to SS.C(1)

% STRAIN SOFTENING
% ================
% Friction angle reduction
% ------------------------
% Layers where friction angle strain softening is applied, 1 is the lower 
% layer and 4 is the upper layer. Set and empty vector [] for no 
% softening
SS.Phases_phi = [1 2 3];
% Range of the friction angle for the strain softening
SS.Phi = [Phi; 15*(2*pi)/360];
% Range of the accumulated second invariant of the strain where strain 
% softening is applied
SS.I2_phi = [0 1];

% Cohesion reduction
% ------------------
% Layers where cohesion strain softening is applied, 1 is the lower 
% layer and 4 is the upper layer. Set and empty vector [] for no 
% softening
SS.Phases_c = [];
% Range of the cohesion for the strain softening
SS.C = [Cohesion; 10*mpa];
% Range of the accumulated second invariant of the strain where strain 
% softening is applied
SS.I2_c = [0 1];

% Viscousity preexponential factor dislocation
% --------------------------------------------
% Layers where viscous softening is applied, 1 is the lower 
% layer and 4 is the upper layer. Set and empty vector [] for no 
% softening
SS.Phases_pef_dis = [1 2 3];
% Range of the preexponential factor for the strain softening
SS.Pef_dis = [1 30];
% Range of the accumulated second invariant of the strain where strain 
% softening is applied
SS.I2_pef_dis = [0 1];

% Viscousity preexponential factor diffusion
% ------------------------------------------
% Layers where viscous softening is applied, 1 is the lower 
% layer and 4 is the upper layer. Set and empty vector [] for no 
% softening
SS.Phases_pef_dif = [1 2 3];
% Range of the preexponential factor for the strain softening
SS.Pef_dif = [1 30];
% Range of the accumulated second invariant of the strain where strain 
% softening is applied
SS.I2_pef_dif = [0 1];

% Viscous softening dependency of the temperature
% -----------------------------------------------
% Set ss_dep_t to 0 if softening dependence on temperature is not needed
% and 1 if softening dependence on temperature is needed
SS.ss_dep_t = 1;
% Diffusion
SS.dif_low_lim = 800;
SS.dif_upp_lim = 1200;
% Dislocation
SS.dis_low_lim = 800;
SS.dis_upp_lim = 1200;

% % Run to check that the softening factor for the pef is correct
% pef_softening_function_check
%--------------------------------------------------------------------------
%%      - Random damage                                             
%--------------------------------------------------------------------------
% Switch to activate damage randomization 1 or to deactivate it 0. At the
% moment it only supports random damage at the friction angle.
SS.rand_s = 0;
% Variation from Phi1 in the randomization SS.Phi_var/2 above and 
% SS.Phi_var/2 below
SS.Phi_var = 4.*(2*pi)/360;
%--------------------------------------------------------------------------
%%      - Other physical properties                                 
%--------------------------------------------------------------------------
Rho = [3300; 2850; 2700]; % Density
%--------------------------------------------------------------------------

%% BOUNDARY CONDITIONS
%%      - Temperature                                               
%--------------------------------------------------------------------------
% Lower boundary condition
% 1) depth
temp_bc_depth = -400*km;
% 2) temperature
temp_bc = 1300;
% 3) depth boundary condition for the initial profile
temp_bc_depth_ini = -120*km;
% 4) temperature bundary condition for the intial profile
temp_bc_ini = 1300;

% Upper boundary condition
% 1) temperature
temp_surf = 0;

% If load_T = 1 loads initial temperatures from a regular grid (i.e.
% calculated with SteadyTempGUI.m and TransientGUI.m thermal solvers)
load_T = 0;
% Tini_dir is the file including the regular mesh and the temperature if
% load_T = 1
Tini_dir = '';
% Function to load temperature
Tini_load = '';
%--------------------------------------------------------------------------
%%      - Mechanical                                                
%--------------------------------------------------------------------------
% bc_v = 'ext_rate' for boundaries defined by extendion velocities and
% 'ext_erate' for boundaries defined by extension strain rate
bc_v = 'ext_rate'; 
% Half extension velocity in m/s (to be used when bc_v = 'ext_rate')
ext_rate    = 0.005/(365*24*60*60); 
% Half extension rate (to be used when bc_v = 'ext_erate')
ext_erate   = 5e-16;
%--------------------------------------------------------------------------
%%          * Top surface (free slip/free surface)                  
%--------------------------------------------------------------------------
% top_surface = 'fs' for the top surface of the model act as a free surface
% topsurface = 'fix' for the top surface of the model act as a x-fixed to 
% 0 surface (free-slip)
top_surface = 'fs';
% A value of 0 is more accurate but less stable. A value of 0.5 is less
% accurate but more stable. 2/3 is proven to be the optimal
% (Andres-Martinez,TODO)
alpha       = 2/3; 
% Parameter for controling the influence of the free surface x-term in the 
% calculation of the average of h for the future step for the free surface.
beta        = 0;
%--------------------------------------------------------------------------

%% INITIAL CONDITIONS
%%      - Geometry                                                  
%--------------------------------------------------------------------------
x_max =  200*km;
x_min =  -200*km;
%layer 1
y_min1 = -400*km;
y_max1 = -35*km;
%layer 2
y_max2 = -17.5*km;
%layer 3
y_max3 =  0*km;
% Base lithosphere
base_lithos = -120*km;
Ylim = [y_min1, y_max1, y_max2, y_max3];

% Resolution
% ----------
% Randomized increment for crustal resolution varying from 50 to -50 m to
% generate different meshes. For this option to be active set
% randomize_mesh = 1
randomize_mesh = 0;
rng('default');
r_inc = (diff([1 100])*rand-50)*randomize_mesh;

UCR = 1*km+r_inc; % Upper crust resolution in km
LCR = 1*km+r_inc; % Lower crust resolution in km
DWOM = 5*km; % Dry and wet olivine mantle in km
% Number of points at the boundaries
cont_points = [floor((x_max-x_min)/DWOM) floor((y_max1-y_min1)/DWOM) ...
    floor((x_max-x_min)/UCR) ...
    floor((y_max2-y_max1)/LCR) floor((x_max-x_min)/UCR) ...
    floor((y_max3-y_max2)/UCR) floor((x_max-x_min)/UCR)]+1; 
% Number of points on geometry contours for ordered as follows:
%       __7__
%            |
%       __5__|6
%            |
%       __3__|4
%            |
%       __1__|2
Elsizes     = [DWOM^2 LCR^2 UCR^2]; % [1e8 1e7 1e7 1e7]

% Function to generate geometries. Note that the default 'make_geometry' 
% needs of the geometric parameters declared above. Another geometric 
% function should be treated as an input for the main and should contain 
% the necessary geometric parameters to generate an output with the format 
% [GEOMETRY,Geo_id,cont_points,Elsizes,x_min,x_max]
geom = 'make_geometry';

% Switch for the different functions used to deal with too thin layers and
% intersections of interfaces, 'dis_layers' for real discontinuous layers
% or 'lineintersect' for layers no thinner than shift
intersect_s = 'lineintersect';
% Smaller distance between two interfaces. When the distance is smaller
% either 'dis_layers' removes the layer in this area or 'lineintersect'
% fixes the thickness of the layer at a distance shift
shift = 100;
%--------------------------------------------------------------------------
%%      - Deformation seed                                          
%--------------------------------------------------------------------------
% ini_deformation is a switch to define different initial topographies for 
% the interfaces:
%       0 - Flat topographies
%       1 - Sinusoidal topography only for the Moho
%       2 - Sinusoidal topography for the Moho and resulting 
%           topography for the surface
%       3 - No initial topography for any interfaces, but increment of 
%           temperature on the center of the model with vertical and
%           horizontal gaussian shape
%       4 - Boundary conditions for the temperature elevated for the
%           center of the model (necking of the lithosphere)
%       5 - Damage weak seed
%       6 - Random damage seed. To use this option remember to activate
%           random damage (SS.rand_s = 1) and to select the RDWS.function
%           and its parameters
ini_deformation = 3;
GVAR.idf = ini_deformation;

% Parameters for the initial topography at the moho for initiating the
% deformation (ini_deformation = 1, 2)
sigma_moho = 20*km;
topo_moho = -4*km;

% Parameters for the temperature initializer of the deformation
% (ini_deformation = 3 and 4)
sigma_tx = 10*km; % Wide of the Gaussian function along x (ini_deformation
% 3 and 4). The temperature seed atenuates with around the depth
% depth_t_seed. The atenuation is applied applying a Gaussian function to 
% calculate the amplitude of the x-Gaussian, which maximum would be
% max_amp_t and wide would be sigma_tz.
sigma_tz = 20*km;
max_amp_t = 100; % Kelvin
depth_t_seed = -35*km;
dist_wst = 0*km;

% Parameters for the damage weak seed (ini_deformation = 5)
WS.damage = 1; % In terms of strain rate
WS.size = 2.5*km; % Radius of the area affected by the damage [m]
WS.coord = [0*km -42.5*km];
WS.time = Inf; % Time step to stop



% Parameters for the random damage weak seed (ini_deformation = 6)
RDWS.function = 'gaussian_band_rand_damage';
RDWS.sigma = 10*km; % Wave length (km)
RDWS.factor = 1.25; % Factor that multiplies the randomization (amplitude)
%--------------------------------------------------------------------------

%% MELTING    
%%      - Parameters                                                
%--------------------------------------------------------------------------
% Melt 
MELT_s = 0;
% Melt density [kg/m^3]
Rho_melt = 2900;
% Emplacement temperature?
T_melt = 1100 + 278; %(Tm'= Tm + L/(Cp*rho)) %Wangen- Magnus

% Other parameters
[Ts,iTs,Vol0,~,X0,nc,Ts0,dTs_dP,dTs_dF,QL,aX,bX,dzmax,ad_K_km, ...
    Vol_ex,Dbulk,p2z,z2p,ad_K_GPa ] = parameters_melt(Rho);

% Melt interpolation in nodes'areas ('area_nod')or into a regular grid ('reg_grid').
melt_interpolation = 'area_nod';
% Igneous body located below the Moho at each time step: as a column ('dike')
% or as a horizontal layer ('sill').
igneous_body = 'dike';
% Release of heat from the melting below the Moho: 'y' or 'n' (yes/no)
heat_release = 'n';
%--------------------------------------------------------------------------

%% SURFACE PROCESSES    
%%      - Settings                                                  
%--------------------------------------------------------------------------
% If surface processes are needed to be computed surf_proc_s = 1, on the
% contrary surf_proc_s = 0
surf_proc_s = 0;

% If isochrons are needed to be tracked with the displacements set tp_isoc
% to be 1. This slows down the model. If set 0 the model will be faster but
% isochrons would not be tracked
tp_isoc = 1;

% Time steps between isochrons to save
iso_sav = 10;

% Function to calculate erosion and sedimentation
surf_proc_func = 'diff_topo_armitage';
%--------------------------------------------------------------------------
%%      - Parameters                                                
%--------------------------------------------------------------------------
% Time step for the surface processes
SP.dt = 0.001*ma;
% Hill-slope diffusion [m^2/yr]
SP.kappa = 0.25;
% Discharge transport coefficient
SP.c = 1e-3;
% Inverse Hack's law
SP.nexp = 1;
% Precipitation rate
SP.alpha_sed = 1;
% Pelagic sedimentation type, 'cnst' for constant or 'var' for a function1
SP.pelagic_t = 'cnst';
% Pelagic sedimentation rate [m^2/yr]
SP.pelagic_rate = 0;
%--------------------------------------------------------------------------
%%      - Sea level                                                 
%--------------------------------------------------------------------------
% Density of water [kg/m^3] (set 0 for no sea level load)
rho_w = 0;
% Sea level [m]
sea_level = 0;
%--------------------------------------------------------------------------

%% TRACK POINTS                                                     
%--------------------------------------------------------------------------
tp_choice = 1; % 1 to track points along time steps and 0
    % to not track points.

% I      n order to initialize track points and tracers, a matrix TRACKP needs to
% be defined. This matrix have the size (number of dimensions x number of
% track points).
%
% Example:
%
% To create a rectangular mesh at the surface from -5 km to 5 km at the
% horizontal and 5 km depth:

% tp_x = (-20:0.5:0)*km; % X initial distribution of the tracked points
% tp_y = (-10:0.5:-2.3)*km; % Y initial distribution of the tracked points
% [TP_x,TP_y] = meshgrid(tp_x,tp_y); % Calculates a regular mesh
% TRACKP{1} = [TP_x(:)'; TP_y(:)']; % Defines track points
% 
% % Creates rectangular-element indexes for the tracking points
% E2N_TP(1,:) = 1:length(tp_y):((length(tp_x)-1)*length(tp_y));
% E2N_TP(2,:) = 2:length(tp_y):((length(tp_x)-1)*length(tp_y));
% E2N_TP(3,:) = length(tp_y)+2:length(tp_y):((length(tp_x))*length(tp_y));
% E2N_TP(4,:) = length(tp_y)+1:length(tp_y):((length(tp_x))*length(tp_y));
% E2N_TP = repmat(E2N_TP,1,length(tp_y)-1);
% ADD_INDEX = repmat((0:length(tp_y)-2),length(tp_x)-1,1);
% ADD_INDEX = repmat(ADD_INDEX(:)',4,1);
% E2N_TP = E2N_TP + ADD_INDEX;

% % Creates line indexes for the tracking points
% tp_x = linspace(x_min,x_max,cont_points(7)); 
%     % X initial distribution of the tracked points
% tp_y = base_lithos*ones(size(tp_x));
%     % Y initial distribution of the tracked points
% TRACKP = [tp_x; tp_y]; % Defines track points
% % LINES_TP = repmat((1:length(tp_y))',1,length(tp_x)); 
% % LINES_TP = LINES_TP(:);

% LAB TRACK
res_tp = 2*km;
TRACKP = [x_min:res_tp:x_max; base_lithos*ones(size(x_min:res_tp:x_max))];
%--------------------------------------------------------------------------
%%      - Melting                                                   
%--------------------------------------------------------------------------
% Switch to track melting once in the surface
tp_melt = 0;
TRACKP_melt =[];
%--------------------------------------------------------------------------

%% INITIAL SETUP

%==========================================================================
% DIRECTORIES
%==========================================================================

mkdir(directory);
mkdir('Mesh');
addpath(directory);
addpath(genpath(mutils_path));
addpath('Input')

%==========================================================================
% MESH GENERATION:
%==========================================================================
fprintf(1, 'PREPROCESSING:      '); tic

% Create an specific name for the triangle output
bars = findstr(directory,'/');
meshname = ['Mesh/',directory(bars(end)+1:end)];

Intersect_ID = [];
Sgap = [];

%GEOMETRY

if strcmp('make_geometry',geom)
%     [GEOMETRY, Geo_id] = make_geometry(x_min, x_max,y_min1, y_max1, y_max2, ...
%         y_max3, y_max4, cont_points, ini_deformation, Rho, sigma_moho, ...
%         topo_moho);
[GEOMETRY, Geo_id] = make_geometry3l(x_min, x_max,y_min1, y_max1, y_max2, ...
        y_max3, cont_points, ini_deformation, Rho, sigma_moho, ...
        topo_moho);
else
    % 'geom' function should contain its own geometric parameters
    make_geom_handle = str2func(geom);
    [GEOMETRY,Geo_id,cont_points,Elsizes,x_min,x_max] = make_geom_handle();
end

[GCOORD,ELEM2NODE, Point_id,Phases] = generate_mesh3l(GEOMETRY,Geo_id,...
    Elsizes,Sgap,mode,triangle_path,meshname);

nnod    = size(GCOORD,2);
ndof    = size(GCOORD,1);
nel     = size(ELEM2NODE,2);

%add 7th node
ELEM2NODE(7,:)  = nnod+1:nnod+nel;
GCOORD          = [GCOORD, [...
    mean(reshape(GCOORD(1, ELEM2NODE(1:3,:)), 3, nel));...
    mean(reshape(GCOORD(2, ELEM2NODE(1:3,:)), 3, nel))]];

nnod    = size(GCOORD,2);

%FIND GEOMETRY MARKERS
Geo_mark   = 1:size(GEOMETRY,2);

%==========================================================================
% BOUNDARY CONDITION: PURE SHEAR
%==========================================================================
% CORNER NODES
prec = 1e2;
Layer1_id   = find(Geo_id==1);
Layer9_id   = find(Geo_id==9);

CORNERS     = [GEOMETRY(:,Layer1_id(1)) ...
    GEOMETRY(:,Layer1_id(end)) GEOMETRY(:,Layer9_id(1)) ...
    GEOMETRY(:,Layer9_id(end))];
Corner_id   = find(ismember((round(prec*GCOORD))', (round(prec*CORNERS))','rows')==1)';

Layer3_id   = find(Geo_id==3);
Layer6_id   = find(Geo_id==6);

CORNERS_IN  = [GEOMETRY(:,Layer3_id(1)) GEOMETRY(:,Layer6_id(1)) ...
    GEOMETRY(:,Layer6_id(end))  GEOMETRY(:,Layer3_id(end))];
Cornin_id   = find(ismember((round(prec*GCOORD))', (round(prec*CORNERS_IN))','rows')==1)';


% Reset boundary conditions
[Bc_ind, Bc_val, Point_id, Bc_ind_fs, Bc_val_fs, ext_erate] = ...
    set_bcs_flow3l(GCOORD, Corner_id, Cornin_id, Point_id, ext_erate, ...
    ext_rate, bc_v);


fprintf(1, [num2str(toc,'%8.6f')]);
fprintf(1, ['\n Number of nodes:   ', num2str(nnod)]);
fprintf(1, ['\n Number of elems:   ', num2str(nel),'\n']);
    
%==========================================================================
% SOLVER
%  nip                - Number of integration points (6 or higher)
% (reorder = 'amd')   - AMD reordering
% (reorder = 'metis') - METIS reordering
% (method = 'std')    - Standard matrix computation
% (method = 'opt')    - Optimized matrix computation
%==========================================================================
nip             =       6;
reorder         =   'amd';
method          =   'opt';
%STORAGE
thick_swell0    = max(GCOORD(2,Point_id==9)) - min(GCOORD(2,Point_id==3));
thick_neck0     = min(GCOORD(2,Point_id==9)) - max(GCOORD(2,Point_id==3));
thick_swell     = zeros(1,steps);
thick_neck      = zeros(1,steps);
extension       = zeros(1,steps);
E2all           = ones(nel,nip)*ext_erate;
Mu_all          = zeros(nel,nip);
Mu_b_all        = zeros(nel,nip);
Mu_dis_all      = zeros(nel,nip);
Mu_dif_all      = zeros(nel,nip);
RHEOL.var       = ones(nel,1);
% Initialazing accumulated gradient of deformation
F_xx = ones(nel, nip);
F_xy = zeros(nel,nip);
F_yx = zeros(nel,nip);
F_yy = ones(nel,nip);
I2 = zeros(nel,nip);
% Initialazing eneu and theta for the elasticity
THETA_all       = zeros(nel,nip);           %viscosity at integration points - needed for initial power law guess
TAU_xx_old      = zeros(nel,nip);
TAU_yy_old      = zeros(nel,nip);
TAU_xy_old      = zeros(nel,nip);
Hs              = zeros(nel,nip);
ttotal = 0;
track_remesh = []; 
BREAKUP.bool = 0;
nw_it = [];
% Declare isochrons rows: 1) x-coordinates, 2) y-coordinates, 3) step
% index, 4) erosion/deposited depth
UpCorners = find(Point_id==-1,2,'last');
ISOCHRONS = [GCOORD(:,max(Point_id)-1==Point_id) GCOORD(:,UpCorners); ...
    zeros(1,sum(max(Point_id)-1==Point_id)+2)];
[ISOCHRONS(1,:),indx_isoc] = sort(ISOCHRONS(1,:));
ISOCHRONS(2,:) = ISOCHRONS(2,indx_isoc);
ISOCHRONS = [ISOCHRONS; ISOCHRONS(2,:)];
Basement = ISOCHRONS(1:2,:);
Tris_isoc = 0;
% ISOCHRONS = [];

%GROWTH RATE
Layer9_id   = [find(Point_id==9) Cornin_id(4)];
a_ori        = max(GCOORD(2,Layer9_id)) - min(GCOORD(2,Layer9_id));

% Calculate random damage
if SS.rand_s==1
    if ini_deformation==6
        RDWS_handle = str2func(RDWS.function);
        SS = RDWS_handle(SS,RDWS,GCOORD,ELEM2NODE,nip);
    else
        SS.RDWS_factor = ones(nel,nip);
    end
    SS = random_damage_WS(SS,nel,nip);
%     % Plot (uncomment)
%     plot(GCOORD(1,ELEM2NODE(7,:))',SS.Phi1_rand(:,1)*180/pi,'.')
%     title('Phi values when random noise is activated')
%     xlabel('Distance [km]')
%     ylabel('Friction angle [^\circ]')
end

% Depletion
if MELT_s==1
    Crust_thickness = zeros(1,steps); 
else
    nc = 1;
end
Dpl0 = zeros(nc,nnod); 
% Melt depletion (which % of rock volume has been melted)
Dpl = Dpl_init_new(Dpl0,GCOORD,ELEM2NODE,base_lithos,y_min1,Phases,nel);
Dpl0 = Dpl;

% Load rheologic variation function
if size(RHEOL.Ndis,2) > 1
    rheol_var_handle = str2func(rheol_var_f);
    RHEOL.var = rheol_var_handle(Dpl,GCOORD,ELEM2NODE,Phases);
end

% Declare surface process function
if surf_proc_s
    surf_proc = str2func(surf_proc_func);
end

%==========================================================================
% CALCULATE INITIAL DATA
%==========================================================================

if load_T
    % Loads the initial temperature field from Tini_dir file
    Tini_handle = str2func(Tini_load);
    Temp = Tini_handle(Tini_dir,GCOORD,temp_bc);
    
%     % Smothing temperatures for 5 timesteps
%     [Bct_ind, Bct_val] = set_bcs_temp(GCOORD, Corner_id, Cornin_id, Point_id, temp_bc, temp_bc_depth);
%     nip = 6;
%     for i=1:5
%         Temp = thermal2d(ELEM2NODE, GCOORD, Phases, K, Rho, Cp, Hp, Hs, Temp, Bct_ind, Bct_val, dt, nip, reorder);
%     end
else
    % Calculates the initial temperature field by solving the thermal
    % relaxation of the model
    [Bct_ind, Bct_val] = set_bcs_temp_ini(...
        GCOORD, Corner_id, Cornin_id, Point_id, temp_bc_ini,temp_bc_depth_ini, ...
        ini_deformation,sigma_tx,sigma_tz);
    
    Temp = temp_bc_ini*ones(size(GCOORD,2),1);
    
    % Thermal solver
    nip =6;
    for i=1:5
        Temp = thermal2d(ELEM2NODE, GCOORD, Phases, K, Rho, Cp, Hp, Hs, Temp, Bct_ind, Bct_val, 100*ma, nip, reorder,Ce);
    end
end

% Temperature boundary conditions
[Bct_ind, Bct_val] = set_bcs_temp(GCOORD, Corner_id, Cornin_id, Point_id, temp_bc, temp_bc_depth);

switch ini_deformation
    case 3
        amp_t = max_amp_t*exp(-((GCOORD(2,:) - depth_t_seed).^2)/sigma_tz^2);
        Temp = Temp + amp_t.*exp(-(GCOORD(1,:)-dist_wst).^2./(sigma_tx^2));
        Temp(Temp>temp_bc) = temp_bc;
end

if wb == 1
    wait_bar = waitbar(0,'Initializing model...'); % Initiates waitbar
    set(wait_bar,'Position',waitbar_pos);
    drawnow
    iter_wb = 0;
end
time0 = clock;
etime = 0;
remesh = 0;
istep = 1;
ntime = dt;

    case 'y'
        load(loadsave_file)
        switch top_surface
            case 'fix'
            case 'fs'
                switch tstep_type
                    case 'cnst'
                    case 'courant'
                        dt = C*min(Dx_e)/max(Vel);
                end
        end
        
        % DIRECTORIES
        addpath(directory);
        addpath(genpath(mutils_path));
        addpath('Input')
        
        if wb == 1
            wait_bar = waitbar(0,'Initializing model...'); % Initializes waitbar
            set(wait_bar,'Position',waitbar_pos);
            drawnow
            iter_wb = 0;
        end
        remesh_wb = 0;
        time0 = clock;
        istep = istep+1;
        ntime = ntime+dt;
end

while ntime<=time_int
    disp(istep)
    t_it = tic;
    track_remesh = [track_remesh remesh];


     
%==========================================================================
% REMESHING
%==========================================================================

% Switch for the different methods to deal with interface intersections and
% too thin layers
inter_t = tic;
switch intersect_s
    case 'lineintersect'
        [GEOMETRY(1,Geo_id==3), GEOMETRY(2,Geo_id==3), GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), remesh, layer_corr] = lineintersect (GEOMETRY(1,Geo_id==3), GEOMETRY(2,Geo_id==3), GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), remesh, shift);
        [GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), GEOMETRY(1,Geo_id==9), GEOMETRY(2,Geo_id==9), remesh, layer_corr] = lineintersect (GEOMETRY(1,Geo_id==6), GEOMETRY(2,Geo_id==6), GEOMETRY(1,Geo_id==9), GEOMETRY(2,Geo_id==9), remesh, shift);
        Intersect_ID = zeros(1,size(GEOMETRY,2))==1;
    case 'dis_layers'
        [GEOMETRY,Geo_id,Sgap,Intersect_ID,remesh] = ...
            dis_layers(GEOMETRY,Geo_id,Intersect_ID,shift,remesh);
end
toc(inter_t)
    
    if(remesh)
        disp('Remeshing..')
        
        % REMESH
        [remesh,GCOORD,ELEM2NODE,Phases,GEOMETRY,Geo_id,Corner_id,Cornin_id, ...
            Point_id,cont_points,Elsizes,nip,x_min,x_max,ext_rate,ext_erate, ...
            bc_v,temp_bc,temp_bc_depth,mode,prec, ...
            Temp,F_xx,F_xy,F_yx,F_yy,TAU_xx_old,TAU_xy_old, ...
            TAU_yy_old,I2,E2all,Mu_all,ndof,nnod,nel,layer_corr,Bc_ind,Bc_val ...
            Bc_ind_fs,Bc_val_fs,Bct_ind,Bct_val,Geo_mark,Intersect_ID,Sgap, ...
            RHEOL.var,SS,Dpl,PRESS_CONT] = ...
    remesh_all3l_dpl_rand_melt(remesh,GCOORD,ELEM2NODE,GEOMETRY,Phases,Geo_id, ...
    Corner_id,Cornin_id,cont_points,Elsizes,nip,x_min,x_max,Ylim,ext_rate, ...
    ext_erate,bc_v,temp_bc,temp_bc_depth,mode,prec, ...
    shift,Temp,F_xx,F_xy,F_yx,F_yy, ...
    TAU_xx_old,TAU_xy_old, TAU_yy_old, plot_s,Intersect_ID,Sgap, ...
    intersect_s,triangle_path,meshname,RHEOL.var,E2all,Mu_all,SS,Ts0, ...
    dTs_dP,dTs_dF,Dpl,PRESS_CONT);
    
        % REMESH ISOCHRONS
        if surf_proc_s
            [ISOCHRONS,Basement] = remesh_isoc(GCOORD,Point_id,ELEM2NODE, ...
                ISOCHRONS,Basement,tp_isoc);
            % Set for recalculation of the TRIS matrix in the next tracking
            % of the isolines
            Tris_isoc = 0;
        end
        
        % REMESH LAB
        TRACKP = resample_line(TRACKP,res_tp,'spline');
    end

    % Damage weak seed
    if ini_deformation==5 && istep*dt<WS.time
        I2 = damage_seed(I2,WS,GCOORD,ELEM2NODE,nip);
    end
    
    % UPDATE VELOCITIES
    [Vel,Pressure,PRES_IP,TAU_xx,TAU_yy,TAU_xy,TAU_xx_old,TAU_yy_old,TAU_xy_old,STRAIN_xx,STRAIN_yy, ...
        STRAIN_xy,E2all,Mu_all,Mu_dis_all,Mu_dif_all,Mu_b_all,Dx_e,F_xx,F_xy,F_yx,F_yy,I2,GIP_x_all,GIP_y_all, ...
        THETA_all,W_xy,RHO,nw_it] = mechanical2d_m(ELEM2NODE,Phases,GCOORD,Temp,E2all, ...
        Mu_all,RHEOL,Phi,Cohesion,R,Grain,Burger,Shearm,Rho,G,Bc_ind,Bc_val,...
        nip,reorder,ext_erate,top_surface,Corner_id,Point_id,dt,alpha,beta, ...
        Bc_ind_fs,Bc_val_fs,SS,F_xx,F_xy,F_yx,F_yy,I2,THETA_all,TAU_xx_old, ...
        TAU_yy_old,TAU_xy_old,elasticity_s,Ce,Dpl,Dplf,nw_it, ...
        sea_level,rho_w,plasticity_t);
    
    % Calculate contiuous pressure from dynamic pressure
    % Keep pressure from at iteration to be used in melt_production
    if(istep ==1)
        PRESS_CONT_old= el2nod_pressure(GCOORD,ELEM2NODE, nel,Pressure);
        PRESS_CONT_old = PRESS_CONT_old';
    else
        PRESS_CONT_old = PRESS_CONT;
    end
    PRESS_CONT = el2nod_pressure(GCOORD,ELEM2NODE, nel,Pressure);
    PRESS_CONT = PRESS_CONT';
    
    % SHEAR HEATING
    Hs = shear_heat(TAU_xx,TAU_yy,TAU_xy,TAU_xx_old,TAU_yy_old, ...
        TAU_xy_old,STRAIN_xx,STRAIN_yy,STRAIN_xy,Phases,Shearm,dt);
    Hs =  sh_s*Hs;

    % TEMPERATURE SOLVER / INCLUDES MELT ITERATIONS / SERPENTINIZATION
    Temp = thermal2d_m(ELEM2NODE, GCOORD, Phases, K, Rho, Cp, Hp, Hs, Temp, Bct_ind, Bct_val, dt, nip, reorder,Ce,Dplf,Dpl);
    
    % KEEP OLD COORDINATES
    GCOORD_old = GCOORD;
    
    %INTEGRATE MELT PRODUCTIVITY
  
    % RESHAPE VELOCITIES
    DISPL       = reshape(Vel,[ndof,nnod]);
        
    % MOVE TRACKED POINTS
    if tp_choice
        TRACKP = track_points(GCOORD,ELEM2NODE,Point_id,TRACKP,DISPL,dt);
    end
    if surf_proc_s
        if tp_isoc
            % Track isochrons
            [ISOCHRONS(1:2,:),Tris_isoc] = track_points_new(GCOORD, ...
                ELEM2NODE,Point_id,ISOCHRONS(1:2,:),DISPL,dt,Tris_isoc);
            Basement = ISOCHRONS(1:2,ISOCHRONS(3,:)==0);
        else
            % Track basement
            Basement = track_points(GCOORD,ELEM2NODE,Point_id,Basement ...
                ,DISPL,dt);
    
        end
    end
    if ini_deformation==5
        WS.coord = (track_points(GCOORD,ELEM2NODE,Point_id,WS.coord', ...
            DISPL,dt))';
    end
    
    if tp_melt && MELT_s
        TRACKP_melt = track_points_melt_test(GCOORD,ELEM2NODE,TRACKP_melt,DISPL,dt);
    end
       
    %UPDATE OF COORDINATES
    GCOORD      = GCOORD + DISPL*dt;
    
    a_end        = max(GCOORD(2,Layer6_id)) - min(GCOORD(2,Layer6_id));
    gr_rate      = log(a_end/a_ori)/dt;
        
    %MAKE STRAIGHT EDGES
    GCOORD(:,ELEM2NODE([6 4 5],:)) = 0.5*(GCOORD(:,ELEM2NODE([1 2 3],:)) + GCOORD(:,ELEM2NODE([2 3 1],:)));
    GCOORD(:,ELEM2NODE(7,:))       = 1/3*(GCOORD(:,ELEM2NODE(1,:))+GCOORD(:,ELEM2NODE(2,:))+GCOORD(:,ELEM2NODE(3,:)));
    
    %======================================================================    
    %SURFACE PROCESSES
    %======================================================================
    if surf_proc_s
        % Find topography
        [Topography,Topo2nodes] = find_topo(GCOORD,ELEM2NODE,Point_id);
        % Apply surface processes
        [New_topo,SP] = surf_proc(Topography,GCOORD,SP,dt,ma);
        % Update isochrons
        if floor(istep/iso_sav)==(istep/iso_sav)
            ISOCHRONS = [ISOCHRONS [New_topo; ...
                istep*ones(1,size(Topography,2)); New_topo(2,:)]];
            % Update TRIS matrix for the isochrons by adding the indexes
            % for the new isochron
            [~,Ti] = track_points_new(GCOORD, ...
                ELEM2NODE,Point_id,New_topo,DISPL,dt,0);
            Tris_isoc = [Tris_isoc Ti];
        end
        % Update the topography and interpolate variables of reshaped 
        % elements by surface processes
        [GCOORD,Temp,F_xx,F_xy,F_yx,F_yy,I2,TAU_xx_old,TAU_xy_old, ...
            TAU_yy_old,Mu_all,E2all,remesh] = update_topo_values ...
            (GCOORD,ELEM2NODE,New_topo,Topo2nodes,Temp,temp_surf,F_xx, ...
            F_xy,F_yx,F_yy,I2,RHEOL,TAU_xx_old,TAU_xy_old,TAU_yy_old,Mu_all, ...
            E2all,R,Phases,ext_rate,remesh);
        % If isochrons are not tracked (tp_isoc = 0) it is not possible to
        % erode the basement with the plot_basement function. Therefore, 
        % erosion needs to be applied now
        if ~tp_isoc
            Basement = [Basement(1,:); ...
                min([Basement(2,:); Topography(2,:)])];
        end
    end

    %UPDATE BOUNDARY CONDITIONS
    [Bc_ind, Bc_val, Point_id, Bc_ind_fs, Bc_val_fs, ext_erate] = ...
        set_bcs_flow3l(GCOORD, Corner_id, Cornin_id, Point_id, ext_erate, ext_rate, bc_v);
    [Bct_ind, Bct_val] = set_bcs_temp(GCOORD, Corner_id, Cornin_id, Point_id, temp_bc, temp_bc_depth);
    
    
    %======================================================================
    % MELTING
    %======================================================================
    if MELT_s
        %[Dpl,dF,Temp,dF_up,dF_diffusive,dP_melting] = melt_prod(Dpl,GCOORD,GCOORD_old,z2p,Ts0,dTs_dP,dTs_dF,QL,Temp,nnod,istep,Point_id,Corner_id);
        [Dpl,dF,Temp,dF_up,dF_diffusive,dP_melting] = melt_prod_new_press_cont(Dpl,GCOORD,GCOORD_old,z2p,Ts0,dTs_dP,dTs_dF,QL,Temp,nnod,istep,Point_id,Corner_id,Rho,Phases,G,PRESS_CONT,PRESS_CONT_old);
        
        %Update viscosity values according to depletion
        if size(RHEOL.Ndis,2) > 1
            rheol_var_handle = str2func(rheol_var_f);
            RHEOL.var = rheol_var_handle(Dpl,GCOORD,ELEM2NODE,Phases);
        end
        
        
        % Calculate area of melting every time step
        indkk =find(dF > 0);
        if(indkk ~= 0)
            switch melt_interpolation
                case 'area_nod'
                    %-->Calculating node's area
                    ELEM2NODE_tri = trimesh_p2_to_p1(ELEM2NODE);
                    area_el   = calc_area_el(GCOORD,ELEM2NODE_tri); % It uses only vertex
                    TMP       = repmat( (1/3)*area_el(:) ,1,3)';
                    area_nod  = accumarray(ELEM2NODE_tri(:), TMP(:));
                    nod16 = 1:(size(GCOORD,2)-nel);
                    %             dF16 = dF(nod16)';
                    %             dF_interp = dF16;
                    dF_interp = dF(nod16)';
                    area_melt = sum(area_nod .* dF_interp );
                case 'reg_grid'
                    %-->Into a regular grid
                    dF_interp = griddata(GCOORD(1,:),GCOORD(2,:),dF,X,Y,'linear');
                    boolean = isnan(dF_interp);
                    dF_interp(boolean) =0 ;
                    % Area melt and thickness of crust at each time step
                    area_el = grdstep^2;
                    area_nod = area_el;
                    area_melt = sum(sum(area_nod.*dF_interp,1),2); %in m^2
            end
            % Calculate crustal thickness (assuming all melt of this time step is extracted at the ridge)
            dz_crust = area_melt/(ext_rate*dt);
        else
            dF_interp = 0;
            area_melt = 0;
            dz_crust = 0;
        end
        % UPWELLING MELTING AND HEAT RELEASE
        Dserp = 0;
        [Crust_thickness,x_ign_body,y_ign_body,in_ign_body,TRACKP_melt,tp_melt,Temp] = emplacement_dike_sill_newmesh...
            (TRACKP_melt,Temp,istep,dz_crust,GCOORD,area_melt,ext_rate,dt,Point_id,ELEM2NODE,Phases,E2all,Geo_id,K,Cp,...
            km,dF,dF_interp,T_melt,Rho_melt,igneous_body,heat_release,Crust_thickness,Dserp);
    end
    %----------------------------------------------------------------------
    
    %CHECK MESH INTEGRETY
    [qn,amin,amax] = checkmesh(GCOORD,ELEM2NODE);
    if(qn<0.2 || amin<7 || amax>170)
        remesh = 1;
    end
    
    %UPDATE GEOMETRY MARKERS
    GEOMETRY = GCOORD(:,Geo_mark);
    
    etime = etime  + dt;
    tint = toc(t_it);
    
    %======================================================================
    % SAVING THE COORDINATES OF THE MESH, THE TEMPERATURE, THE VELOCITY, 
    % TRACERS, SOME VARIABLES AND TIME SPENDING IN THE PROCESSING
    %======================================================================
    wb1 = wb;
    clear wb
    time = clock - time0;
    save_step = 1:floor(steps/n_saves):steps;
    switch save_choice
        case 'cont'
            s_name = [[directory,'/',name],num2str(istep)];
            save(s_name)
        case 'dis'
            if istep == save_step(istep==save_step) % Improve TODO
                s_name = [[directory,'/',name],num2str(istep)];
                save(s_name)
            else
                switch sav_every_step
                    case 'overwrite'
                        save([directory,'/',name])
                    case 'partial'
                        save([directory,'/',name,'p',num2str(istep)], ...
                            sav_var_part{:})
                end
            end
    end
    wb = wb1;
    
    %======================================================================
    % POSTPROCESSING
    %======================================================================
    fprintf(1, 'POSTPROCESSING:     '); tic
    
    switch plot_s
        case 'y'
            
            clf
            drawnow
            figure(1)
            plot_eri
            hold on
            plot_isoc
            axis([-100 100 -40 5])
            drawnow
            hold off
            
    end
    %SWITCH FOR THE TIME STEP CRITERIA
    switch top_surface
        case 'fix'
        case 'fs'
            switch tstep_type
                case 'cnst'
                case 'courant'
                    dt = C*min(Dx_e)/max(Vel);
            end
    end
    
    istep = istep+1;
    ntime = ntime+dt;

    fprintf(1, [num2str(toc,'%8.6f'),'\n']);
    fprintf(1, ['\n']);
    
    % WAIT BAR AND ELAPSED TIME
    if wb == 1
        [iter_wb] = call_waitbar(iter_wb,ma,time0,ntime,time_int,dt,wait_bar);
    end
    
    % BREAK UP CHECK
    [BREAKUP,time_int] = break_up(BREAKUP,GCOORD,Point_id,ntime,time_int);
    
    ttotal = ttotal + tint;
    
end

if wb == 1
    waitbar(1,wait_bar,'COMPLETED!')
end