function [Ts,iTs,Vol0,Dpl0,X0,nc,Ts0,dTs_dP,dTs_dF,QL,aX,bX,dzmax,ad_K_km,Vol_ex,Dbulk,p2z,z2p,ad_K_GPa ] = parameters_melt(Rho)
%UNTITLED Summary of this function goes here
%  
% PETROLOGICAL CONSTANTS FOR MELTING (I am doing everything for one single component)
% Some constants are not used but are kept for later implementations.
        %nc =1; % number of petrological components in mantle
        %[PETRO] = mantle_composition_marta(nc,Rho);
        
        % Ts0    :: solidus temperature of rock at surface pressure
        % dTs_dP :: change in solidus temperature with increasing pressure
        % dTs_dF :: change in solidus temperature with increasing depletion
        % --> Ts = Ts0 + dTs_dP*P + dTs_dF*F
        
        % Solidus function pool (see JPM 2000)
        Ts(1,:) = [1081  132*1e-9  350]; % (2) fertile peridotite (use Dpl0 to make refractory PD!!) THIS IS HARZBURGITE IN JOERG'S PHD
        iTs  = 1;  % pick solidus function(s) from pool (==1 here)
        Vol0 = 1;  % define volume fraction of each component (MUST SUM UP TO 1)
        Dpl0 = 0;  % define initial depletion of each component
        X0   = 200;% define initial water content for each component
        
       % Rho    = Rho.cnst;
        nc     = length(iTs); % number of melting components
        Ts0    = Ts(iTs,1)';  % Extract definition of...
        dTs_dP = Ts(iTs,2)';  % ...solidus function(s)...
        dTs_dF = Ts(iTs,3)';  % ...from the above pool.
        
        %==========================================================================
        % MORE MELTING RELATED PARAMETERS
        %==========================================================================
        % Definition of latent heat QL(enthalpy of fusion)
        % empty ([]) --> QL = (1/3) * T
        % a number   --> latent heat kJ kg^-1; e.g. QL = 400
        % PETRO.QL     = 400;
        % This is going to be T*Increment S/Cp = 550 C % Phipps Morgan,
        % G-cubed, 2001
        QL     = 550; %[degrees Celsius]
        
        
        % Maximum upwelling (decompression) interval; code starts to iterate if
        % decompression is larger in a single time step; use values less than 1 km
        dzmax  = 500; % [m]; 0.5 is a good value
        
        % Define adiabatic temperature increase with depth (K/km)
        % (set to zero to use potential temperatures)
        ad_K_km = 0; %0.3;
        
        % Volume fraction below which a component will be removed (i.e. treated as
        % exhausted). Good value: 0.001
        Vol_ex = 0.001;
        
        % Bulk partition coefficient for water between solid and melt
        Dbulk  = 0.01;
        
        % Coefficients for parameterization of wet melting (Katz et al. 2003)
        % dTs(X) = aX * X^bX, with dTs being the decrease in solidus temperature
        % due to the presence of water content X
        aX     = -43;
        bX     = 0.75;
        
        p2z      = 1/(Rho(2)*9.81); % conversion pressure (Pa) --> depth (m)
        z2p      = (Rho(2)*9.81); % conversion depth (m) --> pressure (Pa)
        ad_K_GPa = ad_K_km * p2z;
        

end

