function [F_xx_new, F_xy_new, F_yx_new, F_yy_new,GIP_xF,GIP_yF, I2, ...
    TAU_xx_new, TAU_xy_new, TAU_yy_new] = remesh_F_TAU ...
    (GCOORD, ELEM2NODE,GCO, E2N, F_xx, F_xy, F_yx, F_yy, nnodel_r, ...
    TAU_xx, TAU_xy, TAU_yy, nip, nel)
% remesh_F

% Brings back F to the nodes
nel_old = size(E2N,2);

EL2N      = zeros(nel_old,nnodel_r);

[IP_X, IP_w]    = ip_triangle(nip);
[   Nbig]    = shp_triangle(IP_X, nnodel_r);

GIP_xF = zeros(nel,nip);
GIP_yF = zeros(nel,nip);

F_xx_n = zeros(nnodel_r,nel_old);
F_xy_n = zeros(nnodel_r,nel_old);
F_yx_n = zeros(nnodel_r,nel_old);
F_yy_n = zeros(nnodel_r,nel_old);

for i=1:nel_old
    is         = (i-1)*nnodel_r+1; ie = (i-1)*nnodel_r+nnodel_r;
    GCO_N(:,is:ie) = GCO(:,E2N([1:nnodel_r],i));
    EL2N(i,:) = is:ie;
    Dummy      = Nbig'\F_xx(i,:)';
    F_xx_n(:,i)= Dummy(1:nnodel_r)';
    Dummy      = Nbig'\F_xy(i,:)';
    F_xy_n(:,i)= Dummy(1:nnodel_r)';
    Dummy      = Nbig'\F_yx(i,:)';
    F_yx_n(:,i)= Dummy(1:nnodel_r)';
    Dummy      = Nbig'\F_yy(i,:)';
    F_yy_n(:,i)= Dummy(1:nnodel_r)';
    Dummy      = Nbig'\TAU_xx(i,:)';
    TAU_xx_n(:,i) = Dummy(1:nnodel_r)';
    Dummy      = Nbig'\TAU_xy(i,:)';
    TAU_xy_n(:,i) = Dummy(1:nnodel_r)';
    Dummy      = Nbig'\TAU_yy(i,:)';
    TAU_yy_n(:,i) = Dummy(1:nnodel_r)';
    
end

% Uncomment the following to plot the F_xx at the nodes
% scatter(GCO(1,E2N(1:nnodel_r,:)),GCO(2,E2N(1:nnodel_r,:)),5,F_xx_n(:))

% Average the values at the nodes???

% Find new ips

[   N, dNdu]    = shp_deriv_triangle(IP_X, size(E2N,1));

ECOORD_x = reshape(GCOORD(1,ELEM2NODE), size(ELEM2NODE,1), nel);
ECOORD_y = reshape(GCOORD(2,ELEM2NODE), size(ELEM2NODE,1), nel);

for ip=1:nip
    
    Ni      =        N{ip};

    GIP_x   = Ni'*ECOORD_x;
    GIP_y   = Ni'*ECOORD_y;
    
    GIP_xF(:,ip)   = GIP_x;
    GIP_yF(:,ip)   = GIP_y;

end

%size_gip = size(GIP_xF);
Tris_F = tsearch2(GCO,uint32(E2N(1:3,:)),[GIP_xF(:)';GIP_yF(:)']);

Tris_F = reshape(Tris_F,size(GIP_xF));
Ind = find(Tris_F==0);

%check of all elements were found, and if not it solves the problem finding
% the closest element
if(~isempty(Ind))
    for i=1:length(Ind)
        [val, Tris_F(Ind(i))] = min(sqrt((GCO(1,E2N(7,:)) - GIP_xF(Ind(i))).^2 + (GCO(2,E2N(7,:)) - GIP_yF(Ind(i))).^2));
    end
end

if(any(isnan(Tris_F)))
    error('remeshing failed in move_contours');
end

% For plotting the new mesh with the new integration points uncomment the
% next lines
%
% figure(265)
% trimesh(ELEM2NODE(1:3,:)',GCOORD(1,:),GCOORD(2,:))
% hold on
% plot(GIP_x_all(:),GIP_y_all(:),'o')

% Calculates the local coordinates of the new ip

xp = GIP_xF(:)'; % New ip
yp = GIP_yF(:)'; % New ip

x = reshape(GCO(1,E2N(1:3,Tris_F)),3,size(xp,2)); % Reshape old coord
y = reshape(GCO(2,E2N(1:3,Tris_F)),3,size(yp,2)); % Reshape old coord

xi = -(-x(1,:).*yp+x(1,:).*y(3,:)-x(3,:).*y(1,:)+xp.*y(1,:)+x(3,:) ...
    .*yp-xp.*y(3,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:) ...
    +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local x cood for ip
yi = (x(1,:).*y(2,:)-x(1,:).*yp-x(2,:).*y(1,:)+x(2,:).*yp+xp ...
    .*y(1,:)-xp.*y(2,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:)...
    +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local y coord for ip

% Load shape functions

[NN] = shp_triangle([xi' yi'], nip);

% Calculate the value of F for the new ips

F_xx_new = sum(NN.*F_xx_n(1:nnodel_r,Tris_F));
F_xx_new = reshape(F_xx_new,size(Tris_F,1),nip);
F_xy_new = sum(NN.*F_xy_n(1:nnodel_r,Tris_F));
F_xy_new = reshape(F_xy_new,size(Tris_F,1),nip);
F_yx_new = sum(NN.*F_yx_n(1:nnodel_r,Tris_F));
F_yx_new = reshape(F_yx_new,size(Tris_F,1),nip);
F_yy_new = sum(NN.*F_yy_n(1:nnodel_r,Tris_F));
F_yy_new = reshape(F_yy_new,size(Tris_F,1),nip);

% Calculate the new I2
E_xx = (1/2)*(F_xx_new.^2 + F_yx_new.^2 - 1);
E_xy = (1/2)*(F_xx_new.*F_xy_new + F_yx_new.*F_yy_new - 0);
E_yy = (1/2)*(F_xy_new.^2 + F_yy_new.^2 - 1);

I2 = sqrt((1/2)*(E_xx.^2 + E_yy.^2) + E_xy.^2);

% Calculate the value of TAU for the new ips
TAU_xx_new = sum(NN.*TAU_xx_n(1:nnodel_r,Tris_F));
TAU_xx_new = reshape(TAU_xx_new,size(Tris_F,1),nip);
TAU_xy_new = sum(NN.*TAU_xy_n(1:nnodel_r,Tris_F));
TAU_xy_new = reshape(TAU_xy_new,size(Tris_F,1),nip);
TAU_yy_new = sum(NN.*TAU_yy_n(1:nnodel_r,Tris_F));
TAU_yy_new = reshape(TAU_yy_new,size(Tris_F,1),nip);

% Uncomment the following to plot F new at the new ip
%
% figure(332)
% subplot(221)
% scatter(GIP_xF(1:10:end),GIP_yF(1:10:end),5,F_xx_new(1:10:end))
% subplot(222)
% scatter(GIP_xF(1:10:end),GIP_yF(1:10:end),5,F_xy_new(1:10:end))
% subplot(223)
% scatter(GIP_xF(1:10:end),GIP_yF(1:10:end),5,F_yx_new(1:10:end))
% subplot(224)
% scatter(GIP_xF(1:10:end),GIP_yF(1:10:end),5,F_yy_new(1:10:end))

% Uncomment the folloing to plot F old at the old nodes
%
% figure(333)
% subplot(221),patch('faces',EL2N(:,1:3),'vertices',GCO_N'/1000,'facevertexcdata', ...
%     F_xx_n(:),'FaceColor','flat')
% shading interp
% axis tight
% colorbar
% subplot(222),patch('faces',EL2N(:,1:3),'vertices',GCO_N'/1000,'facevertexcdata', ...
%     F_xy_n(:),'FaceColor','flat')
% shading interp
% axis tight
% colorbar
% subplot(223),patch('faces',EL2N(:,1:3),'vertices',GCO_N'/1000,'facevertexcdata', ...
%     F_yx_n(:),'FaceColor','flat')
% shading interp
% axis tight
% colorbar
% subplot(224),patch('faces',EL2N(:,1:3),'vertices',GCO_N'/1000,'facevertexcdata', ...
%     F_yy_n(:),'FaceColor','flat')
% shading interp
% axis tight
% colorbar