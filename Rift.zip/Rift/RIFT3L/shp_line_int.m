function  [N] = shp_line_int(ipx, nnodel)

nip  = size(ipx,2);
N    = cell(nip,1);

for i=1:nip
    eta  = ipx(1,i);

    switch nnodel;
        case 2
            SHP   = [0.5*(1 - eta);
                   0.5*(1 + eta)];

        case 3
%             SHP = [eta*(eta-1)/2;
%                  (1-eta)*(1+eta);
%                  eta*(eta+1)/2];
            SHP = [eta*(eta-1)/2;
                 1-eta^2;
                 eta*(eta+1)/2];
         
    end
    
    N{i} = SHP;
end