function [F,load_el] = distr_load_hydrost(Topography,Topo2nodes, ...
    Topo_load,rho_l,GCOORD,ELEM2NODE,Point_id,Corner_id,max_level,G)
% [F,LOAD_EL] = DISTR_LOAD_HYDROST(TOPOGRAPHY,TOPO2NODES,TOPO_LOAD,RHO_L,
% GCOORD,ELEM2NODE,POINT_ID,CORNER_ID,MAX_LEVEL,G) calculates the load
% integrated over the surface due to a distributed load of a layer of
% constant viscosity RHO_L and topography TOPO_LOAD, over the topography of
% the model defined by TOPOGRAPHY and indexes TOPO2NODE. GCOORD,ELEM2NODE,
% POINT_ID and CORNER_ID define the mesh of the model. G is the gravity
% vector. Set MAX_LEVEL a value in case the load upper limit should be held
% at a constant heigth (i.e. sea level); this avoids little overloads in 
% elements partially covered by the load where the interpolation would be
% incorrect if the top part of the load is ment to be held at a constant
% height. Otherwise, set MAX_LEVEL empty [].

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, Postdoc at University of
% Bremen, 07-03-2016. Email: andresma@uni-bremen.de
%--------------------------------------------------------------------------

%==========================================================================
% SETUP
%==========================================================================
% Change the id of the superior corners of the model from -1 to the id of 
% the top surface
Point_id(Corner_id(3:4)) = max(Point_id)-1;
% Number of superficial nodes in the element
nnod_el_s = 3;
% Indexes of the top nodes
Top_nodes = find(Point_id==max(Point_id)-1);
% Top element indexes with 3 nodes on the surface
Top_elem3 = find(sum(ismember(ELEM2NODE,Top_nodes),1)==...
    nnod_el_s);

% Vector of the load forces (size: number of nodes x degrees of freedom)
F = zeros(size(GCOORD,2)*2, 1);

% % Plot load (uncomment)
% plot(Topo_load(1,:),Topo_load(2,:)+Topography(2,:))
% hold on
% axis equal
% axis([10000 30000 -10000 5000])
% plot(Topography(1,:),Topography(2,:),'k')
% trimesh(ELEM2NODE(1:3,Top_elem3)',GCOORD(1,:),GCOORD(2,:),'Color',[0,0,0])

%==========================================================================
% INTEGRATION POINTS, WEIGHTS AND SHAPE FUNCTIONS
%==========================================================================
% Number of integration points
nip = 3;
% Integration points local coordinates
Ip = [-sqrt(3/5), 0, sqrt(3/5)];
% Integration weights
Ipw = [5/9; 8/9; 5/9];
% Shape functions for surface integration
N = shp_line_int(Ip,nnod_el_s);

%==========================================================================
% LOOP THROUGH THE SURFACE ELEMENTS
%==========================================================================
for n = 1:size(Top_elem3,2)
    % Local indexes of the surface nodes
    Lo_nodes_s = Point_id(ELEM2NODE(1:6,Top_elem3(n)))==max(Point_id)-1;
    % Global indexes of the surface nodes
    Gl_nodes_s = ELEM2NODE(Lo_nodes_s,Top_elem3(n));
    
    % Order the surface elements in increasing value
    [Xorder,Xindex] = sort(GCOORD(1,Gl_nodes_s));
    % Reorder the global node indexes
    Gl_nodes_s = Gl_nodes_s(Xindex);
    % Calculate dx
    dx_e = (max(Xorder)-min(Xorder));
    
    % Indexes for the vector F
    Fx_index = 2*double(Gl_nodes_s)-1;
    Fy_index = 2*double(Gl_nodes_s);
    
    % Local topo
    Topo_local = Topography(2,ismember(Topo2nodes,Gl_nodes_s));
    % Find the ip coordinates
    X_ip = Ip*dx_e/2+Xorder(2);
    Y_ip = interp1(Xorder,Topo_local,X_ip,'linear');
    
    % Find the load height at the nodes
    Lnode_e = Topo_load(2,ismember(Topo2nodes,Gl_nodes_s));
    % Find the load height at the ips
    Lip_e = interp1(Xorder,Lnode_e,X_ip,'linear');
    % Correct wrong interpolations at the edges of the sea
    if ~isempty(max_level)
        Lip_e((Lip_e+Y_ip)>max_level) = max_level- ...
            Y_ip((Lip_e+Y_ip)>max_level);
        Lip_e(Lip_e<0) = 0;
    end
    
    % Calculate the increment in height
    dh_e = (Topo_local(3)-Topo_local(1));
    % Module of the slope vector
    slope_m = sqrt(dx_e^2 + dh_e^2);
    % Perpendicular-to-the-surface unitarian vector pointing downwards
    n = [dh_e,-dx_e]/slope_m;
    % Components of the ip load
    Lip_x = Lip_e'*n(1);
    Lip_y = Lip_e'*n(2);
    
%     % Plot nodes 'o', ips 'x' and load heigth over ips '^' (uncomment)
%     plot(Xorder,Topo_local,'o')
%     plot(X_ip,Y_ip,'x')
%     plot(X_ip,Y_ip+Lip_e,'^')
%     % Plot directed heigths over the ips
%     plot([X_ip; X_ip-Lip_x'],[Y_ip; Y_ip-Lip_y'],'r')
    
    % Initialize the vector F_s for each element.
    F_x =  zeros(nnod_el_s,1);
    F_y =  zeros(nnod_el_s,1);
    
    % Integration loop
    for ip_s = 1:nip
        % Point load (omitted dx_e term)
        F_x = F_x + ...
            N{ip_s}*Ip(ip_s).*Lip_x*rho_l*(-G(2))*dx_e/2;
        F_y = F_y + ...
            N{ip_s}*Ip(ip_s).*Lip_y*rho_l*(-G(2))*dx_e/2;
    end
    
    % Save forces
    F(Fx_index) = F(Fx_index) + F_x;
    F(Fy_index) = F(Fy_index) + F_y;
end

% % Plot directed integrated heights over the nodes (uncomment)
% pnodes = find(F(1:2:end-1)~=0 & F(2:2:end)~=0);
% Fh = F/(-G(2)*rho_l);
% plot([GCOORD(1,pnodes); GCOORD(1,pnodes)-Fh(pnodes*2-1)'], ...
%     [GCOORD(2,pnodes); GCOORD(2,pnodes)-Fh(pnodes*2)'],'b')

%==========================================================================
% FIND ELEMENTS IN CONTACT WITH THE LOAD
%==========================================================================
% Global load
Gl_load = zeros(1,size(GCOORD,2));
Gl_load(Topo2nodes) = Topo_load(2,:);
% Surface elements loaded
s_load_el = sum(Gl_load(ELEM2NODE(1:6,Top_elem3)),1)>0;
% Elements loaded
load_el = zeros(1,size(ELEM2NODE,2));
load_el(Top_elem3) = s_load_el;
load_el = load_el==1;

% % Plot loaded elements (uncomment)
% trimesh(ELEM2NODE(1:3,load_el)',GCOORD(1,:),GCOORD(2,:),'Color',[1,0,0])