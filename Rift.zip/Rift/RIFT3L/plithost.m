function PLITHOST = plithost(GCOORD,ELEM2NODE,Point_id,Phases,...
    rho,G)
% PLITHOS = PLITHOS(GCOORD,ELEM2NODE,POINT_ID,PHASES,RHO,G) calculates the
% lithostatic pressure at the integration points using the mesh defined by
% GCOORD, ELEM2NODE, POINT_ID, PHASES and the density RHO and gravity
% vector G.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 03-09-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%disp('CALCULATING LITHOSTATIC PRESSURES: ')

t = tic;

% Calculate GIPS
nip = 6;
GIP_x = zeros(size(ELEM2NODE(1:6,:)'));
GIP_y = zeros(size(ELEM2NODE(1:6,:)'));
[IP_X,~] = ip_triangle(6);
[N,~] = shp_deriv_triangle(IP_X,7);
for ip=1:nip
    Ni = N{ip};
    ECOORD_x = reshape(GCOORD(1,ELEM2NODE),7,size(ELEM2NODE,2));
    ECOORD_y = reshape(GCOORD(2,ELEM2NODE),7,size(ELEM2NODE,2));
    GIP_x(:,ip) = Ni'*ECOORD_x;
    GIP_y(:,ip) = Ni'*ECOORD_y;
end

% Vectorize GIPs
Gip_x = GIP_x(:);
Gip_y = GIP_y(:);

% Find interfaces id
Interf_id = 3:3:max(Point_id);
% Add corners
Corners = repmat([1 3:3:max(Point_id)],2,1);
Point_id(Point_id==-1) = Corners(:)';

% Initialize vertical distance to interface matrix
DIST2INT = zeros(length(Interf_id),size(Gip_x,1));

% Loop to calculate distances to interfaces
for n = 1:length(Interf_id)
    % Interface evaluated
    INTn = GCOORD(:,Point_id==Interf_id(n));
    % Sort interface
    [INTn(1,:),indx] = sort(INTn(1,:));
    INTn(2,:) = INTn(2,indx);
    % Y coordinate of the projection of the global coordinates into the
    % interfave evaluated
    INTy = interp1(INTn(1,:),INTn(2,:),Gip_x);
    % Calculate vertical distances
    DIST2INT(n,:) = INTy'-Gip_y';
end

% Remove negative distances (when points are above interfaces)
DIST2INT(DIST2INT<0) = 0;

% Build density matrix
RHO = rho(repmat(unique(Phases)',1,size(Gip_x,1)));
RHO(1:end-1,:) = -diff(RHO);

% Calculate lithostatic pressure for each node
PLITHOST = sum(DIST2INT.*RHO.*(-G(2)));
PLITHOST = reshape(PLITHOST,size(ELEM2NODE,2),nip);

%disp(toc(t))

% % Plot (uncomment)
% plp = sum(PLITHOST,2)/6;
% patch('faces',ELEM2NODE(1:3,:)','vertices',GCOORD'/1000,'facevertexcdata', ...
%     plp(:)/1e6,'FaceColor','flat')
% shading flat
% colorbar
% title('Pressures [MPa]')
% xlabel('Distance [Km]')
% ylabel('Depth [Km]')