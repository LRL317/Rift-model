function [TRACKP,Tris] = track_points(GCOORD,ELEM2NODE,Point_id,TRACKP, ...
    DISPL,dt,Tris)

% TRACK_POINTS(GCOORD,ELEM2NODE,TRACKP,DISPL,DT) Calculatates the new
% positions for the tracked points TRACKP after deformation of the current
% time step DT, using the velocities DISPL, defined in the nodes of a mesh
% GCOORD, ELEM2NODE.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 23-06-2013. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------
% MA 23-06-2014 Indexation of the outer track point problems solved
% MA 06-09-2015 Bug when tracking points where at x-coordinates equivalent
%     to the corners of the model solved
% MA 07-10-2015 Added the hability to input TRIS matrices when calculated
%     previous steps for fast solving
% MA 12-10-2015 Added matricial form of OUTSIDE POINTS
% MA 12-10-2015 Added Velocity interpolation as in the edge on the element 
%     when outside points

O.ooo = 0;
if Tris==0
    % When Tris is initiated but not previously calculated or deleted
    tic;
    % Finds the elements where the track points are located
    Tris = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),TRACKP);
else
    % When there is a initial guess for the Tris
    tic;
    % Finds the elements where the track points are located
    Tris(Tris~=0) = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)), ...
        TRACKP(:,Tris~=0),O,Tris(Tris~=0));
end
disp(['LOCALIZE TRACK POINTS: ',num2str(toc)])

% Finds points outside of the mesh
Ind = find(Tris==0);

%======================================================================
% OUTSIDE POINTS
%======================================================================
tic;
% Checks all points were found and if not correct the problem
if(~isempty(Ind))
    % Add corners to the surface
    Corners = find(Point_id==-1);
    Point_id(Corners(end-1:end)) = max(Point_id)-1;
    % Finds the surface indexes
    Surf_i = find(Point_id==max(Point_id)-1);
    % Finds the surface coordinates
    Surface = GCOORD(:,Surf_i);
    % Reorder variables in function of x
    [Surface_sort,Indx_surf] = sort(Surface(1,:));
    Surface_sort = [Surface_sort; Surface(2,Indx_surf)];
    Surf_i_sort = Surf_i(Indx_surf);
    
    % Interpolate y-coordinate for the outside tps
    COORD_surf = interp1(Surface_sort(1,:),Surface_sort(2,:),...
        TRACKP(1,Ind));
    % Save real y-coordinates of outside tp
    TRACKP_out_y = TRACKP(2,Ind);
    % Save interpolation as y-coordinates of tp for future use in
    % calculation of the velocities at the edges of the elements and not
    % outside
    TRACKP(2,Ind) = COORD_surf;
    
    % Create matrices to find surface points on the right and left of each
    % tp
    TPout_x = repmat(TRACKP(1,Ind)',1,length(Surface_sort(1,:)));
    SURFACE = repmat(Surface_sort(1,:),length(TRACKP(1,Ind)),1);
    
    % Indexes of surface points on the right and left
    LEFT = TPout_x>=SURFACE;
    RIGHT = TPout_x<SURFACE;
    
    % Indexes of the points that define the surface segment containing the
    % x-coordinates of the tps
    [Tpi,Left] = find(([LEFT(:,1:end-1) zeros(length(Ind),1)]==1 & ...
        [RIGHT(:,2:end) zeros(length(Ind),1)]==1) | ...
        ([zeros(length(Ind),length(Surface_sort(1,:))-1) ...
        ones(length(Ind),1)]==1 & repmat(sum(RIGHT,2)==0,1, ...
        length(Surface_sort(1,:)))));
    % Reorder indexes
    [~,Tpi_ind] = sort(Tpi);
    Left = Left(Tpi_ind);
    Right = Left+1;
    % Account for right corner exception
    Corner_right = Left==size(Surface_sort,2);
    Right(Corner_right) = Left(Corner_right)-1;
    
    % Elements of the surface
    Surface_el = find(sum(ismember(ELEM2NODE(1:6,:),Surf_i))>1);
    
    % Elements of the surface defined in Surface_el which correspond to the
    % tps
    ELout = zeros(size(Left));
    tic;
    for n = 1:length(Left) % TODO find the matricial solution for this loop
        ELout(n) = find(sum(ismember(ELEM2NODE(1:6,Surface_el), ...
            Surf_i_sort([Left(n) Right(n)])))==2);
    end
    disp(['LOCALIZE OUTER-MESH TRACK POINTS: ',num2str(toc)])
    % Redefine Tris for the out points using ELout
    Tris(Ind) = Surface_el(ELout);
end
%==========================================================================
% VELOCITIES AND DISPLACEMENTS
%==========================================================================
% Interpolate velocities at the trackpoints
Vx_tp = remesh_val(Tris,GCOORD,TRACKP,DISPL(1,:),ELEM2NODE);
Vy_tp = remesh_val(Tris,GCOORD,TRACKP,DISPL(2,:),ELEM2NODE);

if(~isempty(Ind))
    % Mark the points outside of the mesh
    Tris(Ind) = 0;
    % Change y-coordinates of the tps outside of the mesh from the surface
    % to their real location
    TRACKP(2,Ind) = TRACKP_out_y;
end

% Calculates displacements and updates the position of the track points
TRACKP = TRACKP + [Vx_tp; Vy_tp].*dt;