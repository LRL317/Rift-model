function RHO = density(Rho,Temp,Ce,GCOORD,ELEM2NODE,Phases,nip,rho_s)
% RHO = DENSITY(RHO,TEMP,GCOORD,ELEM2NODE,PHASES,NIP,RHO_S) calculates the
% densities

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 25-04-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

if rho_s
% #############################
% DENSITY TEMPERATURE DEPENDENT
% #############################

%==========================================================================
% CALCULATE INTEGRATION POINTS
%==========================================================================
% Local IPs
[IP_X,~] = ip_triangle(nip);
% Calculate shape functions
[N,~] = shp_deriv_triangle(IP_X,size(ELEM2NODE,1));

% Reoder the coordinates into element nodes
ECOORD_x = reshape(GCOORD(1,ELEM2NODE),size(ELEM2NODE,1),size(ELEM2NODE,2));
ECOORD_y = reshape(GCOORD(2,ELEM2NODE),size(ELEM2NODE,1),size(ELEM2NODE,2));

% Declare GIPs
IPx = zeros(size(ELEM2NODE,2),nip);
IPy = zeros(size(ELEM2NODE,2),nip);
% Calculate integration point coordinates (GIPs)
for ip=1:nip
    Ni = N{ip};
    GIP_x   = Ni'*ECOORD_x;
    GIP_y   = Ni'*ECOORD_y;
    IPx(:,ip)   = GIP_x;
    IPy(:,ip)   = GIP_y;
end

% Plot (uncomment)
% plot_mesh; hold on
% plot(IPx/1000,IPy/1000,'.')

%==========================================================================
% CALCULATE TEMPERATURES AT THE INTEGRATION POINTS
%==========================================================================
% Build the tris matrix that relates the integration points with their
% respective element
Tris = repmat((1:size(ELEM2NODE,2))',1,nip);
Tris = Tris(:)';

% Calculate temperatures at the integration points
Tip_ns = remesh_val(Tris,GCOORD,[IPx(:)'; IPy(:)'],Temp,ELEM2NODE);
% Reshape the temperature matrix to be in the same shape as the integration
% points
Tip = reshape(Tip_ns,size(ELEM2NODE,2),nip);

% Plot (uncomment)
% plot_gt = 0;
% plot_t
% hold on
% plot_mesh
% region = [-10 10 -50 0]*km;
% ipp = IPx >= region(1) & IPx <= region(2) & ...
%     IPy >= region(3) & IPy <= region(4);
% hold on
% plot(IPx(ipp)/km,IPy(ipp)/km,'ow','MarkerFaceColor','w','MarkerSize',5)
% scatter(IPx(ipp)/km,IPy(ipp)/km,25,Tip(ipp),'.')

%==========================================================================
% CALCULATE DENSITIES
%==========================================================================
% Create the matrixes for the density at O C and thermal expansivity
RHO_0 = repmat(Rho(Phases),1,nip);
CE = repmat(Ce(Phases),1,nip);

% Calculate the density
RHO = RHO_0.*(1-CE.*(Tip-0));
else

% ###############################    
% DENSITY TEMPERATURE INDEPENDENT
% ###############################
RHO = repmat(Rho(Phases),1,nip);
end













