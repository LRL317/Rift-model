function [F_xx_new, F_xy_new, F_yx_new, F_yy_new,GIP_X,GIP_Y, I2, ...
    TAU_xx_new, TAU_xy_new, TAU_yy_new, Mu_all_new, E2_all_new] = ...
    remesh_F_TAU_Mu_E2_linear ...
    (GCOORD, ELEM2NODE,GCO, E2N, F_xx, F_xy, F_yx, F_yy, nnodel_r, ...
    TAU_xx, TAU_xy, TAU_yy, Mu_all, E2_all, nip, nel)

% Switch for the interpolation scheme
interp_s = 'old_nodes2new_ips';

% Accumulate variables to remesh in a single matrix Vip
Vip = [F_xx F_xy F_yx F_yy TAU_xx TAU_xy TAU_yy Mu_all E2_all];

% Calculates values at nodes from the values at the integration points
Vn = ip2nodes(Vip,GCO,E2N,nip,nnodel_r);

% Calculates coordinates of the integration points for the new mesh
[GIP_X,GIP_Y] = ip_coord(GCOORD,ELEM2NODE,nel,nip);

switch interp_s
    case 'old_nodes2new_ips'
        % Old element indexes in which the new ips are contained
        Tris_F = tsearch2(GCO,uint32(E2N(1:3,:)),[GIP_X(:)';GIP_Y(:)']);
        
        Tris_F = reshape(Tris_F,size(GIP_X));
        Ind = find(Tris_F==0);
        
        % Check of all elements were found, and if not it solves the 
        % problem finding the closest element
        if(~isempty(Ind))
            for i=1:length(Ind)
                [val, Tris_F(Ind(i))] = min(sqrt( ...
                    (GCO(1,E2N(7,:)) - GIP_X(Ind(i))).^2 + ...
                    (GCO(2,E2N(7,:)) - GIP_Y(Ind(i))).^2));
            end
        end
        
        if(any(isnan(Tris_F)))
            error('remeshing failed in move_contours');
        end
        
        % Calculates the local coordinates of the new ip
        xp = GIP_X(:)'; % New ip
        yp = GIP_Y(:)'; % New ip
        
        x = reshape(GCO(1,E2N(1:3,Tris_F)),3,size(xp,2)); % Reshape old coord
        y = reshape(GCO(2,E2N(1:3,Tris_F)),3,size(yp,2)); % Reshape old coord
        
        xi = -(-x(1,:).*yp+x(1,:).*y(3,:)-x(3,:).*y(1,:)+xp.*y(1,:)+x(3,:) ...
            .*yp-xp.*y(3,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:) ...
            +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local x cood for ip
        yi = (x(1,:).*y(2,:)-x(1,:).*yp-x(2,:).*y(1,:)+x(2,:).*yp+xp ...
            .*y(1,:)-xp.*y(2,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:)...
            +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local y coord for ip
        
        % Load shape functions
        [NN] = shp_triangle([xi' yi'], nnodel_r);
        
        % Number of variables
        nvar = size(Vip,2)/nip;
        
        Vip_new = zeros(nel,nvar*nip);
        % Calculate the new ip values by linearly interpolating from the 
        % values in the nodes
        for j = 1:nvar
            Vin = sum(NN.*Vn((j-1)*nnodel_r+(1:nnodel_r),Tris_F));
            Vip_new(:,(j-1)*nip+(1:nip)) = reshape(Vin,size(Tris_F,1),nip);
        end
        
        % Get the variables from the new ip variable matrix
        F_xx_new =      Vip_new(:,(1-1)*nip+(1:nip));
        F_xy_new =      Vip_new(:,(2-1)*nip+(1:nip));
        F_yx_new =      Vip_new(:,(3-1)*nip+(1:nip));
        F_yy_new =      Vip_new(:,(4-1)*nip+(1:nip));
        TAU_xx_new =    Vip_new(:,(5-1)*nip+(1:nip));
        TAU_xy_new =    Vip_new(:,(6-1)*nip+(1:nip));
        TAU_yy_new =    Vip_new(:,(7-1)*nip+(1:nip));
        Mu_all_new =    Vip_new(:,(8-1)*nip+(1:nip));
        E2_all_new =    Vip_new(:,(9-1)*nip+(1:nip));
        
    case 'old_nodes2new_nodes2new_ips'
        % TODO In the future we might want to test another type of
        % remeshing in which we would move the variables to the old nodes,
        % then to the nodes of the new mesh (making the function
        % continuous) and then to the new integration points. Beaware this
        % could trigger smoothing of the variables in the rheologic
        % boundaries which might no be desirable.
        
%         % New node coordinates sorted with the element logic
%         ECOORD_X = reshape(GCOORD(1,ELEM2NODE), size(ELEM2NODE,1), nel);
%         ECOORD_Y = reshape(GCOORD(2,ELEM2NODE), size(ELEM2NODE,1), nel);
%         
%         % Old element indexes in which the new nodes are contained
%         Tris_F = tsearch2(GCO,uint32(E2N(1:3,:)), ...
%             [ECOORD_X(:)';ECOORD_Y(:)']);
%         
%         Tris_F = reshape(Tris_F,size(ECOORD_X));
%         Ind = find(Tris_F==0);
%         
%         % Check of all elements were found, and if not it solves the 
%         % problem finding the closest element
%         if(~isempty(Ind))
%             for i=1:length(Ind)
%                 [val, Tris_F(Ind(i))] = min(sqrt( ...
%                     (GCO(1,E2N(7,:)) - ECOORD_X(Ind(i))).^2 + ...
%                     (GCO(2,E2N(7,:)) - ECOORD_Y(Ind(i))).^2));
%             end
%         end
%         
%         if(any(isnan(Tris_F)))
%             error('remeshing failed in move_contours');
%         end
%         
%         % Calculates the local coordinates of the new nodes
%         xp = ECOORD_X(:)'; % New ip
%         yp = ECOORD_Y(:)'; % New ip
%         
%         x = reshape(GCO(1,E2N(1:3,Tris_F)),3,size(xp,2)); % Reshape old coord
%         y = reshape(GCO(2,E2N(1:3,Tris_F)),3,size(yp,2)); % Reshape old coord
%         
%         xi = -(-x(1,:).*yp+x(1,:).*y(3,:)-x(3,:).*y(1,:)+xp.*y(1,:)+x(3,:) ...
%             .*yp-xp.*y(3,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:) ...
%             +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local x cood for ip
%         yi = (x(1,:).*y(2,:)-x(1,:).*yp-x(2,:).*y(1,:)+x(2,:).*yp+xp ...
%             .*y(1,:)-xp.*y(2,:))./(-x(1,:).*y(3,:)+x(1,:).*y(2,:)-x(2,:).*y(1,:)...
%             +x(2,:).*y(3,:)+x(3,:).*y(1,:)-x(3,:).*y(2,:)); % Local y coord for ip
%         
%         % Load shape functions
%         [NN] = shp_triangle([xi' yi'], nnodel_r);
%         
%         % Number of variables
%         nvar = size(Vip,2)/nip;
%         
%         Vn_new = zeros(nel,nvar*nnodel_r);
end

% Calculate the new I2
E_xx = (1/2)*(F_xx_new.^2 + F_yx_new.^2 - 1);
E_xy = (1/2)*(F_xx_new.*F_xy_new + F_yx_new.*F_yy_new - 0);
E_yy = (1/2)*(F_xy_new.^2 + F_yy_new.^2 - 1);

I2 = sqrt((1/2)*(E_xx.^2 + E_yy.^2) + E_xy.^2);

% sum(sum(F_xx_new~=F_xx_nn)) + sum(sum(F_xy_new~=F_xy_nn)) + sum(sum(F_yx_new~=F_yx_nn)) + sum(sum(F_yy_new~=F_yy_nn)) + ...
%      sum(sum(TAU_xx_new~=TAU_xx_nn)) + sum(sum(TAU_xy_new~=TAU_xy_nn)) + sum(sum(TAU_yy_new~=TAU_yy_nn))

%==========================================================================
% PLOT (uncomment)
%==========================================================================
% for n = 1:length(F_xx_n)
%     patch('Faces',[1 2 3],'Vertices', ...
%         [GCO(:,E2N(1:3,n))'/1000 F_xx_n(1:3,n)],'EdgeColor','white')
%     hold on
% end
% %alpha(0.2)
% hold on
% plot3(GIP_xF/1000,GIP_yF/1000,F_xx_new,'.')