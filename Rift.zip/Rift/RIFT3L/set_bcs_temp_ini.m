function [Bc_ind, Bc_val, Point_id] = set_bcs_temp_ini(...
    GCOORD, Corner_id, Cornin_id, Point_id,temp_bc,temp_bc_depth, ...
    ini_deformation, sigma_tx,sigma_tz)

%top right
Bc_ind = [ Corner_id(3)];
Bc_val = [ 0];
%top left
Bc_ind = [Bc_ind Corner_id(4)];
Bc_val = [Bc_val 0];
%Remove corner nodes from segement ids
Point_id(Corner_id) = -1;

%Remove corner nodes from segement ids
Point_id(Cornin_id) = -1;

% Upper boundary
Bc_tmp = find(Point_id==max(Point_id)-1);
Bc_ind = [Bc_ind Bc_tmp];
Bc_val = [Bc_val zeros(size(Bc_tmp))];

switch ini_deformation
    case {0,5}
        xisotherm = linspace(min(GCOORD(1,:)),max(GCOORD(1,:)),1000);
        yisotherm = temp_bc_depth*ones(size(xisotherm));
        % Nodes below boundary condition
        Bc_tmp = find((interp1(xisotherm,yisotherm,GCOORD(1,:))-GCOORD(2,:))>=0);
        Bc_ind = [Bc_ind Bc_tmp];
        Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];
        
    case {1,2,3,6}
        % Bottom boundary
        Bc_tmp = find(GCOORD(2,:) <= temp_bc_depth); % Nodes below
        % boundary condition
        Bc_ind = [Bc_ind Bc_tmp];
        Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];
        
    case 4
        xisotherm = linspace(min(GCOORD(1,:)),max(GCOORD(1,:)),1000);
        yisotherm = temp_bc_depth + sigma_tz*exp(-xisotherm.^2./((sigma_tx/2)^2));
        % Nodes below boundary condition
        Bc_tmp = find((interp1(xisotherm,yisotherm,GCOORD(1,:))-GCOORD(2,:))>=0);
        Bc_ind = [Bc_ind Bc_tmp];
        Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];    
        
end

%CORNERS
%bot left
Bc_ind = [Bc_ind Corner_id(1)];
Bc_val = [Bc_val temp_bc];

%bot right
Bc_ind = [Bc_ind Corner_id(2)];
Bc_val = [Bc_val temp_bc];

% Bottom boundary
Bc_tmp = find(Point_id==1);
Bc_ind = [Bc_ind Bc_tmp];
Bc_val = [Bc_val temp_bc*ones(size(Bc_tmp))];
