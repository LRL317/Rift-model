function [GEOMETRY,Geo_id,Intersect_ID] = ...
    fix_tri_int(GEOMETRY,Geo_id,Intersect_ID)
% [GEOMETRY,GEO_ID,INTERSECT_ID] = FIX_TRI_INT(GEOMETRY,GEO_ID,
% INTERSECT_ID) finds the triangles with one vertex corresponding to an
% intersection (INTERSECT_ID) between interfaces and which two of their
% sides are GEOMETRY elements of the interfaces intersecting for then to
% check (using checkmesh.m) if they have a good 'pseudo-delaunay' shape. If
% they don't, this will trigger a remeshing on the next time step or it
% might produce a error in generate_mesh.m. In order to fix this kind of
% problem this function adds an extra node in this case between points P1
% and P2.
%
% Example:
% --------                                           . Normal geometry node
%               P1        P3                         x Intersection node
% _______.______x_________.___ Interface 2
%                \                              P1, P2 and P3 is the
%                 \.P2                          triangle to evaluate
%                   \____.____ Interface 1
%
%       LP2  LP1    RP1 RP2
% ___.___.___x___.___x___.___.___ Interface 2
%           /         \                        RP Vertex of right triangles
% ___.___._/           \_.___.___ Interface 1  LP Vertex of left triangles
%       LP3             RP3

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 12-09-2014. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%==========================================================================
% INDEX THE GEOMETRY INTERSECTION NODES
%==========================================================================

% Create a vector where 1s in Intersect_ID are substituted by consecutive
% numbers from 1 to the number of intersection points
Int_id = Intersect_ID.*cumsum(Intersect_ID);

%==========================================================================
% TRIANGLES AT THE RIGHT INTERSECTION (RP)
%==========================================================================
% Take odd numbers of Int_id to create an index of P1
Rint1 = (Int_id/2)~=floor(Int_id/2) & Int_id~=0;
Rint1 = find(Rint1);
% Take previous points to P1 (same interface) to create an index of P2
Rint2 = Rint1-1;
% Indexes of P1 in pointlist. LOC will be a zero vectors where would be n
% where the n P1 is found (n = 1,2,...,number of P1s). Note that P1
% (intersection point) is repeated at interfaces 1 and 2
[~,LOC] = ismember(GEOMETRY',GEOMETRY(:,Rint1)','rows');
% Find first repetead points which are the ones on the interface evaluated
[~,Ind_rep] = unique(LOC,'first');
Ind_rep(1) = [];
% Find the common intersection points, both in the evaluated interface and
% the ones at interfaces above
Rint3 = find(LOC~=0);
% Remove repeated intersection points
Rint3(ismember(Rint3,Ind_rep)) = [];
% Order for Rint3
[~,Order] = ismember(GEOMETRY(:,Rint1)',GEOMETRY(:,Rint3)','rows');
% Reorder Rint3
Rint3 = Rint3(Order);
% Previous point
Rint3 = Rint3'-1;
% Loop through each evaluated triangle to calculate quality of the shape
Rqn = zeros(1,length(Rint1));
for ii = 1:length(Rint1)
    Rp = GEOMETRY(:,[Rint1(ii) Rint2(ii) Rint3(ii)]);
    [qn,amin,amax] = checkmesh(Rp,[1;2;3]);
    Rqn(ii) = qn<0.2 | amin<7 | amax>170;
end

%==========================================================================
% TRIANGLES AT THE LEFT INTERSECTION (LP)
%==========================================================================
% Take pair numbers of Int_id to create an index of P1
Lint1 = (Int_id/2)==floor(Int_id/2) & Int_id~=0;
Lint1 = find(Lint1);
% Take next points to P1 (same interface) to create an index of P2
Lint2 = Lint1+1;
% Indexes of P1 in pointlist. LOC will be a zero vectors where would be n
% where the n P1 is found (n = 1,2,...,number of P1s). Note that P1
% (intersection point) is repeated at interfaces 1 and 2
[~,LOC] = ismember(GEOMETRY',GEOMETRY(:,Lint1)','rows');
% Find first repetead points which are the ones on the interface evaluated
[~,Ind_rep] = unique(LOC,'first');
Ind_rep(1) = [];
% Find the common intersection points, both in the evaluated interface and
% the ones at interfaces above
Lint3 = find(LOC~=0);
% Remove repeated intersection points
Lint3(ismember(Lint3,Ind_rep)) = [];
% Order for Lint3
[~,Order] = ismember(GEOMETRY(:,Lint1)',GEOMETRY(:,Lint3)','rows');
% Reorder Lint3
Lint3 = Lint3(Order);
% Previous point
Lint3 = Lint3'+1;
% Loop through each evaluated triangle to calculate quality of the shape
Lqn = zeros(1,length(Lint1));
for ii = 1:length(Lint1)
    Lp = GEOMETRY(:,[Lint1(ii) Lint2(ii) Lint3(ii)]);
    [qn,amin,amax] = checkmesh(Lp,[1;2;3]);
    Lqn(ii) = qn<0.2 | amin<7 | amax>170;
end

%==========================================================================
% FIX NON-DELAUNAY TRIANGLES
%==========================================================================

% Example:
% --------
%            RP1   RP2
% _____.______x_____._____._____._____ Interface 2
%              ''--__
%                    ''--__
%                  o       ''--_._____ Interface 1
%                New point     RP3
%                that will
%                connect RP1 and RP3 at interface 1
%                so that the new intersection triangle
%                has a better shape

% Make Rint and Lint a boolean vector
Rint = Rint2(Rqn==1);
Lint = Lint2(Lqn==1);

% Fix right triangles
% -------------------
% Loop for n bad triangles
for n = 1:sum(Rqn)
    % Horizontal distance between RP1 and RP2 divided by 2
    Rinc = (GEOMETRY(:,Rint(n))-GEOMETRY(:,Rint(n)+1))/2;
    % Add a point to GEOMETRY that is between RP1 and RP2 horiozontally and 
    % has the same y-coordinate as RP2 so that the shape of the new
    % triangle is delaunay or closer than before
    GEOMETRY = [GEOMETRY(:,1:Rint(n)) ...
        [GEOMETRY(1,Rint(n))-Rinc(1); GEOMETRY(2,Rint(n))-Rinc(2)] ...
        GEOMETRY(:,Rint(n)+1:end)];
    % Redimentsion Geo_id for the new point
    Geo_id = [Geo_id(1:Rint(n)) Geo_id(Rint(n)) Geo_id(Rint(n)+1:end)];
    % Redimentsion Intersect_ID for the new point
    Intersect_ID = ...
        [Intersect_ID(1:Rint(n)) 0 Intersect_ID(Rint(n)+1:end)]==1;
    % Add the new point into the indexes for next iteration
    Rint(Rint>Rint(n)) = Rint(Rint>Rint(n))+1;
    Lint(Lint>Rint(n)) = Lint(Lint>Rint(n))+1;
end

for n = 1:sum(Lqn)
    % Horizontal distance between RP1 and RP2 divided by 2
    Linc = (GEOMETRY(:,Lint(n))-GEOMETRY(:,Lint(n)-1))/2;
    % Add a point to GEOMETRY that is between RP1 and RP2 horiozontally and 
    % has the same y-coordinate as RP2 so that the shape of the new
    % triangle is delaunay or closer than before
    GEOMETRY = [GEOMETRY(:,1:Lint(n)-1) ...
        [GEOMETRY(1,Lint(n))-Linc(1); GEOMETRY(2,Lint(n))-Linc(2)] ...
        GEOMETRY(:,Lint(n):end)];
    % Redimentsion Geo_id for the new point
    Geo_id = [Geo_id(1:Lint(n)-1) Geo_id(Lint(n)) Geo_id(Lint(n):end)];
    % Redimentsion Intersect_ID for the new point
    Intersect_ID = ...
        [Intersect_ID(1:Lint(n)-1) 0 Intersect_ID(Lint(n):end)]==1;
    % Add the new point into the indexes for next iteration
    Lint(Lint>Lint(n)) = Lint(Lint>Lint(n))+1;
end