% PHASES PLOT
%   Optional input variables:
%
%               USE                     OPTIONS                 DEFAULTS
%
% color_int     Color of the box        #interfaces x 3 vector  Black
%               and interfaces          with values [0 1]
%
% line_width    Width of the box        #interfaces x 1 vector  1
%               and interfaces          with width values

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 17-02-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

% Plot phases
% -----------


patch('faces',ELEM2NODE(1:3,:)','vertices',GCOORD'/1000, ...
    'facevertexcdata',Phases(:),'FaceColor','flat','EdgeColor','none')
new_color=[
138 173 119
251 238 212
166 124 102
    ]./255
colormap(new_color)
freezeColors

%axis tight
hold on

plot_inibox_filed;

drawnow
hold on