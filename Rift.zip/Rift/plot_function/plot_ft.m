%This is the calculation of the thinning factor for each layer of the rift at a given time
clc;
clear;
crust_thf=[];
crust_thftime=[];
% Initial envelope
% ----------------
%
minValue=0;
L=(300000*2)/10;
 i_i=    % steps
    FN_open='/';  % open variables path
    FN_save='/';  % save file path  
    % dont change below
    
    mkdir(FN_save);  % make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  % load variables
    AGE=num2str(dt/ma*i_i);  % the age of every step, in Myr


indx = 1 : 1: length(GCOORD);
GCO_sur = GCOORD(:,Point_id==max(Point_id-1));
[GCO_sur(1,:),indxs1] = sort(GCO_sur(1,:));
GCO_sur(2,:) = GCO_sur(2,indxs1);

GCO_mf = GCOORD(:,Point_id==max(Point_id-4));
[GCO_mf(1,:),indxs1] = sort(GCO_mf(1,:));
GCO_mf(2,:) = GCO_mf(2,indxs1);

GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
[GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
GCO_moho(2,:) = GCO_moho(2,indxs3);



xinter= -200000:1:200000;

logical_index = TRACKP(2,:)> -120000;  

Y_sur=interp1(GCO_sur(1,:),GCO_sur(2,:),xinter,'linear');
Y_mf=interp1(GCO_mf(1,:),GCO_mf(2,:),xinter,'linear');
Y_litho=interp1(TRACKP(1,logical_index),TRACKP(2,logical_index),xinter,'linear');
Y_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xinter,'linear');


%x=min(GCOORD(1,:)):res_p:max(GCOORD(1,:))
upcrust_thf=17500./(Y_sur -Y_mf);
upcrust_thf(upcrust_thf>=100) =90;
upcrust_thf(find(upcrust_thf>=10 &upcrust_thf<90))=10+upcrust_thf(find(upcrust_thf>=10 &upcrust_thf<90))./80;
crust_thf=35000./(Y_sur -Y_moho);
crust_thf(crust_thf>=90) =90;
crust_thf(find(crust_thf>=10 &crust_thf<90))=10+crust_thf(find(crust_thf>=10 &crust_thf<90))./80;

lithomantle_thf=abs(95000./(Y_moho -Y_litho));
lithomantle_thf(lithomantle_thf>=90) =90;
lithomantle_thf(find(lithomantle_thf>=10 &lithomantle_thf<90))=10+lithomantle_thf(find(lithomantle_thf>=10 &lithomantle_thf<90))./80;


%lithomantle_thf(find(lithomantle_thf>10))=11;


plot(xinter/1000,upcrust_thf,'Color',[62 43 109]./255,'linewidth',2);
hold on
plot(xinter/1000,crust_thf,'Color',[240 100 73]./255,'linewidth',2);
hold on
plot(xinter/1000,lithomantle_thf,'Color',[255 170 50]./255,'linewidth',2);


axis([-200 200 1 11])
set(gca, 'YtickLabel', {'1', '2', '3', '4', '5','6','7','8','9','10','90'})
xlabel('Distance [Km]')
ylabel('Tinned Factor')


