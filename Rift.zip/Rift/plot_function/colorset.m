function newmap=colorset(n);

color_choice=slanCL(n);
nColors = 256;
newmap = interp1(1:size(color_choice,1), color_choice, linspace(1, size(color_choice,1), nColors), 'linear');


