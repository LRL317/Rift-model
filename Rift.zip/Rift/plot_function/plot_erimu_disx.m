%The code computes mu/eri distributions 
% across stratified layers at multiple temporal intervals and archives 
% the results in structured TXT-format text records.

clc;
close all hidden;

for i_i=  % steps
    clear -regexp [^i_i];
    
    FN_open='';  % open variables path
    FN_save='';% save file path   
    % dont change below
    
    mkdir(FN_save); %make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  %load variables
    AGE=num2str(dt/ma*i_i);  %the age of every step
    
    %[x,total_x]=t1200_mu(i_i,FN_open);
    [x,total_x]=t1200_eri(i_i,FN_open);
    
    a=total_x';
    fid=fopen(strcat(FN_save,'mucrust_',AGE,'.txt'),'w');
    fprintf(fid,'%e \n',a);
    fclose(fid);
    
end
    