function [suriso,PPN] = btp_li2(input,OUTPUT,Points,istep_break,wd)

tic
resax = 1;

% loading target files and data
list_dir = dir(input);
load([input,'/',list_dir(4).name],'name','save_step');
%load(strcat(input,'_',num2str(i_i))]);
istep_old  = 1:10:istep_break;

Tris_r = [];
% we just track one point, that is the intersection point of log and
% the first not overlapped isochron,that is Point(:,1)
TPN    = zeros(1,size(istep_old,2));% to save temperature every time step
PPN    = zeros(2,size(istep_old,2));% to save position of the points every time step
BHF    = zeros(1,size(istep_old,2));% to save heat flow
TCT = zeros(1,size(istep_old,2));% to save crust thick
TLT = zeros(1,size(istep_old,2));% to save litho thick
TMLT = zeros(1,size(istep_old,2));% to save lithomantle thick
suriso = zeros(1,size(istep_old,2));

dz     = 5;   
nss    = 1;
% plot_var = {'GCOORD','ELEM2NODE','Point_id','Corner_id','Cornin_id', ...
%     'E2all','dt','ma','istep','km','nel','ISOCHRONS','DISPL','Basement',...
%     'tp_isoc','Temp','Phases','I2','K','surf_proc_s','RHO'};
plot_var = {'GCOORD','ELEM2NODE','Point_id','Corner_id','Cornin_id', ...
    'dt','ma','istep','km','nel','DISPL','ISOCHRONS','Basement',...
    'tp_isoc','Temp','Phases','K','surf_proc_s','RHO','TRACKP'};

for i_i = istep_break:-10:1
    % load data form istep =  step-count
    load(strcat(input,'_',num2str(i_i)),plot_var{:});
    
    % Calculate new positions for points
    %======================================================================     
    TrisNp = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),Points(:,1));
    ii = 1;
    while ~TrisNp
            
        [Topography,~] = find_topo(GCOORD,ELEM2NODE,Point_id);
        py1 = interp1(Topography(1,:),Topography(2,:),Points(1,1),'linear');
        TrisNp = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),[Points(1,1);py1]);
        if TrisNp
            Points = [Points(1,1);py1];
            break
        else
            for ii = 1:100
                py1 = py1-10;
                TrisNp = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),[Points(1,1);py1]);
                if TrisNp
                    Points = [Points(1,1);py1];
                    break
                end
            end
        end
    end
    
   
    %==============================================================================
PPN(:,nss) = Points(:,1);
        % calculate T at step-count
        xp = Points(1,1);
        yp = Points(2,1);
        %             Ftp = TriScatteredInterp(GCOORD(1,:)',GCOORD(2,:)',Temp','natural')
        %             TPN_tris(nss) = Ftp(xp,yp);
      
        

     %%crust_thick/litho_thick/litho_mantel_thick
     indx = 1 : 1: length(GCOORD);   
     GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
     [GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
     GCO_moho(2,:) = GCO_moho(2,indxs3);
     logical_index = TRACKP(2,:)> -120000;  
     
    Yp_sur=yp;
    Yp_litho=interp1(TRACKP(1,logical_index),TRACKP(2,logical_index),xp,'linear');
    Yp_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xp,'linear');
   
    %TLT(:,nss)=Yp_sur-Yp_litho;
    %TLMT(:,nss)=Yp_moho-Yp_litho;
    litho_thf(1,:)=120000./(Yp_sur -Yp_litho);
    crust_thf(1,:)=35000./(Yp_sur -Yp_moho);

at=0.0000328;
tm=1300;
ah=120*km;
ch=35*km;
rc=2775;
rl=3300;

Lord_pre = rc*(1-at*tm*ch/2/ah)*ch+rl*(1-at*tm*(ah+ch)/2/ah)*(ah-ch);
Lord_after_crust= rc*(1-at*tm*ch*litho_thf/2/ah./crust_thf).*(ch./crust_thf);
Lord_after_litho= rl*(1-at*tm*(ah*crust_thf+ch*litho_thf)/2/ah./crust_thf).*(ah./litho_thf - ch./crust_thf);
Lord_after= Lord_after_crust +  Lord_after_litho;  
Lord_diff=Lord_pre-Lord_after;
Upwell=Lord_diff./(rl*(1-at*tm));
suriso(:,nss)=ah*(1-1./(litho_thf))-Upwell;

        nss      = nss + 1;
        clear p t Yp_sur Yp_litho Yp_moho

for dtten=1:10
   
    %Calculate pionts in back mat;this back mat=-dt,just 10000yr
     GCOORD0 = GCOORD-DISPL*dt; % we bring the points backward dt=10000yr
    % Calculate original edge-node and 7th-node positions
    GCOORD0(:,ELEM2NODE([6 4 5],:)) = 0.5*(GCOORD0(:,ELEM2NODE([1 2 3],:)) ...
        + GCOORD0(:,ELEM2NODE([2 3 1],:)));
    GCOORD0(:,ELEM2NODE(7,:))       = 1/3*(GCOORD0(:,ELEM2NODE(1,:))+ ...
        GCOORD0(:,ELEM2NODE(2,:))+GCOORD0(:,ELEM2NODE(3,:)));
    GCOORDd = GCOORD;
    % Forward track to get the original positions fo nodes 4 to 7
    % before correction to get a straight triangle (the correctino
    % which occurs after the mechanical)
    
    GCOORDd(:,ELEM2NODE(4:7,:)) = ...
        GCOORD0(:,ELEM2NODE(4:7,:)) + DISPL(:,ELEM2NODE(4:7,:))*dt;
    
    % Displacements at nodes due to the deformation of the triangle at the
    % edges
    DN = GCOORD-GCOORDd;
    %==============================
    % Displacement at the tracking point due to the deformation of the
    % triangle at the edges
    DTNp(1,:) = remesh_val(TrisNp,GCOORD,Points(:,1),DN(1,:),ELEM2NODE);
    DTNp(2,:) = remesh_val(TrisNp,GCOORD,Points(:,1),DN(2,:),ELEM2NODE);
    
    % Relative position of the tracked point to the nodes at the beginning
    % of the time step
    RelPNp = Points + DTNp;
    
    % Interpolate velocities at the trackpoints
    Vx_tpNp = remesh_val(TrisNp,GCOORD,RelPNp(:,1),DISPL(1,:),ELEM2NODE);
    Vy_tpNp = remesh_val(TrisNp,GCOORD,RelPNp(:,1),DISPL(2,:),ELEM2NODE);
    %=============================
    % calculate new position for the back tracking point
    %=================================================
    Points(:,1) = Points(:,1) - [Vx_tpNp; Vy_tpNp].*dt;
    GCOORD = GCOORD0;
end   
     clear GCOORD
    
    %=================================================
end

 
 
toc

