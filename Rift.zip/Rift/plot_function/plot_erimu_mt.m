%The process involves visualizing structured numerical datasets stored in TXT-formatted files,
%determining extremum values through statistical analysis,
%and generating temporal evolution plots of positional variations.
clc;
close all hidden;
maxeri_t=[];
maxeri_x=[];
 
for i_i=1:100:4001  % steps
    
    %clear -regexp [^i_i];
    
     FN_open='eri/crust';  % open variables path\txt
  
    % dont change below
    it=i_i/100;
    % load variables
    AGE=num2str(0.01*i_i);  % the age of every step, in Myr
     a=load(strcat(FN_open,'eri_',AGE,'.txt'));
    maxeri=max(a);
    index_eri = find(a == maxeri);
     %rows = size(a, 1);
     %comrows = zeros(rows*2, 1);

    x=-200:1:199;
    x=x';
    maxeri_t(end+1,:)=i_i;
    maxeri_x(end+1,:)=x(index_eri);
    
    %yti=0:200000:1800000;
    %yticks(yti);
end
plot(maxeri_t,(maxeri_x),'--r');
hold on
%xticks( [-150,-125,-100,-75,-50,-25,0,25,50,75,100,125,150]);
maxeri_t=[];
maxeri_x=[];
 
for i_i=1:100:4001  % stepstest_stand1/S1_v10t10v2
    
    %clear -regexp [^i_i];
    
     FN_open='eri/mantle/';  % open variables path\txt
  
    % dont change below
    it=i_i/100;
    % load variables
    AGE=num2str(0.01*i_i);  % the age of every step, in Myr
     a=load(strcat(FN_open,'eri_',AGE,'.txt'));
    maxeri=max(a);
    index_eri = find(a == maxeri);
     %rows = size(a, 1);
     %comrows = zeros(rows*2, 1);


    x=-200:1:199;
    x=x';
    maxeri_t(end+1,:)=i_i;
    maxeri_x(end+1,:)=x(index_eri);
    
    %yti=0:200000:1800000;
    %yticks(yti);
end
plot(maxeri_t,(maxeri_x),'--b');
hold on
minmu_t=[];
minmu_x=[];

 for i_i=1:100:4001  % stepstest_stand1/S1_v10t10v2
    
    %clear -regexp [^i_i];
    
     FN_open='mu\crust/';  % open variables path\txt
    
    % dont change below
    it=i_i/100;
    % load variables
    AGE=num2str(0.01*i_i);  % the age of every step, in Myr
     a=load(strcat(FN_open,'mu_',AGE,'.txt'));
    minmu=min(a);
    index_mu = find(a == minmu);

    x=-200:1:199;
    x=x';
    minmu_t(end+1,:)=i_i;
    minmu_x(end+1,:)=x(index_mu);
    
    %yti=0:200000:1800000;
    %yticks(yti);
end
plot(minmu_t,abs(minmu_x),'r');
hold on

minmu_t=[];
minmu_x=[];

 fori_i=1:100:4001   % stepstest_stand1/S1_v10t10v2
    
    %clear -regexp [^i_i];
    
     FN_open='mu\mantle/';  % open variables path\txt
    
    % dont change below
    it=i_i/100;
    % load variables
    AGE=num2str(0.01*i_i);  % the age of every step, in Myr
     a=load(strcat(FN_open,'mu_',AGE,'.txt'));
    minmu=min(a);
    index_mu = find(a == minmu);

    x=-200:1:199;
    x=x';
    minmu_t(end+1,:)=i_i;
    minmu_x(end+1,:)=x(index_mu);

end
plot(minmu_t,abs(minmu_x),'b');

hold off

%axis([500 4000 -10 70])


