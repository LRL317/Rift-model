%% tectonic subsidence & thermal history
% getting beta from package
% LOOP;
clear
clc
addpath('\RIFT3L')
addpath('\plot_functions')
%% Parameters
%CONSTANTS
km    = 1000;
ma    = 1e6*365.25*24*60*60;

rho_w = 1000;% water density
kappa = 1e-6;% thermal diffusity
k_s   = 1.8; % thermal conductivity of sed. grain at layers, all sediment
% layers have the same thermal condutivity
k_w   = 0.62;% thermal conductivity of pore fluid, like water
k_c   = 2.1; % thermal conductivity of upper crust
k_m   = 3.3; % thermal conductivity of mantle
Phi0 = 0.49; % all sediment layers should have the same phi0
Coml = 0.27./km; % because of no decompaction, coml is not used here
temp_surf = 0;

%Plotting
doyouplot =0;

%% INPUT
% get depth data from ISOCHRONS
in_dir  = '';%saves
out_dir = '';%txt

% step is choosed from the deepest
istep_break = 1241;
istep_tec  = 1:10:istep_break;
x_log = [20,-69,69,111,-111]*km;

VAR ={'GCOORD','ELEM2NODE','Point_id','Temp','Phases','I2','y_max1',...
    'tp_isoc','Topography','Rho','TRACKP','Ce','Hp','K','base_lithos',...
    'temp_bc','temp_surf','surf_proc_s'};

for il = 1:size(x_log,2)
   
istep_tec  = 1:10:istep_break;
OUTPUT = [out_dir,num2str(istep_tec(end)),'_','log',num2str(x_log(il)/km),'km'];

mkdir(OUTPUT) % creat data-saving directory
load([in_dir,'_',num2str(istep_tec(end)),'.mat'],VAR{:});
[Topography,topo2nodes] = find_topo(GCOORD,ELEM2NODE,Point_id);
y_log = interp1(Topography(1,:),Topography(2,:),x_log(il));
        Points    = [x_log(il);y_log];
        wd = 0;    
 [suriso,PPN] = btp_li2(in_dir,OUTPUT,Points,istep_break,wd);

 filePath2 = fullfile(OUTPUT,strcat(num2str(x_log(il)/km),'_','PPN.txt'));
 fid2=fopen(filePath2,'wt'); 
 for j = 1:length(PPN)
 fprintf(fid2,'%4.4f %4.4f %4.4f %4.4f\n',istep_tec(j),PPN(1,j),PPN(2,j),suriso(j));
 end
 fclose(fid2);
  
end

 





