% 2ND STRAIN RATE INVARIANT PLOT
%   Optional input variables:
%
%               USE                     OPTIONS                 DEFAULTS
%
% color_int     Color of the box        #interfaces x 3 vector  Black
%               and interfaces          with values [0 1]
%
% line_width    Width of the box        #interfaces x 1 vector  1
%               and interfaces          with width values
%
% plot_gt       Plot geotherm in an     0 don't plot geotherm   1
%               additional subplot      1 plot geotherm

%--------------------------------------------------------------------------
% Function written by Lars R??pke. Edited by Miguel Andres-Martinez, 
% 17-02-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%==========================================================================
% MAPPING FROM INTEGRATION POINTS TO NODES - IP CANNOT BE PLOTTED
%==========================================================================
EL2N      = zeros(nel,3); % new connectivity matrix
GCOORD_N  = zeros(2,nel*3);
T_n      = zeros(3,nel);
EL2N(1,:) = 1:3;
nip = 6;
nnodel = 6;
[IP_X, IP_w]    = ip_triangle(nip);
[   Nbig]    = shp_triangle(IP_X, nnodel);
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    T_n(is:ie) = Temp(ELEM2NODE([1 2 3],i));    
end

%==========================================================================
% PLOT
%==========================================================================
% Plot temperature field
% ----------------------
if exist('plot_gt','var')
    if plot_gt
        subplot(2,1,1)
    end
end
%title(['Temperature [C] (',num2str(istep*dt/ma),' Myr)'])
%xlabel('Distance [Km]')
%ylabel('Depth [Km]')
patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata',T_n(:), ...
    'FaceColor','flat')


%goodcolor n=1614\1629\788\782\230\1578\1102\1631\1666\1751\496
%temp194\270\1629\496
color_choice = [
    0.6471         0    0.1294 
1.0000    0.1961         0
    0.9137    0.6314    0.4863
    0.9137    0.8941    0.6510
    0.1059    0.7137    0.6863
         0    0.4627    0.7333
    0.0902    0.1569    0.4111
    ]
 %[0.1412         0    0.8471
 %0.6471         0    0.1294]
 nColors = 256;
newmap = interp1(1:size(color_choice,1), color_choice, linspace(1, size(color_choice,1), nColors), 'linear');
%colormap(newmap)
colormap(flipud(newmap))
shading interp
yticks( [-80,-60,-40,-20,0]);
xticks( [-200,-150,-100,-50,0,50,100,150,200]);
axis([-80 80 -40 inf])
%axis([-200 200 -40 inf])
%pbaspect([10 1 1])
pbaspect([3 1 1])

caxis([0 1300]);

%colorbar('southoutside')
%hc = colorbar;
hold on

% Plot box and interfaces
% -----------------------
plot_box

drawnow
hold on

%plot contour
x_=GCOORD_N(1,:)';
y_=GCOORD_N(2,:)';
z_=T_n(:);
xi=linspace(min(x_),max(x_),100);
yi=linspace(min(y_),max(y_),100);
[XI YI]=meshgrid(xi,yi);
ZI = griddata(x_,y_,z_,XI,YI);

[cs1,h1]=contour(XI/1000,YI/1000,ZI,[1200,1200], 'LineWidth',1.5,'Color','w');
[cs3,h3]=contour(XI/1000,YI/1000,ZI,[900,900], 'LineWidth',1.5,'Color','w');
[cs4,h4]=contour(XI/1000,YI/1000,ZI,[600,600], 'LineWidth',1.5,'Color','w');
[cs5,h5]=contour(XI/1000,YI/1000,ZI,[300,300], 'LineWidth',1.5,'Color','w');



hold on
cc1=clabel(cs1,h1,'LabelSpacing',300,'Color','w','FontSize', 10);
cc3=clabel(cs3,h3,'LabelSpacing',251,'Color','w','FontSize', 10);
cc4=clabel(cs4,h4,'LabelSpacing',300,'Color','w','FontSize', 10);
cc5=clabel(cs5,h5,'LabelSpacing',300,'Color','w','FontSize', 10);


hold off
% Plot geotherm
% -------------
if exist('plot_gt','var')
    if plot_gt
        subplot(2,1,2)
        plot(-GCOORD(2,:)/1000,Temp,'.')
        xlabel('Depth [Km]')
        ylabel('Temperature [C]')
    end
end