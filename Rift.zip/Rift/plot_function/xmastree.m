function xmastree(file,E)
% XMASTREE(FILE,E) loads a step of a model given by the directory FILE and
% plots the differential stresses for a determined strain rate E, for a
% depth profile specified by the user using a GUI graph showing the 
% temperature of the model. If E is leaved empty [] the function will take 
% the boundary condition velocities and calculate the strain rate. Press a 
% click outside of the temperature plot to finish the script and plot the 
% differential stress profile in a new figure.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 20-11-2014. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

% 21/04/2015 MA
    % FIXED an bug where the x-coordinate read from the manual input was
    % not multiplied by 1000 and, therefore, the interpolation of
    % temperatures and phases was not calculated in the correct position
    % FIXED calculated pressures. Now pressures are calculated from the
    % weight of the whole rock column (including topography)
    % ADDED plot_box to the temperature field    

% TODO implement multiple rheologies for a phase

%==========================================================================
% SET UP
%==========================================================================

load(file)

res_p = 1; % [Km]
mpa = 1e6; % MPa
km = 1000; % Km

% Strain calculation
if isempty(E)
    switch bc_v
        case 'ext_rate'
            E = ext_rate/max(GCOORD(1,:));
        case 'ext_erate'
            E = ext_erate;
    end
end

%==========================================================================
% PLOT TEMPERATURES
%==========================================================================
% Calculate temperatures for the elements
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    T_n(is:ie) = Temp(ELEM2NODE([1 2 3],i));    
end

% Plot temperatures
subplot(1,2,1)
patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata',T_n(:),'FaceColor','flat')
shading interp
axis tight
colormap(jet)
colorbar
hold on
plot_box
title('Temperatures')
xlabel('Distance [Km]')
ylabel('Depth [Km]')
hold on

%==========================================================================
% GUI
%==========================================================================
% Initial envelope
% ----------------
% Vertical line
Y = min(GCOORD(2,:)):res_p:max(GCOORD(2,:));
% Initial X
X = min(GCOORD(1,:))*ones(size(Y));
% Plot
plot(X([1 end])/1000,Y([1 end])/1000,'w')
% Get line for later remove
last_line = get(gca, 'children');

keep_plot = 1;
% Plotting loop
while keep_plot
    % Take pointer input
    [x,y] = ginput(1);
    % If inside the area for plotting plot new envelope
    if (x*1000 >= min(GCOORD(1,:)) && x*1000 <= max(GCOORD(1,:))) && ...
            (y*1000 >= min(GCOORD(2,:)) && y*1000 <= max(GCOORD(2,:)))
        subplot(1,2,1)
        hold on
        % Delete previous line in the subplot 1
        delete(last_line(1));
        % Calculate new vector of X
        X = x*1000*ones(size(Y));
        % Plot new line in subplot 1
        plot(X([1 end])/1000,Y([1 end])/1000,'w')
        % Mark last line for later remove
        last_line = get(gca, 'children');
        hold off
        % Remove points above topography
        topo = interp1(GCOORD(1,Point_id==(max(Point_id)-1)), ...
                GCOORD(2,Point_id==(max(Point_id)-1)),x*1000);
        X(Y>topo) = [];
        Y(Y>topo) = [];
            
        % Calculating envelope
        T = griddata(GCOORD(1,:)',GCOORD(2,:)',Temp(:),X,Y);
%         subplot(1,2,2)
%         plot(T,Y/km,'k')

%==========================================================================
% CALCULATE PHASES
%==========================================================================
        % Find interfaces ids
        Interf_id = [1 3:3:max(Point_id)-1];
        
        % Find points where interfaces intersect with the profile
        Interfaces = zeros(1,length(Interf_id));
        for n = 1:length(Interf_id)
            Interfaces(n) = interp1(GCOORD(1,Point_id==Interf_id(n)), ...
                GCOORD(2,Point_id==Interf_id(n)),x*1000);
        end
        
        % Assign phases to Y
        Profile_pha = zeros(length(Y),1);
        for n = 1:length(Interf_id)-1
            Profile_pha(Y>=Interfaces(n) & Y<=Interfaces(n+1)) = n;
        end

%==========================================================================
% BRITTLE
%==========================================================================
        % Brittle shear stress (Mohr-Coulomb)
        T_b = (max(Y)-Y)*2700*9.81.*sin(SS.Phi(1)) + SS.C(1);
        
%         % Plot
%         subplot(1,2,2)
%         hold on
%         plot(T_b/mpa,Y/km,'b')

%==========================================================================
% DISLOCATION CREEP BEHAVIOUR
%==========================================================================
% Hirth and Kohlstedt (2003)

        % Dislocation shear stress
        if exist('RHEOL','var')
            T_dis = (E./RHEOL.Adis(Profile_pha,1)').^ ...
                (1./RHEOL.Ndis(Profile_pha,1)').* ...
                exp(RHEOL.Qdis(Profile_pha,1)'./ ...
                (R*(T+273).*RHEOL.Ndis(Profile_pha,1)'));
        else
            T_dis = (E./Adis(Profile_pha,1)').^ ...
                (1./Ndis(Profile_pha,1)').* ...
                exp(Qdis(Profile_pha,1)'./ ...
                (R*(T+273).*Ndis(Profile_pha,1)'));
        end
        
%         % Plot
%         subplot(1,2,2)
%         hold on
%         plot(T_dis/mpa,Y/km,'.r')
        
%==========================================================================
% DIFFUSION CREEP BEHAVIOUR
%==========================================================================
% Hirth and Kohlstedt (2003)

% Dislocation shear stress
        if exist('RHEOL','var')
            T_dif = (E./RHEOL.Adif(Profile_pha,1)').^ ...
                (1./RHEOL.Ndif(Profile_pha,1)').* ...
                exp(RHEOL.Qdif(Profile_pha,1)'./ ...
                (R*(T+273).*RHEOL.Ndif(Profile_pha,1)'));
        else
            T_dif = (E./Adif(Profile_pha,1)').^ ...
                (1./Ndif(Profile_pha,1)').* ...
                exp(Qdif(Profile_pha,1)'./ ...
                (R*(T+273).*Ndif(Profile_pha,1)'));
        end
        
%         % Plot
%         subplot(1,2,2)
%         hold on
%         plot(T_dif/mpa,Y/km,'.g')

%==========================================================================
% PLOT
%==========================================================================
        % Minimum shear stress
        T_min = min([T_b; T_dis; T_dif]);

        % Plot
        subplot(1,2,2)
        plot(T_min/mpa,Y/km,'k')
        title('Differential stress profile')
        xlabel('\sigma_1-\sigma_3 [MPa]')
        ylabel('Depth [Km]')
%==========================================================================
% END
%==========================================================================
        
        % If outside the area of plotting, finish plotting
    else
        hold off
        keep_plot = 0;
    end
end

figure(333)
hold on
plot(T_min/mpa,Y/km,'k','linewidth',2)
title('Differential stress profile')
xlabel('\sigma_1-\sigma_3 [MPa]')
ylabel('Depth [Km]')
axis([0 max(T_min/mpa)+50 -100 max(Y/km)])
daspect([15 1 1])