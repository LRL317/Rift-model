EL2N      = zeros(nel,3); % new connectivity matrix
GCOORD_N  = zeros(2,nel*3);
E2_n      = zeros(3,nel);
EL2N(1,:) = 1:3;
nip = 6;
nnodel = 6;
[IP_X, IP_w]    = ip_triangle(nip);
[   Nbig]    = shp_triangle(IP_X, nnodel);
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    Dummy      = Nbig'\E2all(i,:)';
    E2_n(:,i)= Dummy(1:3);
end

% Correct negative E2_n which are the result of interpolation
E2_n = abs(E2_n);

%==========================================================================
% PLOT
%==========================================================================
% Plot strain rate
% ----------------
istep_Myr=floor((istep*dt/(ma/10)))/10;
%title(['2nd strain rate invariant (',num2str(istep_Myr),' Myr)'])
%xlabel('Horizontal Position [km]')
%ylabel('Depth [km]')
% Check if the data needs to be plotted on logarithmic color scale
if exist('log_data','var')
    if log_data
        patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
            log10(E2_n(:)),'FaceColor','flat')
    else
        patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
            E2_n(:),'FaceColor','flat')
    end
else
    patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
        log10(E2_n(:)),'FaceColor','flat')
end

%goodcolor n=1614\1629\788\782\230\1578\1102\1631\1666\1751\496 temp194\270\1629

color_choice=[
     0.0157    0.1176    0.2588 
      0.0157    0.0784    0.2588
    0.0039    0.1294    0.4118
      0.0039    0.1647    0.4863
    0    0.2235    0.6118     
    0    0.2392    0.6471      
    0.1725    0.8000    0.8275
    1.0000    0.7804    0.1725
   0.8784    0.2039    0.1882
    0.8353         0    0.1961
]

%[
 %  0.0157    0.1176    0.2588
  %  0.7451    0.2275    0.2039
  %  1.0000    0.6431         0
nColors = 256;
newmap = interp1(1:size(color_choice,1), color_choice, linspace(1, size(color_choice,1), nColors), 'linear');
colormap(newmap)

yticks( [-80,-60,-40,-20,0]);
xticks( [-200,-150,-100,-50,0,50,100,150,200]);

%set (gca,'XDir','reverse')
axis([-150 150 -40 inf])
%axis([-200 200 -40 inf])
%pbaspect([10 1 1])
pbaspect([7.5 1 1])
%set (gca,'XDir','rev

caxis([-22 -13]);

%colormap(flipud(newmap))


%colorbar('southoutside')
%pbaspect([5 1 1])
shading interp
%hc = colorbar;




for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    T_n(is:ie) = Temp(ELEM2NODE([1 2 3],i));    
end






% Plot box and interfaces
% -----------------------
% Define plotbox_s if doesn't exist
if ~exist('plotbox_s','var')
    plotbox_s = 1;
end

if plotbox_s
    plot_box
end
hold on
x_=GCOORD_N(1,:)';
y_=GCOORD_N(2,:)';
z_=T_n(:);
xi=linspace(min(x_),max(x_),100);
yi=linspace(min(y_),max(y_),100);
[XI YI]=meshgrid(xi,yi);
ZI = griddata(x_,y_,z_,XI,YI);

%[cs1,h1]=contour(XI/1000,YI/1000,ZI,[1200,1200],'--', 'LineWidth',2,'Color','w');

%[cs3,h3]=contour(XI/1000,YI/1000,ZI,[600,600],'--', 'LineWidth',2,'Color','w');

hold on
%cc1=clabel(cs1,h1,'LabelSpacing',250,'Color','w');

%cc3=clabel(cs3,h3,'LabelSpacing',300,'Color','w');
%cc5=clabel(cs5,h5,'Color','k');


drawnow
hold off