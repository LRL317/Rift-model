%The code first determines a specific step size, then executes plotting and data store pictures.

clc;
close all hidden;

 i_i=   % i_i= steps
    
    clear -regexp [^i_i];
    
    FN_open='';  % open variables path
    FN_save='';  % save file path   
    
    % dont change below
    
    mkdir(FN_save);  % make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  % load variables
    AGE=num2str(dt/ma*i_i);  % the age of every step, in My
    
    figure(1)
    clf;
    
    %plot_mu
    
    print(strcat(FN_save,'Mu_',AGE,'.jpg'),'-djpeg','-r1000')
    

  
    
   











