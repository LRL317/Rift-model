function [color_scale] = mu_colormap(Mu,invert)

max_mu = max(max(Mu_all));
min_mu = min(min(Mu_all));


