% Elena Ros

function [Crust_thickness,xdike,ydike,indike,tp_melt,TP_xmelt,TP_ymelt,x_shallow,y_shallow,radius_tpmelt_all] = ...
                column_melt_dike_maxE2all_newmesh_belowserp(GCOORD,area_melt,ext_rate,dt,...
                Point_id,ELEM2NODE,Phases,E2all,istep,Crust_thickness,Dserp)
           
% Calculate crustal thickness (assuming all melt of this time step is extracted at the ridge)
dz_crust = area_melt/(ext_rate*dt);
Crust_thickness(istep) = dz_crust/2;

% Find the nodos in the Moho and select the elements of the upper mantle in which the Moho is present.        
Moho_nodes = find(Point_id==3);
mohoe=find(sum(ismember(ELEM2NODE,Moho_nodes),1)& Phases==1);


% Find the element with the maximum strain rate
[max_eri_ii,~] = find(E2all(mohoe,:)==max(max(E2all(mohoe,:))));
max_eri_i = mohoe(max_eri_ii); 

% Find the nodes of this element 
nodes_elem_maxE2all = ELEM2NODE(:,max_eri_i);

% %Identify the node of this elem that belongs to the Moho in order to localize the column
% %of melting
[y_shallow,i_coord] = max(GCOORD(2,nodes_elem_maxE2all(ismember(nodes_elem_maxE2all,Moho_nodes))));
nodes_Moho_maxE2all = nodes_elem_maxE2all(ismember(nodes_elem_maxE2all,Moho_nodes));
x_shallow = GCOORD(1,nodes_Moho_maxE2all(i_coord));

%%%%%%%%%%%%%
if max(Dserp)>=0.001
        
Dserp_test= Dserp;
Dserp_test(Dserp <0.001) = 0;
    
%%Dserp_test(nodes_Moho_maxE2all(i_coord)) % can happen that the point itself does not have Dserp
%any(Dserp(ELEM2NODE(:,max_eri_i))~=0)  % if equals 1 means that this triangle has Dserp
%Dserp_nodes= find(Dserp_test>0);
%Dserp_elems= find(sum(ismember(ELEM2NODE,Dserp_nodes),1)& Phases==1);
% %plot(GCOORD(1,Dserp_nodes)/1000,GCOORD(2,Dserp_nodes)/1000,'*y')
% %Tris   = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),GCOORD(:,Dserp_nodes));
% %plot(GCOORD(1,ELEM2NODE(:,Tris))/1000,GCOORD(2,ELEM2NODE(:,Tris))/1000,'*m')
 
% Dserp_nodes_uni= unique(ELEM2NODE(:,Dserp_elems));

% % find(abs(GCOORD(1,Dserp_nodes_uni)-x_shallow)==min(abs(GCOORD(1,Dserp_nodes_uni)-x_shallow)) & ...
% %      max(abs(GCOORD(2,Dserp_nodes_uni)-y_shallow)))
% 
% % [val,i_node]= min(GCOORD(2,nodes_elem_maxE2all))
% % plot(GCOORD(1,nodes_elem_maxE2all(i_node))/1000,GCOORD(2,nodes_elem_maxE2all(i_node))/1000,'*m','MarkerSize',14)

 
% %  [ma,~] = find(E2all(Dserp_elems,:)==max(max(E2all(Dserp_elems,:))));
% %  mai = Dserp_elems(ma); 
 
[X_sha,Y_sha_depth] = meshgrid(x_shallow, linspace(y_shallow,-20000,100));

%Dserp_nodes_no=find(Dserp_test==0);
% [X_serp1,Y_serp1] = meshgrid(linspace(x_shallow-1000,x_shallow+1000), linspace(y_shallow,-20000,100));
%%%%Dserp_test_interp = griddata(GCOORD(1,Dserp_nodes_uni),GCOORD(2,Dserp_nodes_uni),Dserp_test>0,X_serp1,Y_serp1,'linear');
%Dserp_test_interp = griddata(GCOORD(1,:),GCOORD(2,:),Dserp_test,X_serp1,Y_serp1,'linear')
%plot(X_serp1(Dserp_test_interp>0)/1000,Y_serp1(Dserp_test_interp>0)/1000,'y*')

Dserp_test_interp = griddata(GCOORD(1,:),GCOORD(2,:),Dserp_test,X_sha,Y_sha_depth,'linear');
%plot(X_sha(Dserp_test_interp>0)/1000,Y_sha_depth(Dserp_test_interp>0)/1000,'r*')
%hold on

if max(Dserp_test_interp)~=0
y_shallow_new = min(Y_sha_depth(Dserp_test_interp>0));
%plot(X_sha/1000,Y_sha_depth/1000,'r*')
%plot(x_shallow/1000,y_shallow/1000,'g*')
%plot(x_shallow/1000,y_shallow_new/1000,'*r','MarkerSize',14)
%plot(x_shallow/1000,Y_sha_depth(Dserp_test_interp==0)/1000,'c*')
y_shallow = y_shallow_new;
end
% [val,ii]=find(abs(GCOORD(1,Dserp_nodes_no)-x_shallow)== ...
%      min(abs(GCOORD(1,Dserp_nodes_no)-x_shallow)))



% for i=1:length(Y_sha_depth)
% [val,ii]=find(abs(GCOORD(2,Dserp_nodes_no)-Y_sha_depth(i))== ...
%      max(abs(GCOORD(2,Dserp_nodes_no)-Y_sha_depth(i))))
% end
%     for i=1:length(Dserp_nodes)
%         [val, els(Dserp_nodes(i))] = min(sqrt((x_shallow - GCOORD(1,Dserp_nodes(i))).^2 ));
%     end
end
%%%%%%%%%%%%%

% Calculate the thickness of the column at the correct depth to locate it
zbottom_thick = y_shallow-dz_crust/2; %means the thickness is the crustal thickness

%Column_melt will be given by
if (dz_crust/2)<1000
    scale = 100;
else
    scale = 1000;
end

column_melt1 = [(x_shallow-ext_rate*dt)*ones(1,ceil(dz_crust/(2*scale)));...  
                  linspace(y_shallow,zbottom_thick,ceil(dz_crust/(2*scale)))];
column_melt2 = [(x_shallow+ext_rate*dt)*ones(1,ceil(dz_crust/(2*scale)));...  
                  linspace(y_shallow,zbottom_thick,ceil(dz_crust/(2*scale)))];
              
              
area_tpmelt = area_melt/ceil(dz_crust/(2*scale));   
radius_tpmelt = sqrt(area_tpmelt/pi); %m
radius_tpmelt_all = repmat(radius_tpmelt,2*ceil(dz_crust/(2*scale)),1)';              
              
              
              
              
[TP_xmelt1,TP_ymelt1]=meshgrid(column_melt1(1,1), linspace(y_shallow,...
                        zbottom_thick,ceil(dz_crust/(2*scale))));
[TP_xmelt2,TP_ymelt2]=meshgrid(column_melt2(1,1), linspace(y_shallow,...
                        zbottom_thick,ceil(dz_crust/(2*scale))));
 TP_xmelt=[TP_xmelt1;TP_xmelt2];
 TP_ymelt=[TP_ymelt1;TP_ymelt2];
 
 % Dike modelling
             line_left=[(x_shallow-ext_rate*dt)*ones(1,floor(dz_crust/(2*10)));...
                         linspace(y_shallow,zbottom_thick,floor(dz_crust/(2*10)))];
      
             line_right=[(x_shallow+ext_rate*dt)*ones(1,floor(dz_crust/(2*10)));...
                         linspace(y_shallow,zbottom_thick,floor(dz_crust/(2*10)))];
                     
             line_top = [linspace(x_shallow-ext_rate*dt,x_shallow+ext_rate*dt,...
                        floor(ext_rate*dt/(2*10))); y_shallow*ones(1,floor(ext_rate*dt/(2*10)))];

             line_bottom = [linspace(x_shallow-ext_rate*dt,x_shallow+ext_rate*dt,...
                          floor(ext_rate*dt/(2*10))); (zbottom_thick)...
                          *ones(1,floor(ext_rate*dt/(2*10)))];
             
             xdike = [ line_left(1,:),line_top(1,:),line_right(1,:),fliplr(line_bottom(1,:))] ;
             ydike = [ line_left(2,:),line_top(2,:),line_right(2,:),fliplr(line_bottom(2,:))];
             indike = inpolygon(GCOORD(1,:),GCOORD(2,:),xdike,ydike);
             
             clear 'line_left' 'line_right' 'line_top' 'line_bottom'
             
tp_melt = 1; %to check is doing well the melt emplacement

end

