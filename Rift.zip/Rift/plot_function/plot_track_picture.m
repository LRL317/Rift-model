%The code first determines a specific step size, then executes plotting
%with trackpoints


clc;
close all hidden;

 i_i=   % steps
    
    clear -regexp [^i_i];
    
    FN_open='';  % open variables path\
    FN_save='';  % save file path   
    
    % dont change below
   
    mkdir(FN_save);  % make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  % load variables
    AGE=num2str(dt/ma*i_i);  % the age of every step, in My
    
   %Track pionts
PPN0=load('txt');
PPN0100=load('txt');
PPN050=load('txt');
PPN50=load('txt');
PPN100=load('txt');
    
figure(1)
    clf;
 
    %plot_strength;
   it=125-(i_i-1)/10;
   plot_phases_li;
   hold on
   scatter(PPN0(it,2)/km,PPN0(it,3)/km,60,[62 43 109]./255,'filled');%purple
   hold on
   scatter(PPN50(it,2)/km,PPN50(it,3)/km,60,[230 56 56]./255,'filled');
   hold on
   scatter(PPN050(it,2)/km,PPN050(it,3)/km,60,[255 170 50]./255,'filled');
   hold on
   scatter(PPN0100(it,2)/km,PPN0100(it,3)/km,60,[48 151 164]./255,'filled');
   hold on
   scatter(PPN100(it,2)/km,PPN100(it,3)/km,60,[5 80 91]./255,'filled');

    
  
    
   











