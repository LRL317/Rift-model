% Plot track points
% zzx

    function   [x_l,y_l,x_r,y_r]=Point_xy_steps(temp_temp,dis_given)


        x=temp_temp(end-1,:); % initial coordinate
        [~,ind_l]=min(abs(-dis_given-x)); % left index
        [~,ind_r]=min(abs(dis_given-x)); % right index
        x_l=[];
        y_l=[];
        x_r=[];
        y_r=[];
        for i=1:2:size(temp_temp,1)
            x_l=[temp_temp(i,ind_l),x_l];  % x location of every step for the initial point -dis_given
            x_r=[temp_temp(i,ind_r),x_r];  % x location of every step for the initial point dis_given
        end
        for i=2:2:size(temp_temp,1)
            y_l=[temp_temp(i,ind_l),y_l];  % y location of every step for the initial point -dis_given
            y_r=[temp_temp(i,ind_r),y_r];  % y location of every step for the initial point dis_given
        end










        
        
        
        
        
        
        
        
        
        
        
        