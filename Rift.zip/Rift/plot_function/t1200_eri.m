function [x,total_x]=t1200_eri(i_i,FN_open)

clear -regexp [^i_i, FN_open];
    load(strcat(FN_open,'_',num2str(i_i)));
 

%bulid the grid
EL2N      = zeros(nel,3); % new connectivity matrix
GCOORD_N  = zeros(2,nel*3);
Mu_n      = zeros(3,nel);
EL2N(1,:) = 1:3;
nip = 6;
nnodel = 6;
res_p = 1;

[IP_X,~]    = ip_triangle(nip);
[N,~] =shp_deriv_triangle(IP_X, nnodel);
[   Nbig]    = shp_triangle(IP_X, nnodel);
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    Dummy      = Nbig'\E2all(i,:)';
    E2_n(:,i)= Dummy(1:3);
end
E2all(:)=abs(E2all(:));
%E2all(:) = log10(E2all(:));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
GIPxp = zeros(size(E2all));
GIPyp = zeros(size(E2all));

for ip = 1:nip
    Ni = N{ip};
    ECOORD_xp = reshape(GCOORD(1,ELEM2NODE(1:6,:)),nnodel,nel);
    ECOORD_yp = reshape(GCOORD(2,ELEM2NODE(1:6,:)),nnodel,nel);
    GIPxp(:,ip) = Ni'*ECOORD_xp;
    GIPyp(:,ip) = Ni'*ECOORD_yp;
end


% Initial envelope
% ----------------
GCO_sur = GCOORD(:,Point_id==max(Point_id-1));
[GCO_sur(1,:),indxs1] = sort(GCO_sur(1,:));
GCO_sur(2,:) = GCO_sur(2,indxs1);

GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
[GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
GCO_moho(2,:) = GCO_moho(2,indxs3);

indx = 1 : 1: length(GCOORD);  
EL2N      = zeros(nel,3); % new connectivity matrix
GCOORD_N  = zeros(2,nel*3);
T_n      = zeros(3,nel);
EL2N(1,:) = 1:3;
nip = 6;
nnodel = 6;
[IP_X, IP_w]    = ip_triangle(nip);
[   Nbig]    = shp_triangle(IP_X, nnodel);
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    T_n(is:ie) = Temp(ELEM2NODE([1 2 3],i));    
end
x_=GCOORD_N(1,:)';
y_=GCOORD_N(2,:)';
z_=T_n(:);
xi=linspace(min(x_),max(x_),1000);
yi=linspace(min(y_),max(y_),1000);
[XI YI]=meshgrid(xi,yi);
ZI = griddata(x_,y_,z_,XI,YI);
[td,hd]=contour(XI,YI,ZI,[1200,1200], 'LineWidth',1,'Color','w');
t_litho = td(:, 2:end);

[t_lithox, ia, ic] =  unique(t_litho(1,:));
t_lithox = t_litho(1,ia);
t_lithoy = t_litho(2,ia);

xinter=-200000 :1: 200000;
Y_sur=interp1(GCO_sur(1,:),GCO_sur(2,:),xinter,'spline');
Y_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xinter,'spline');
Y_litho=interp1(TRACKP(1,:),TRACKP(2,:),xinter,'spline');
Y_t1200=interp1(t_lithox,t_lithoy,xinter,'linear');
%x=min(GCOORD(1,:)):res_p:max(GCOORD(1,:))

total_eri=[];
x=[];
for xi=1:1:400

x(xi)=xi-201;
xt=xi*1000+1;
Y = Y_t1200(xt):1:Y_moho(xt);

% Initial X
X = x(xi)*1000*ones(size(Y));

% Calculating envelope
Envelope = griddata(GIPxp(:),GIPyp(:),E2all(:),X,Y);
%total_mu(xi) = nansum(Envelope);%mean
total_mu(xi) = nanmean(Envelope);
end
total_x=total_mu;
end


