
indx = 1 : 1: length(GCOORD);
GCO_sur = GCOORD(:,Point_id==max(Point_id-1));
[GCO_sur(1,:),indxs1] = sort(GCO_sur(1,:));
GCO_sur(2,:) = GCO_sur(2,indxs1);

GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
[GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
GCO_moho(2,:) = GCO_moho(2,indxs3);

GCO_mf = GCOORD(:,Point_id==max(Point_id-4));
[GCO_mf(1,:),indxs1] = sort(GCO_mf(1,:));
GCO_mf(2,:) = GCO_mf(2,indxs1);


Len_right=floor((max(GCO_sur(1,:))/10))*10;
Len_left=floor((min(GCO_sur(1,:))/10))*10;

xinter= Len_left:1:Len_right;
logical_index = TRACKP(2,:)> -120000;  
%TRACKP(2,logical_index)=-70000;

Y_sur=interp1(GCO_sur(1,:),GCO_sur(2,:),xinter,'linear');
Y_mf=interp1(GCO_mf(1,:),GCO_mf(2,:),xinter,'linear');
Y_litho=interp1(TRACKP(1,logical_index),TRACKP(2,logical_index),xinter,'linear');
%Y_litho=interp1(TRACKP(1,:),TRACKP(2,:),xinter,'linear');

Y_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xinter,'linear');
% Plot the box
%trackp astenosphere
plot(xinter/km,Y_sur/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_moho/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_mf/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_litho/km,'color','k','LineWidth',1);
hold on

%x_intersect = interp1(Y_litho/km, xinter/km, -40);

%patch([xinter/km 0], [Y_litho/km -50], [158 69 51]./255);

%xlitho= min(Y_litho):1:max(Y_litho);
fill(xinter/km, Y_litho/km,[158 69 51]./255);

%a=area( Y_litho/km);
%a.FaceColor = [158 69 51]./255;

%surface
%fill( Y_sur/km, Y_mf/km, 'g')
%axis([-200 200 -120 inf])
yticks( [-60,-40,-20,0]);
%yticks( [-30,-15,0]);
xticks( [-150,-100,-50,0,50,100,150]);

%set (gca,'XDir','reverse')
axis([-150 150 -40 inf])
%axis([-200 200 -40 inf])
%pbaspect([2.5 1 1])
pbaspect([7.5 1 1])
box on
ax.Box = 'off';
set(gca,'Box','off');
set(gca,'TickDir','out');
%set(gca,'TickLength',[0.005,0.035])

%title([num2str(istep_Myr), 'Myr'])
%xlabel('Horizontal Position [Km]')
%ylabel('Depth [Km]')
%-160:20:0;

