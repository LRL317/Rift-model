
indx = 1 : 1: length(GCOORD);
X=[GCOORD(1,indx)/km; GCOORD(2,indx)/km];
% First determine the grid size and extent
gridSize = 8; 
xMin = min(X(1,:));
xMax = max(X(1,:));
yMin = min(X(2,:));
yMax = max(X(2,:));

% Calculate the number of grid nodes
nX = ceil((xMax - xMin) / gridSize);
nY = ceil((yMax - yMin) / gridSize);

% Initialize the nearest point of each grid node to NaN
nearestPoints = NaN(nX, nY);

% For each grid node, find the closest point to it
for i = 1:nX-1
    for j = 1:nY
        % Calculate the center coordinates of the current node
        xGridCenter = xMin + (i-0.5)*gridSize;
        yGridCenter = yMin + (j-0.5)*gridSize;
        
        % Calculate the distance from the current node to all random points and find the minimum and the corresponding indexes
        distances = sqrt(sum((X' - [xGridCenter, yGridCenter]).^2, 2));
        [minDist, minIdx] = min(distances);
        
        nearestPoints(i,j) = minIdx;
    end
end
np = nearestPoints(:);
npt=np(~isnan(np));


quiver(GCOORD(1,npt)/km, GCOORD(2,npt)/km, Vel(npt*2-1)', Vel(npt*2)',1,'Color','k');




