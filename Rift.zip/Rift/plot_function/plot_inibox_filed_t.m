
indx = 1 : 1: length(GCOORD);
GCO_sur = GCOORD(:,Point_id==max(Point_id-1));
[GCO_sur(1,:),indxs1] = sort(GCO_sur(1,:));
GCO_sur(2,:) = GCO_sur(2,indxs1);

GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
[GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
GCO_moho(2,:) = GCO_moho(2,indxs3);

GCO_mf = GCOORD(:,Point_id==max(Point_id-4));
[GCO_mf(1,:),indxs1] = sort(GCO_mf(1,:));
GCO_mf(2,:) = GCO_mf(2,indxs1);


Len_right=floor((max(GCO_sur(1,:))/10))*10;
Len_left=floor((min(GCO_sur(1,:))/10))*10;

xinter= Len_left:1:Len_right;
logical_index = TRACKP(2,:)> -120000;  

Y_sur=interp1(GCO_sur(1,:),GCO_sur(2,:),xinter,'linear');
Y_mf=interp1(GCO_mf(1,:),GCO_mf(2,:),xinter,'linear');
Y_litho=interp1(TRACKP(1,logical_index),TRACKP(2,logical_index),xinter,'linear');
Y_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xinter,'linear');
% Plot the box

%trackp astenosphere
plot(xinter/km,Y_sur/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_moho/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_mf/km,'color','k','LineWidth',1);
hold on
plot(xinter/km,Y_litho/km,'color','k','LineWidth',1);
hold on
%surface
fill( xinter/km, Y_litho/km,[158 69 51]./255)



%hold on
%fill( Y_sur/km, Y_mf/km, 'g')


%axis([-200 200 -120 inf])
yticks( [-80,-60,-40,-20,0]);
xticks( [-120,-80,-40,0,40,80,120]);
axis([-120 120 -60 inf])

pbaspect([4 1 1])

pbaspect([4 1 1])
box on
ax.Box = 'off';
set(gca,'Box','off');
set(gca,'TickDir','out');
set(gca,'TickLength',[0.005,0.035])

%title([num2str(istep_Myr), 'Myr'])
%xlabel('Horizontal Position [Km]')
%ylabel('Depth [Km]')
%-160:20:0;

