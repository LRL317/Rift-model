%This part of the code calculates the crustal thinning factor over time

clc;
clear;
crust_thf=[];
crust_thftime=[];
% Initial envelope
% ----------------
%
minValue=0;
L=(310000*2)/10;
for i_i=1241:-10:1  % stepstest_stand1
    FN_open='';  % open variables path
    FN_save='';  % save file path  
    % dont change below
    
    mkdir(FN_save);  % make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  % load variables
    AGE=num2str(dt/ma*i_i);  % the age of every step, in Myr

indx = 1 : 1: length(GCOORD);
GCO_sur = GCOORD(:,Point_id==max(Point_id-1));
[GCO_sur(1,:),indxs1] = sort(GCO_sur(1,:));
GCO_sur(2,:) = GCO_sur(2,indxs1);

GCO_moho = GCOORD(:,Point_id==max(Point_id-7));
[GCO_moho(1,:),indxs3] = sort(GCO_moho(1,:));
GCO_moho(2,:) = GCO_moho(2,indxs3);

Len_right=floor((max(GCO_sur(1,:))/10))*10;
Len_left=floor((min(GCO_sur(1,:))/10))*10;

xinter= Len_left:10:Len_right;

padSize =floor( (L - length(xinter)) / 2);
padVector = minValue * ones(1, padSize); 



Y_sur=interp1(GCO_sur(1,:),GCO_sur(2,:),xinter,'linear');
Y_litho=interp1(TRACKP(1,:),TRACKP(2,:),xinter,'linear');
Y_moho=interp1(GCO_moho(1,:),GCO_moho(2,:),xinter,'linear');

Y_sur= [padVector, Y_sur, padVector];  
Y_litho= [padVector, Y_litho, padVector]; 
Y_moho= [padVector, Y_moho, padVector];


%x=min(GCOORD(1,:)):res_p:max(GCOORD(1,:))
crust_thf(1,:)=35000./(Y_sur -Y_moho);
%litho_fthc(1,:)=(Y_litho)/km;

crust_thftime(end+1,:)=crust_thf(1,:);
%(i_i,:)=xt;
end



%time_fy=1:10:length(time_lithof(1,:));
%time_fx=1:10:length(time_lithof(1,:));


crust_thftime(isinf(crust_thftime)) = 0;
data1=crust_thftime;
data1(find(data1>=9)) = 1110;
data1(find(data1>=7& data1<9)) = 1010;
data1(find(data1>=5 & data1<7)) = 910;
data1(find(data1>=3.5 & data1<5)) = 810;
data1(find(data1>=3 & data1<3.5)) = 710;
data1(find(data1>=2.5 & data1<3)) = 610;
data1(find(data1>=2 & data1<2.5)) = 510;
data1(find(data1>=1.6 & data1<2)) = 410;
data1(find(data1>=1.3 & data1<1.6)) = 310;
data1(find(data1>=1 & data1<1.3)) = 210;
%data1(find(data1>=0.5 & data1=<1)) = 210;
data1(find(data1 <1 )) = 110;


h=imagesc(data1);
%set(h,'alphadata',~isinf(data1));

set (gca,'YDir','reverse');
color_choice=[
 0.4863         0         0
    0.6471         0    0.1294 
1.0000    0.1961         0
    0.9137    0.6314    0.4863
    0.9137    0.8941    0.6510
    0.6431    0.8353    0.6627
    0.1059    0.7137    0.6863
         0    0.4627    0.7333
    0.0902    0.1569    0.4111
    
    1 1  1     
]
nColors = 25;
newmap = interp1(1:size(color_choice,1), color_choice, linspace(1, size(color_choice,1), nColors), 'linear');
colormap(flipud(color_choice))
%colormap(flipud(newmap))
c = colorbar;
%caxis([0 9]);
c = colorbar;
set(c,'Ticks',100:100:1200,'TickLabels',{'0','1','1.3','1.6','2','2.5','3','3.5','5','7','9'});

xlabel('Distance [Km]')
ylabel('Time [Ma]')


