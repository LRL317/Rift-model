% VISCOSITY PLOT
%   Optional input variables:
%
%               USE                     OPTIONS                 DEFAULTS
%
% color_int     Color of the box        #interfaces x 3 vector  Black
%               and interfaces          with values [0 1]
%
% line_width    Width of the box        #interfaces x 1 vector  1
%               and interfaces          with width values
%
% log_data      Plot logarithmic data   0 no logarithmic data   1
%                                       1 logarithmic data

%--------------------------------------------------------------------------
% Function written by Lars Rüpke. Edited by Miguel Andres-Martinez, 
% 17-02-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

%==========================================================================
% MAPPING FROM INTEGRATION POINTS TO NODES - IP CANNOT BE PLOTTED
%==========================================================================
EL2N      = zeros(nel,3); % new connectivity matrix
GCOORD_N  = zeros(2,nel*3);
Mu_n      = zeros(3,nel);
EL2N(1,:) = 1:3;
nip = 6;
nnodel = 6;
[IP_X, IP_w]    = ip_triangle(nip);
[   Nbig]    = shp_triangle(IP_X, nnodel);
for i=1:nel
    is         = (i-1)*3+1; ie = (i-1)*3+3;
    GCOORD_N(:,is:ie) = GCOORD(:,ELEM2NODE([1 2 3],i));
    EL2N(i,:) = is:ie;
    Dummy      = Nbig'\Mu_all(i,:)';
    Mu_n(:,i)= Dummy(1:3);
end

% Correct negative E2_n which are the result of interpolation
Mu_n = abs(Mu_n);

%==========================================================================
% PLOT
%==========================================================================
% Plot viscosity
% --------------
%istep_Myr=floor((istep*dt/(ma/10)))/10;
%title(['Viscosity (',num2str(istep_Myr),' Myr)'])
%xlabel('Horizontal Position [km]')
%ylabel('Depth [km]')
% Check if the data needs to be plotted on logarithmic color scale
if exist('log_data','var')
    if log_data
        patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
            log10(Mu_n(:)),'FaceColor','flat')
    else
        patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
            Mu_n(:),'FaceColor','flat')
    end
else
    patch('faces',EL2N,'vertices',GCOORD_N'/1000,'facevertexcdata', ...
        log10(Mu_n(:)),'FaceColor','flat')
end
axis tight

color_choice=[
       0    0.5020    0.5020
    0.4392    0.6431    0.5804
    0.7059    0.7843    0.6588
    0.9647    0.9294    0.7412 
    0.9216    0.8706    0.6078
    0.9294    0.7333    0.5412
    0.8706    0.5412    0.3529
    
    0.7922    0.3373    0.1725
    0.7294    0.3176    0.1686
    0.6196    0.2314    0.0941
]
   
nColors = 256;
newmap = interp1(1:size(color_choice,1), color_choice, linspace(1, size(color_choice,1), nColors), 'linear');
colormap(flipud(newmap))

yticks( [-60,-40,-20,0]);
xticks( [-120,-80,-40,0,40,80,120]);
%xticks( [-150,-100,-50,0,50,100,150]);
axis([-120 120 -60 inf])
%axis([-80 80 -40 inf])
pbaspect([4 1 1])
%pbaspect([4 1 1])
%set (gca,'XDir','reverse')

%pbaspect([3 1 1])

%caxis([-22 -13]);

caxis([19 22]);


%colorbar('southoutside')


shading interp
hold on

% Plot box and interfaces
% -----------------------
plot_box
box on
ax.Box = 'off';
set(gca,'Box','off');
set(gca,'TickDir','out');
set(gca,'TickLength',[0.005,0.035])
drawnow

hold off

% Plot contours
hold on
x_=GCOORD_N(1,:)';
y_=GCOORD_N(2,:)';
z_=log10(Mu_n(:));
xi=linspace(min(x_),max(x_),100);
yi=linspace(min(y_),max(y_),100);
[XI YI]=meshgrid(xi,yi);
ZI = griddata(x_,y_,z_,XI,YI);

%figure(12);
%[cs,h]=contour(XI/1000,YI/1000,ZI, 'LineWidth',1,'Color','w')
%[cs,h]=contour(XI/1000,YI/1000,ZI,[21.5,21.5], 'LineWidth',1,'Color','w')
[cs,h]=contour(XI/1000,YI/1000,ZI,[21,21], 'LineWidth',1.5,'Color',[0.9686,0.4275,0.3686]);
%contour(XI/1000,YI/1000,ZI,[21.0,21.0], 'LineWidth',1,'Color','m')
hold on
%clabel(cs,'FontSize', 15)
cc=clabel(cs,h,'LabelSpacing',500,'Color',[0.9686,0.4275,0.3686],'FontSize', 10);%,'FontSize', 5);
%set(cc,'BackgroundColor','w');
%set(cc,'Margin',1);
drawnow
