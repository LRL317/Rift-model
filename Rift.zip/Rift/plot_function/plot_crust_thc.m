% Plots the surface of the model together with the layer below
%setting
GCO_p = GCOORD(:,Point_id==max(Point_id-1));
[GCO_p(1,:),indxs1] = sort(GCO_p(1,:));
GCO_p(2,:) = GCO_p(2,indxs1);

GCO_m = GCOORD(:,Point_id==max(Point_id-4));
[GCO_m(1,:),indxs2] = sort(GCO_m(1,:));
GCO_m(2,:) = GCO_m(2,indxs2);

GCO_l = GCOORD(:,Point_id==max(Point_id-7));
[GCO_l(1,:),indxs3] = sort(GCO_l(1,:));
GCO_l(2,:) = GCO_l(2,indxs3);



%interp1
max_GCO=[max(GCO_p(1,:)) max(GCO_m(1,:)) max(GCO_l(1,:))];
max_GCO_x=min(max_GCO);

min_GCO=[min(GCO_p(1,:)) min(GCO_m(1,:)) min(GCO_l(1,:))];
min_GCO_x=max(min_GCO);

x_inter=min_GCO_x:1:max_GCO_x;
GCOp_inter=interp1(GCO_p(1,:),GCO_p(2,:),x_inter,'spline');
GCOm_inter=interp1(GCO_m(1,:),GCO_m(2,:),x_inter,'spline');
GCOl_inter=interp1(GCO_l(1,:),GCO_l(2,:),x_inter,'spline');

%calculat
crust_thc=GCOp_inter-GCOl_inter;
l_crust_thc=GCOm_inter-GCOl_inter;
u_crust_thc=GCOp_inter-GCOm_inter;
crust_thc=crust_thc/km;

plot(x_inter/km,crust_thc,'k','LineWidth',2);
hold on
%plot(x_inter/km,l_crust_thc/km,'r','LineWidth',2);
hold on
%plot(x_inter/km,u_crust_thc/km,'g','LineWidth',2);
axis([-120 120 -inf 30])
hold off

title('Layer thick')
xlabel('Distance [Km]')
ylabel('Crust thick [Km]')
