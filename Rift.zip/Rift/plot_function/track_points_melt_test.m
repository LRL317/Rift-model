function TRACKP_melt = track_points_melt_test(GCOORD,ELEM2NODE,TRACKP_melt,DISPL,dt)

% TRACK_POINTS(GCOORD,ELEM2NODE,TRACKP,DISPL,DT) Calculates the new
% positions for the tracked points TRACKP after deformation of the current
% time step DT, using the velocities DISPL, defined in the nodes of a mesh
% GCOORD, ELEM2NODE.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 23-06-2013. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------
% MA 23-06-2014 Indexation of the outer track point problems solved


% Finds the elements where the track points are located
% Turn off TriRep warning
warning('off','MATLAB:TriRep:PtsNotInTriWarnId')

TRACKP_radius = TRACKP_melt(3,:);
TRACKP_istep = TRACKP_melt(4,:);
TRACKP = TRACKP_melt(1:2,:);

Tris = tsearch2(GCOORD,uint32(ELEM2NODE(1:3,:)),TRACKP);

% figure(7);
% patch('faces',ELEM2NODE(1:3,:)','vertices',GCOORD'/1000,'FaceColor','c')
% hold on; patch('faces',ELEM2NODE(1:3,Tris)','vertices',GCOORD'/1000,'FaceColor','r')
% axis([-150 150 -80 0])
%plot(TRACKP(1,:)/1000,TRACKP(2,:)/1000,'.','Color',[0, 0.5, 0],'MarkerSize',10)

% Finds points outside of the mesh
Ind = find(Tris==0);

%==========================================================================
% OUTSIDE POINTS
%==========================================================================

% Checks all points were found and if not correct the problem
if(~isempty(Ind))
    % Loop through the track points found outside of the mesh
    for i=1:length(Ind)
        % Finds the closest node
        [~,i_coord] = min(sqrt((GCOORD(1,:) ...
            - TRACKP(1,Ind(i))).^2 + (GCOORD(2,:) ...
            - TRACKP(2,Ind(i))).^2));
        
        % Finds the element wich the closest node belongs to
        [~,Tris(Ind(i))] = find(ismember(ELEM2NODE,i_coord),1);
        
        % Redifines the track point coordinates as the ones of the closest
        % node
        TRACKP(:,Ind(i)) = GCOORD(:,i_coord);
    end
end

%==========================================================================
% VELOCITIES AND DISPLACEMENTS
%==========================================================================

% Interpolate velocities at the trackpoints
Vx_tp = remesh_val_melt(Tris,GCOORD,TRACKP,DISPL(1,:),ELEM2NODE);
Vy_tp = remesh_val_melt(Tris,GCOORD,TRACKP,DISPL(2,:),ELEM2NODE);

% Calculates displacements and updates the position of the track points
TRACKP = TRACKP + [Vx_tp; Vy_tp].*dt;


TRACKP_melt=[TRACKP;TRACKP_radius;TRACKP_istep];

end


