function [Topography,Topo2nodes] = find_topo(GCOORD,ELEM2NODE,Point_id)
% [TOPOGRAPHY,TOPO2NODES] = FIND_TOPO(GCOORD,ELEM2NODE,POINT_ID) finds the
% nodes that are part of the topography of a model mesh defined by GCOORD,
% ELEM2NODE and POINT_ID. It returns the x- and y-coordinates of the
% topographic nodes TOPOGRAPHY and the indexes of this nodes TOPO2NODES at
% the global matrix.

%--------------------------------------------------------------------------
% Function written by Miguel Andres-Martinez, PhD student at Royal Holloway
% University of London, 05-09-2015. Email: mandresmartinez87@gmail.com
%--------------------------------------------------------------------------

% TODO Generalize function to find topography even when different layers
% are exposed at surface (i.e. basement and sediments).

% Surface nodes
Point_id(find(Point_id==-1,2,'last')) = max(Point_id)-1;
Surf_nodes = find(Point_id==max(Point_id)-1);

% Reorder topography
Ytopo = GCOORD(2,Surf_nodes);
[Xtopo,sort_topo] = sort(GCOORD(1,Surf_nodes));
Topography = [Xtopo; Ytopo(sort_topo)];

% Find the indexes that relate the Topography with its nodes
Topo2nodes = Surf_nodes(sort_topo);