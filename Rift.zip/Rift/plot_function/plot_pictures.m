%This code generates a series of visualization plots and performs data storage operations.

clc;
close all hidden;

 
for i_i=1:10:1001  % stepstest
    
    clear -regexp [^i_i];
    
    FN_open='';  % open variables path
    FN_save='';  % save file path   
    % dont change below
    
    mkdir(FN_save);  % make directory to store figures
    load(strcat(FN_open,'_',num2str(i_i)));  % load variables
    AGE=num2str(dt/ma*i_i);  % the age of every step, in Myr
    
    figure(1)
    clf;
    plot_eri;
    print(strcat(FN_save,'eri_',AGE,'.jpg'),'-djpeg','-r1000')
    
    figure(2)
    clf;
    plot_crust_thc;
    print(strcat(FN_save,'thc_',AGE,'.jpg'),'-djpeg','-r1000')
    
    figure(3)
    clf;
    plot_mu;
    hold on
    plot_vel_sparse;
    hold off
    print(strcat(FN_save,'vel_',AGE,'.jpg'),'-djpeg','-r1000')
   
end



















